import React, { useState, useEffect, useMemo, useCallback } from "react";
import axios from "axios";
import {
  Search,
  Edit,
  Trash2,
  X,
  Save,
  ChevronLeft,
  ChevronRight,
  Plus,
  FileText,
  ToggleLeft,
  ToggleRight,
} from "lucide-react";

// Initial state for adding a new contract
const INITIAL_NEW_CONTRACT_STATE = {
  name: "",
  
  status: true,
  isDefault: false, 
  order: 1, 
};

// --- ContractList Component ---

const ContractList = () => {
  const [contracts, setContracts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [newContract, setNewContract] = useState(INITIAL_NEW_CONTRACT_STATE);
  const [editingContract, setEditingContract] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);

  // --- API Configuration ---
  const API_BASE_URL =
    import.meta.env.VITE_API_BASE_URL || "http://localhost:5000/api";
  const CONTRACT_API_URL = `${API_BASE_URL}/contract`;

  // --- Utility Functions ---

 
  const boolToApiValue = (bool) => (bool ? 1 : 0);

  
  const normalizeContract = (c) => ({
    ...c,
    name: c.name || c.title,
 
    status: !!(c.status || c.isActive),
    isDefault: !!c.isDefault,
    order: c.order || 0,
  });

  
  const fetchContracts = useCallback(async () => {
    try {
      const res = await axios.get(CONTRACT_API_URL);
      const contractData = res.data.data
        ? res.data.data.map(normalizeContract)
        : [];

      if (Array.isArray(contractData)) {
        contractData.sort(
          (a, b) =>
            (a.order || 0) - (b.order || 0) ||
            (a.name || "").localeCompare(b.name || "")
        );
        setContracts(contractData);
      } else {
        console.error("API response data is not an array:", res.data);
        setContracts([]);
      }
    } catch (error) {
      console.error(`Error loading contracts: ${error}`);
    }
  },[CONTRACT_API_URL]);

  useEffect(() => {
    fetchContracts();
  }, [CONTRACT_API_URL,fetchContracts]);

  
  const unsetOtherDefaults = async (newDefaultContractId) => {
    // Find the current default contract (if any)
    const currentDefault = contracts.find(c => c.isDefault && c._id !== newDefaultContractId);
    
    if (currentDefault) {
      console.log(`Unsetting previous default: ${currentDefault.name}`);
      
      // Send update request to unset its default status
      try {
        await axios.put(`${CONTRACT_API_URL}/${currentDefault._id}`, {
          title: currentDefault.name,
          status: boolToApiValue(currentDefault.status),
          isDefault: 0, // Explicitly set to 0 (false)
          order: currentDefault.order,
        });
        
      } catch (error) {
        console.error(`Failed to unset default for ${currentDefault.name}:`, error.response?.data || error.message);
        // We proceed even if one update fails
      }
    }
  }



  //  Add Contract
  const handleAddContract = async () => {
    if (!newContract.name.trim()) {
      alert("Please enter contract name.");
      return;
    }

    try {
      // 1. If the new contract is set as default, unset all others FIRST.
      if (newContract.isDefault) {
        // Since the new contract doesn't have an ID yet, we pass null
        await unsetOtherDefaults(null); 
      }

      // 2. Add the new contract
      const payload = {
        title: newContract.name,
        
        status: boolToApiValue(newContract.status), 
        isDefault: boolToApiValue(newContract.isDefault), 
        order: newContract.order,
      };

      await axios.post(CONTRACT_API_URL, payload);
      
      
      await fetchContracts(); 

      setNewContract(INITIAL_NEW_CONTRACT_STATE);
      setShowAddForm(false);
      alert("Contract added successfully!");
      
    } catch (err) {
      console.error(
        "Failed to add contract. Server Response:",
        err.response?.data || err.message
      );
      alert(
        err.response?.data?.error ||
          err.response?.data?.message ||
          "Failed to save contract! Check console for details."
      );
    }
  };


  const handleEdit = (contract) => {
    setEditingContract(normalizeContract(contract));
  };

  const handleSaveEdit = async () => {
    if (!editingContract.name.trim()) {
      alert("Please enter contract name.");
      return;
    }

    try {
    
      if (editingContract.isDefault) {
        await unsetOtherDefaults(editingContract._id); 
      }

      // 2. Save the edited contract
      const payload = {
        title: editingContract.name,

        status: boolToApiValue(editingContract.status), 
        isDefault: boolToApiValue(editingContract.isDefault), 
        order: editingContract.order,
      };

      await axios.put(
        `${CONTRACT_API_URL}/${editingContract._id}`,
        payload
      );

      await fetchContracts(); 

      setEditingContract(null);
      alert("Contract updated successfully!");

    } catch (err) {
      console.error(
        "Failed to save edit. Server Response:",
        err.response?.data || err.message
      );
      alert(err.response?.data?.error || "Error updating contract");
    }
  };


  const handleCancelEdit = () => setEditingContract(null);
  const handleCancelAdd = () => {
    setShowAddForm(false);
    setNewContract(INITIAL_NEW_CONTRACT_STATE);
  };
  
  //  Delete Contract (Same)
  const handleDelete = async (id) => {
    // ... (rest of handleDelete remains the same)
    if (!window.confirm("Are you sure you want to delete this contract?"))
      return;

    try {
      await axios.delete(`${CONTRACT_API_URL}/${id}`);

      setContracts((prev) => prev.filter((c) => c._id !== id));
      alert("Contract deleted successfully.");
    } catch (err) {
      console.error(
        "Failed to delete contract. Server Response:",
        err.response?.data || err.message
      );
      alert(
        err.response?.data?.error ||
          "Failed to delete contract. It might be linked to other records or restricted by the server."
      );
    }
  };

  
  const handleToggleStatus = async (contract) => {
    // Toggle the boolean status
    const newStatus = !contract.status;

    try {
      const payload = {
        title: contract.name,
        status: boolToApiValue(newStatus), 
        isDefault: boolToApiValue(contract.isDefault),
        order: contract.order,
      };

      const res = await axios.put(`${CONTRACT_API_URL}/${contract._id}`, payload);
      const updatedContract = normalizeContract(res.data.data || res.data);

      setContracts((prev) =>
        prev.map((c) => (c._id === contract._id ? updatedContract : c))
      );
      alert(`Status toggled to ${newStatus ? 'Active' : 'Inactive'} successfully!`);

    } catch (err) {
      console.error(err);
      alert(err.response?.data?.error || "Failed to toggle status");
    }
  };
  
  // --- Search, Pagination, Badges (Same) ---
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(20);
  
  const filteredContracts = useMemo(() => {
    if (!Array.isArray(contracts)) return [];

    return contracts.filter((contract) =>
      (contract?.name || contract?.title || "")
        .toLowerCase()
        .includes(searchTerm.toLowerCase())
    );
  }, [searchTerm, contracts]);

  const totalPages = Math.ceil(filteredContracts.length / recordsPerPage);
  const indexOfLast = currentPage * recordsPerPage;
  const indexOfFirst = indexOfLast - recordsPerPage;
  const currentRecords = filteredContracts.slice(indexOfFirst, indexOfLast);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, recordsPerPage]);

  const getPageNumbers = () => {
    const pageNumbers = [];
    const maxPagesToShow = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2));
    let endPage = Math.min(totalPages, startPage + maxPagesToShow - 1);
    if (endPage - startPage + 1 < maxPagesToShow) {
      startPage = Math.max(1, endPage - maxPagesToShow + 1);
    }
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(i);
    }
    return pageNumbers;
  };
  
  const getStatusBadge = (status) => {
    return status === true ? (
      <span className="px-3 py-1 bg-green-100 text-green-800 text-sm font-medium rounded-full">
        Active
      </span>
    ) : (
      <span className="px-3 py-1 bg-red-100 text-red-800 text-sm font-medium rounded-full">
        Inactive
      </span>
    );
  };

 
  
  // --- JSX Render (Updated Add Form) ---

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 text-center">
          <div className="flex justify-center items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-[#450693] to-[#8C00FF] rounded-2xl">
              <FileText className="text-white" size={32} />
            </div>
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-[#450693] to-[#8C00FF] bg-clip-text text-transparent">
            Contract Management
          </h1>
          <p className="text-gray-600 mt-2">Manage Contracts</p>
        </div>

        {/* Controls Section */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <div className="flex flex-col lg:flex-row gap-4 justify-between items-start lg:items-center">
            {/* Search Bar */}
            <div className="relative flex-1 max-w-md">
              <Search
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={20}
              />
              <input
                type="text"
                placeholder="Search Contract..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#8C00FF] focus:border-transparent"
              />
            </div>

            {/* Records Per Page Selector */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">Show:</span>
              <select
                value={recordsPerPage}
                onChange={(e) => setRecordsPerPage(Number(e.target.value))}
                className="border rounded px-2 py-1 text-sm"
              >
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={40}>40</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
              <span className="text-sm text-gray-600">entries</span>
            </div>

            {/* Add Button */}
            <button
              onClick={() => setShowAddForm(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] text-white px-6 py-3 rounded-xl font-semibold hover:opacity-90 transition-opacity"
            >
              <Plus size={20} />
              Add Contract
            </button>
          </div>

          {/* Results Count */}
          <div className="mt-4 text-sm text-gray-600">
            Showing {filteredContracts.length} of {contracts.length} Contracts
          </div>
        </div>

        {/* Add Contract Form */}
        {showAddForm && (
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-6 border-2 border-[#8C00FF]">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-[#450693]">
                Add New Contract
              </h3>
              <button
                onClick={handleCancelAdd}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 items-end">
              <div className="lg:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Contract Name *
                </label>
                <input
                  type="text"
                  placeholder="Enter contract name"
                  value={newContract.name}
                  onChange={(e) =>
                    setNewContract({ ...newContract, name: e.target.value })
                  }
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Display Order
                </label>
                <input
                  type="number"
                  min="0"
                  placeholder="Order"
                  value={newContract.order}
                  onChange={(e) =>
                    setNewContract({
                      ...newContract,
                      order: parseInt(e.target.value) || 0,
                    })
                  }
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF]"
                />
              </div>

              <div className="flex flex-col gap-3">
                {/* Status Checkbox - Dynamic status removed */}
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="newStatus"
                    className="h-5 w-5 accent-[#8C00FF] cursor-pointer"
                    checked={newContract.status} 
                    onChange={(e) =>
                      setNewContract({
                        ...newContract,
                        status: e.target.checked, 
                      })
                    }
                  />
                  <label htmlFor="newStatus" className="text-sm font-medium text-gray-700 cursor-pointer">
                    Active
                  </label>
                </div>

                {/* Default Checkbox - Dynamic status removed */}
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="newDefault"
                    className="h-5 w-5 accent-[#8C00FF] cursor-pointer"
                    checked={newContract.isDefault} 
                    onChange={(e) =>
                      setNewContract({
                        ...newContract,
                        isDefault: e.target.checked, 
                      })
                    }
                  />
                  <label htmlFor="newDefault" className="text-sm font-medium text-gray-700 cursor-pointer">
                    Set as Default
                  </label>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={handleAddContract}
                  className="flex-1 bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] text-white px-4 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
                >
                  Add Contract
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Contracts Table */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gradient-to-r from-[#450693] to-[#8C00FF] text-white">
                  <th className="p-4 text-left font-semibold">#</th>
                  <th className="p-4 text-left font-semibold">Order</th>
                  <th className="p-4 text-left font-semibold">Contract Name</th>
                  <th className="p-4 text-center font-semibold">Status</th>
                  <th className="p-4 text-center font-semibold">Default</th>
                  <th className="p-4 text-center font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentRecords.map((contract, index) => {
                  const isEditing = editingContract?._id === contract._id;

                  return (
                    <tr
                      key={contract._id}
                      className={`border-b hover:bg-gray-50 transition-colors ${
                        contract.isDefault
                          ? "bg-yellow-50 border-l-4 border-l-yellow-400"
                          : index % 2 === 0
                          ? "bg-white"
                          : "bg-gray-50"
                      }`}
                    >
                      {/* Serial Number */}
                      <td className="p-4 font-medium">
                        {indexOfFirst + index + 1}
                      </td>

                      {/* Order (Edit Mode) */}
                      <td className="p-4">
                        {isEditing ? (
                          <input
                            type="number"
                            min="0"
                            value={editingContract.order}
                            onChange={(e) =>
                              setEditingContract({
                                ...editingContract,
                                order: parseInt(e.target.value) || 0,
                              })
                            }
                            className="w-16 p-2 border border-gray-300 rounded-lg text-center focus:outline-none focus:ring-2 focus:ring-[#8C00FF]"
                          />
                        ) : (
                          <span className="inline-flex items-center justify-center w-8 h-8 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                            {contract.order || 0}
                          </span>
                        )}
                      </td>

                      {/* Contract Name (Edit Mode) */}
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] rounded-full flex items-center justify-center text-white">
                            <FileText size={16} />
                          </div>
                          <div className="flex items-center gap-2 w-full">
                            {isEditing ? (
                              <input
                                type="text"
                                value={editingContract.name}
                                onChange={(e) =>
                                  setEditingContract({
                                    ...editingContract,
                                    name: e.target.value,
                                  })
                                }
                                className="flex-1 p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF]"
                              />
                            ) : (
                              <>
                                <div className="font-medium text-gray-900">
                                  {contract.name || "Missing Name"}
                                </div>
                                {contract.isDefault && (
                                  <span className="bg-yellow-500 text-white text-xs px-2 py-1 rounded-full font-medium">
                                    ⭐ Default
                                  </span>
                                )}
                              </>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Status (Edit Mode) */}
                      <td className="p-4 text-center">
                        {isEditing ? (
                          <input
                            type="checkbox"
                            className="h-5 w-5 accent-[#8C00FF] cursor-pointer"
                            checked={editingContract.status}
                            onChange={(e) =>
                              setEditingContract({
                                ...editingContract,
                                status: e.target.checked,
                              })
                            }
                          />
                        ) : (
                          getStatusBadge(contract.status)
                        )}
                      </td>

                      {/* Default (Edit Mode) */}
                      <td className="p-4 text-center">
                        {isEditing ? (
                          <input
                            type="checkbox"
                            className="h-5 w-5 accent-[#8C00FF] cursor-pointer"
                            checked={editingContract.isDefault}
                            onChange={(e) =>
                              setEditingContract({
                                ...editingContract,
                                isDefault: e.target.checked,
                              })
                            }
                          />
                        ) : contract.isDefault ? (
                          <span className="inline-flex items-center gap-1 text-yellow-600 font-medium">
                            <span className="w-2 h-2 bg-yellow-500 rounded-full"></span>
                            Yes
                          </span>
                        ) : (
                          <span className="text-gray-400">No</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="p-4 text-center">
                        <div className="flex justify-center gap-2">
                          {isEditing ? (
                            <>
                              <button
                                onClick={handleSaveEdit}
                                className="flex items-center gap-1 bg-green-500 text-white px-3 py-2 rounded-lg hover:bg-green-600 transition-colors"
                              >
                                <Save size={16} />
                                Save
                              </button>
                              <button
                                onClick={handleCancelEdit}
                                className="flex items-center gap-1 bg-gray-500 text-white px-3 py-2 rounded-lg hover:bg-gray-600 transition-colors"
                              >
                                <X size={16} />
                                Cancel
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                onClick={() => handleEdit(contract)}
                                className="flex items-center gap-1 bg-[#FFC400] text-white p-2 rounded-lg hover:bg-[#E6B000] transition-colors"
                                title="Edit"
                              >
                                <Edit size={16} />
                              </button>

                              <button
                                onClick={() => handleToggleStatus(contract)}
                                className={`flex items-center justify-center p-2 rounded-lg text-white transition-colors ${
                                  contract.status
                                    ? "bg-gray-500 hover:bg-gray-600"
                                    : "bg-green-500 hover:bg-green-600"
                                }`}
                                title={
                                  contract.status ? "Deactivate" : "Activate"
                                }
                              >
                                {contract.status ? (
                                  <ToggleLeft size={20} />
                                ) : (
                                  <ToggleRight size={20} />
                                )}
                              </button>

                              <button
                                onClick={() => handleDelete(contract._id)}
                                className={`flex items-center gap-1 bg-red-500 text-white p-2 rounded-lg hover:bg-red-600 transition-colors`}
                                title="Delete"
                              >
                                <Trash2 size={16} />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {/* Empty State */}
            {currentRecords.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                {searchTerm
                  ? "No contracts found matching your search."
                  : "No contracts available."}
              </div>
            )}
          </div>

          {/* Pagination */}
          {filteredContracts.length > 0 && (
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 p-6 border-t border-gray-200">
              <div className="text-sm text-gray-600">
                Showing {indexOfFirst + 1} to{" "}
                {Math.min(indexOfLast, filteredContracts.length)} of{" "}
                {filteredContracts.length} entries
              </div>

              <div className="flex items-center gap-2">
                {/* Pagination Controls */}
                <button
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(1)}
                  className="px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  First
                </button>

                <button
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(currentPage - 1)}
                  className="flex items-center gap-1 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronLeft size={16} />
                  Previous
                </button>

                {getPageNumbers().map((pageNumber) => (
                  <button
                    key={pageNumber}
                    onClick={() => setCurrentPage(pageNumber)}
                    className={`px-4 py-2 rounded-lg transition-colors ${
                      currentPage === pageNumber
                        ? "bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] text-white"
                        : "bg-white border border-gray-300 hover:bg-gray-50"
                    }`}
                  >
                    {pageNumber}
                  </button>
                ))}

                <button
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage(currentPage + 1)}
                  className="flex items-center gap-1 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Next
                  <ChevronRight size={16} />
                </button>

                <button
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage(totalPages)}
                  className="px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Last
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ContractList;