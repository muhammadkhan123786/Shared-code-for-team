import { getCities, getCountries } from '@/utils/EmployeeUtils';
import React, { useState, useEffect, useRef } from 'react';

const GoogleAddressAutocomplete = ({ onAddressChange }) => {
  const [useGoogleMap, setUseGoogleMap] = useState(true);
  const [countries, setCountries] = useState([]);
  const [cities, setCities] = useState([]);

  const [addressData, setAddressData] = useState({
    address: '',
    country: '',
    city: '',
    postal_code: '',
  });
  const inputRef = useRef(null);

  // Load Google Autocomplete only when toggle ON
  useEffect(() => {
    const fetchCountries = async () => {
      console.log('fetch countries.');
      try {
        const response = await getCountries(); // ✅ this should return data array
        console.log(response);
        setCountries(response || []); // ✅ set actual array, not function
      } catch (error) {
        console.error('Failed to fetch countries:', error);
      }
    };

    fetchCountries();
  }, []);
  useEffect(() => {
    const fetchCities = async () => {
      try {
        const response = await getCities();

        // Ensure response.data exists and is an array
        const allCities = Array.isArray(response) ? response : [];

        // Filter cities based on selected country (convert to Number safely)

        const filteredCities = allCities.filter(
          (city) => city.countryId._id === addressData.country
        );

        setCities(filteredCities);
      } catch (error) {
        console.error('Failed to fetch cities:', error);
        setCities([]); // Reset to empty array on error
      }
    };

    if (!useGoogleMap && addressData.country) {
      fetchCities();
    } else if (useGoogleMap) {
      // Clear manual cities when switching back to Google mode
      setCities([]);
    }
  }, [addressData.country, useGoogleMap]);

  useEffect(() => {
    if (!useGoogleMap || !window.google?.maps?.places) return;

    const autocomplete = new window.google.maps.places.Autocomplete(
      inputRef.current,
      {
        types: ['geocode'],
        componentRestrictions: { country: [] }, // you can restrict countries here
      }
    );

    autocomplete.addListener('place_changed', () => {
      const place = autocomplete.getPlace();
      const components = place.address_components || [];

      let country = '';
      let city = '';
      let postal_code = '';

      components.forEach((component) => {
        if (component.types.includes('country')) country = component.long_name;
        if (
          component.types.includes('locality') ||
          component.types.includes('administrative_area_level_2')
        )
          city = component.long_name;
        if (component.types.includes('postal_code'))
          postal_code = component.long_name;
      });

      const updated = {
        address: place.formatted_address || '',
        country,
        city,
        postal_code,
      };

      setAddressData(updated);
      onAddressChange(updated);
    });
  }, [useGoogleMap, onAddressChange]);

  // Handle manual input
  const handleManualChange = (e) => {
    const { name, value } = e.target;

    if (name === 'country') {
      console.log('Name: ', name);

      const updatedcities = cities.filter(
        (city) => city.country_id === Number(value)
      );
      setCities(updatedcities);
    }
    const updated = { ...addressData, [name]: value };
    setAddressData(updated);
    onAddressChange(updated);
  };

  return (
    <div className="space-y-4">
      {/* Toggle */}
      <label className="flex items-center gap-2">
        <input
          type="checkbox"
          checked={useGoogleMap}
          onChange={() =>
            setUseGoogleMap((pre) => {
              setAddressData({
                address: '',
                country: '',
                city: '',
                postal_code: '',
              });
              return !pre;
            })
          }
        />
        <span>Use Google Map Auto-Fill</span>
      </label>

      {/* Address Fields */}
      {useGoogleMap ? (
        <div className="space-y-3">
          <div>
            <label className="block text-sm font-medium mb-1">Address *</label>
            <input
              ref={inputRef}
              type="text"
              name="address"
              value={addressData.address}
              onChange={(e) =>
                setAddressData((prev) => ({ ...prev, address: e.target.value }))
              }
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="Start typing your address..."
              autoComplete="off"
            />
          </div>

          {/* Read-only auto fields */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-sm font-medium mb-1">Country</label>
              <input
                type="text"
                name="country"
                value={addressData.country}
                readOnly
                className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 cursor-not-allowed"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">City</label>
              <input
                type="text"
                name="city"
                value={addressData.city}
                readOnly
                className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 cursor-not-allowed"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">
                Postal Code
              </label>
              <input
                type="text"
                name="postal_code"
                value={addressData.postal_code}
                readOnly
                className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 cursor-not-allowed"
              />
            </div>
          </div>
        </div>
      ) : (
        /* Manual Input Mode */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium mb-1">Address *</label>
            <input
              type="text"
              name="address"
              value={addressData.address}
              onChange={handleManualChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="Enter address"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Country *</label>
            <select
              name="country"
              value={addressData._id}
              onChange={handleManualChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select Country</option>
              {countries.map((c) => (
                <option key={c._id} value={c._id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">City *</label>
            <select
              name="city"
              value={addressData._id}
              onChange={handleManualChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select City</option>
              {cities.map((c) => (
                <option key={c._id} value={c._id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">
              Postal Code *
            </label>
            <input
              type="text"
              name="postal_code"
              value={addressData.postal_code}
              onChange={handleManualChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="Enter postal code"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default GoogleAddressAutocomplete;
