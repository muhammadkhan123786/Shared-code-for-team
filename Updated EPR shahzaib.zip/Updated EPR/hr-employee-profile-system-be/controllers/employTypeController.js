const EmployType = require("../models/employtype");


exports.createEmploytype = async (req, res) => {
  try {
    const { description, order = 1, isDefault, isActive } = req.body;

    if (!description) {
      return res.status(400).json({ error: "Description is required" });
    }

    const exist = await EmployType.findOne({
      description: { $regex: new RegExp(`^${description.trim()}$`, "i") },
    });

    if (exist) {
      return res.status(400).json({ error: "Employ type already exists" });
    }

    const newEmployType = await EmployType.create({
      description: description.trim(),
      order: parseInt(order) || 1,
      isDefault,
      isActive,
    });

    res.status(201).json({
      message: "Employ type created successfully",
      data: newEmployType,
    });
  } catch (error) {
    console.error("Error creating employ type:", error);
    res.status(500).json({ error: "Failed to create employ type" });
  }
};

exports.getAllEmploytypes = async (req, res) => {
  try {
    const employTypes = await EmployType.find().sort({ createdAt: -1 });
    res.status(200).json({ data: employTypes });
  } catch (error) {
    console.error("Error fetching employ types:", error);
    res.status(500).json({ error: "Failed to fetch employ types" });
  }
};




exports.updateEmploytype = async (req, res) => {
    try {
        const { id } = req.params;
     
        const { description, order, isDefault, isActive } = req.body;

       
        const employType = await EmployType.findById(id);
        if (!employType) {
            return res.status(404).json({ error: "Employ type not found" });
        }

        // --- CRITICAL FIX: Unique Description Validation ---
        if (description) {
            const trimmedDescription = description.trim();
            
            
            const existingEmployType = await EmployType.findOne({
                description: trimmedDescription,
             
                _id: { $ne: id }, 
            });

            if (existingEmployType) {
              
                return res.status(409).json({ 
                    error: `Employ type name '${trimmedDescription}' already exists.`,
                    message: "Validation failed: Duplicate name."
                });
            }
            
          
            employType.description = trimmedDescription;
        }
    
        if (order !== undefined) employType.order = order;
        if (isDefault !== undefined) employType.isDefault = isDefault;
        if (isActive !== undefined) employType.isActive = isActive;

      
        if (isDefault === 1 || isDefault === true) {
            // Unset the default flag on all other documents
            await EmployType.updateMany(
                { _id: { $ne: id }, isDefault: true },
                { $set: { isDefault: false } }
            );
        
        }


        await employType.save();

        res.status(200).json({
            message: "Employ type updated successfully",
            data: employType,
        });

    } catch (error) {
        console.error("Error updating employ type:", error);
        
        res.status(500).json({ error: "Failed to update employ type. Check server logs." });
    }
};


exports.deleteEmploytype = async (req, res) => {
  try {
    const { id } = req.params;
    const employType = await EmployType.findByIdAndDelete(id);

    if (!employType) {
      return res.status(404).json({ error: "Employ type not found" });
    }

    res.status(200).json({ message: "Employ type deleted successfully" });
  } catch (error) {
    console.error("Error deleting employ type:", error);
    res.status(500).json({ error: "Failed to delete employ type" });
  }
};
