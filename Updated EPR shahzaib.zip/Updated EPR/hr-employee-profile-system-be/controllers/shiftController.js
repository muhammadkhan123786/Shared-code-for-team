const Shift = require("../models/shift");

exports.createShift = async (req, res) => {
  try {
    const { description, timing, order = 1, isDefault, isActive } = req.body;

    if (!description || !timing?.startTime || !timing?.endTime) {
      return res.status(400).json({ error: "All fields are required" });
    }

    const exist = await Shift.findOne({
      description: { $regex: new RegExp(`^${description.trim()}$`, "i") },
    });

    if (exist) {
      return res.status(400).json({ error: "Shift already exists" });
    }

    const newShift = await Shift.create({
      description: description.trim(),
      timing,
      order: parseInt(order) || 1,
      isDefault,
      isActive,
    });

    res.status(201).json({
      message: "Shift created successfully",
      data: newShift,
    });
  } catch (error) {
    console.error("Error creating shift:", error);
    res.status(500).json({ error: "Failed to create shift" });
  }
};


exports.getAllShifts = async (req, res) => {
  try {
    const shifts = await Shift.find().sort({ order: 1 });
    res.status(200).json({
      message: "Shifts fetched successfully",
      data: shifts,
    });
  } catch (error) {
    console.error("Error fetching shifts:", error);
    res.status(500).json({ error: "Failed to fetch shifts" });
  }
};




exports.updateShift = async (req, res) => {
    try {
        const { id } = req.params;
        const updatedData = req.body;

        if (updatedData.name) {
            const trimmedName = updatedData.name.trim();

          
            const existingShift = await Shift.findOne({
                name: trimmedName,
              
                _id: { $ne: id },
            });

            if (existingShift) {
                
                return res.status(409).json({
                    error: `Shift name '${trimmedName}' already exists.`,
                    message: "Validation failed: Duplicate name."
                });
            }

           
            updatedData.name = trimmedName;
        }
    
        const updatedShift = await Shift.findByIdAndUpdate(id, updatedData, {
            new: true,
            runValidators: true, 
        });

        if (!updatedShift) {
            return res.status(404).json({ error: "Shift not found" });
        }

        res.status(200).json({
            message: "Shift updated successfully",
            data: updatedShift,
        });

    } catch (error) {
        console.error("Error updating shift:", error);

        if (error.code === 11000) {
            return res.status(409).json({
                error: "A shift with these details already exists.",
                message: "Database conflict: Duplicate key."
            });
        }

        res.status(500).json({ error: "Failed to update shift" });
    }
};


exports.deleteShift = async (req, res) => {
  try {
    const { id } = req.params;

    const deletedShift = await Shift.findByIdAndDelete(id);

    if (!deletedShift) {
      return res.status(404).json({ error: "Shift not found" });
    }

    res.status(200).json({
      message: "Shift deleted successfully",
    });
  } catch (error) {
    console.error("Error deleting shift:", error);
    res.status(500).json({ error: "Failed to delete shift" });
  }
};
