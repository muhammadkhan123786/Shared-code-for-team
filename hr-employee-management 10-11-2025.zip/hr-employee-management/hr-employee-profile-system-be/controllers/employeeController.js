// controllers/employeeController.js
const Employee = require("../models/Employee");
const fs = require("fs");
const path = require("path");
const { fileUpload } = require("../middleware/fileUpload");
const Country = require("../models/Country");
const { default: mongoose } = require("mongoose");
const City = require("../models/City");

// Helper to calculate duration
const calculateDuration = (startDate, endDate) => {
  if (!startDate) return "";
  const start = new Date(startDate + "-01"); // Append day for month input
  const end = endDate === "Present" ? new Date() : new Date(endDate + "-01");
  const years = end.getFullYear() - start.getFullYear();
  const months = end.getMonth() - start.getMonth();
  let totalMonths = years * 12 + months;
  if (totalMonths < 0) totalMonths = 0;
  const yearsPart = Math.floor(totalMonths / 12);
  const monthsPart = totalMonths % 12;
  const parts = [];
  if (yearsPart > 0)
    parts.push(`${yearsPart} year${yearsPart !== 1 ? "s" : ""}`);
  if (monthsPart > 0)
    parts.push(`${monthsPart} month${monthsPart !== 1 ? "s" : ""}`);
  return parts.join(" ") || "0 months";
};

// GET all employees
exports.getAllEmployees = async (req, res) => {
  try {
    const employees = await Employee.find()
      .populate("title", "title")
      .populate("country", "name")
      .populate("city", "name")
      .populate("visaType", "type")
      .populate("department", "name")
      .populate("EmployeeStatus", "status")
      .populate("jobTitle", "name")
      .select("-__v"); // Exclude unnecessary fields
    res.json({ success: true, data: employees });
  } catch (error) {
    console.error("Error fetching employees:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to fetch employees" });
  }
};

// GET employee by ID
exports.getEmployeeById = async (req, res) => {
  try {
    const employee = await Employee.findById(req.params.id)
      .populate("title", "title")
      .populate("country", "name")
      .populate("city", "name")
      .populate("visaType", "type")
      .populate("department", "name")
      .populate("EmployeeStatus", "status")
      .populate("jobTitle", "name");
    if (!employee) {
      return res
        .status(404)
        .json({ success: false, message: "Employee not found" });
    }
    res.json({ success: true, data: employee });
  } catch (error) {
    console.error("Error fetching employee:", error);
    res
      .status(500)
      .json({ success: false, message: "Failed to fetch employee" });
  }
};

exports.createEmployee = [
  fileUpload,
  async (req, res) => {
    try {
      const profilePicture = req.files?.profilePicture?.[0]?.filename || null;

      // START: Diagnostic Logging
      console.log("--- Inside createEmployee Controller ---");
      console.log("req.body:", req.body);
      // END: Diagnostic Logging
      const { employeeStatus, ...rest } = req.body;
      let employeeData = {
        // Use 'let' so we can modify it
        ...req.body,
        EmployeeStatus: employeeStatus,
        profilePicture,
      };

      // Ensure address and postCode are always strings, even if empty,
      // to match potential schema expectations of type String.
      // This helps if they somehow come in as null/undefined from req.body
      employeeData.address = employeeData.address || "";
      employeeData.postCode = employeeData.postCode || "";

      // Diagnostic log after initial assignment
      console.log("employeeData after initial assignment:", employeeData);

      // 🔹 Validate Email (unchanged)
      const existingEmail = await Employee.findOne({
        email: employeeData.email,
      });
      if (existingEmail) {
        if (profilePicture)
          fs.unlinkSync(`uploads/profile-pictures/${profilePicture}`);
        return res.status(400).json({
          success: false,
          message: "Email already exists",
        });
      }

      // 🔹 Validate National Insurance Number (NIN) (unchanged)
      const existingNIN = await Employee.findOne({
        nationalInsuranceNumber: employeeData.nationalInsuranceNumber,
      });
      if (existingNIN) {
        if (profilePicture)
          fs.unlinkSync(`uploads/profile-pictures/${profilePicture}`);
        return res.status(400).json({
          success: false,
          message: "National Insurance Number already exists",
        });
      }

      // =========================
      // 🔹 Country Handling
      // =========================
      let { country } = employeeData;
      if (Array.isArray(country)) country = country[0];
      if (typeof country === "object" && country?.name) country = country.name;

      if (
        typeof country === "string" &&
        !mongoose.Types.ObjectId.isValid(country)
      ) {
        let countryDoc = await Country.findOne({ name: country.trim() });
        if (!countryDoc) {
          const lastCountry = await Country.findOne().sort({ order: -1 });
          const nextOrder = lastCountry ? lastCountry.order + 1 : 1;
          countryDoc = await Country.create({
            name: country.trim(),
            status: 1,
            isDefault: 0,
            order: nextOrder,
          });
          console.log(`✅ Created new country: ${countryDoc.name}`);
        }
        employeeData.country = countryDoc._id; // Update employeeData with ObjectId
      } else if (mongoose.Types.ObjectId.isValid(country)) {
        // If country is already a valid ObjectId (e.g., from an update scenario)
        employeeData.country = country;
      } else {
        // If country is neither a string to be looked up nor a valid ObjectId, clear it or handle as needed
        // This might be the case if an empty string or invalid input for country
        employeeData.country = null; // Or undefined, depending on schema requirements
      }

      // =========================
      // 🔹 City Handling
      // =========================
      let { city } = employeeData;
      if (Array.isArray(city)) city = city[0];
      if (typeof city === "object" && city?.name) city = city.name;

      if (typeof city === "string" && !mongoose.Types.ObjectId.isValid(city)) {
        let cityDoc = await City.findOne({
          name: city.trim(),
          countryId: employeeData.country, // Ensure country is already an ObjectId here
        });
        if (!cityDoc) {
          const lastCity = await City.findOne().sort({ order: -1 });
          const nextOrder = lastCity ? lastCity.order + 1 : 1;
          cityDoc = await City.create({
            name: city.trim(),
            countryId: employeeData.country,
            status: 1,
            isDefault: 0,
            order: nextOrder,
          });
          console.log(`✅ Created new city: ${cityDoc.name}`);
        }
        employeeData.city = cityDoc._id; // Update employeeData with ObjectId
      } else if (mongoose.Types.ObjectId.isValid(city)) {
        // If city is already a valid ObjectId
        employeeData.city = city;
      } else {
        employeeData.city = null; // Or undefined
      }

      // START: Diagnostic Logging
      console.log("employeeData BEFORE saving:", employeeData);
      // END: Diagnostic Logging

      // =========================
      // 🔹 Create Employee
      // =========================
      const employee = new Employee(employeeData);
      console.log("Employee: ", employee);
      await employee.save();

      res.status(201).json({
        success: true,
        message: "Employee created successfully",
        data: employee,
      });
    } catch (error) {
      console.error("❌ Error creating employee:", error.message);

      // 🔹 Cleanup files on error (unchanged)
      if (req.files) {
        if (req.files.profilePicture) {
          const profilePicFilename = req.files.profilePicture[0].filename;
          const profilePicPath = `uploads/profile-pictures/${profilePicFilename}`;
          if (fs.existsSync(profilePicPath)) {
            fs.unlinkSync(profilePicPath);
          }
        }
        if (req.files.documentFiles) {
          req.files.documentFiles.forEach((file) => {
            const docPath = `uploads/documents/${file.filename}`;
            if (fs.existsSync(docPath)) {
              fs.unlinkSync(docPath);
            }
          });
        }
      }

      // Differentiate between Mongoose validation errors and other errors
      if (error.name === "ValidationError") {
        return res.status(400).json({
          success: false,
          message: "Employee validation failed",
          error: error.message,
          errors: error.errors, // Include detailed validation errors
        });
      }

      res.status(500).json({
        success: false,
        message: "Failed to create employee",
        error: error.message,
      });
    }
  },
];

// UPDATE employee (for all steps: Education, Employment, Documents, NextOfKin)
exports.updateEmployee = [
  fileUpload,
  async (req, res) => {
    try {
      let updates = { ...req.body };
      const employeeId = req.params.id;

      let existingEmployee = await Employee.findById(employeeId);
      if (!existingEmployee) {
        return res
          .status(404)
          .json({ success: false, message: "Employee not found" });
      }

      // ---------------- COUNTRY NORMALIZATION ----------------
      let { country, city } = updates;

      if (Array.isArray(country)) country = country[0];
      if (typeof country === "object" && country !== null && country.name)
        country = country.name;

      if (
        typeof country === "string" &&
        !mongoose.Types.ObjectId.isValid(country)
      ) {
        let countryDoc = await Country.findOne({ name: country.trim() });
        if (!countryDoc) {
          const lastCountry = await Country.findOne()
            .sort({ order: -1 })
            .limit(1);
          const nextOrder = lastCountry ? lastCountry.order + 1 : 1;

          countryDoc = await Country.create({
            name: country.trim(),
            status: 1,
            isDefault: 0,
            order: nextOrder,
          });

          console.log(`✅ Created new country: ${countryDoc.name}`);
        }
        updates.country = countryDoc._id;
      }

      // ---------------- CITY NORMALIZATION ----------------
      if (Array.isArray(city)) city = city[0];
      if (typeof city === "object" && city !== null && city.name)
        city = city.name;

      if (typeof city === "string" && !mongoose.Types.ObjectId.isValid(city)) {
        let cityDoc = await City.findOne({
          name: city.trim(),
          countryId: updates.country || existingEmployee.country,
        });

        if (!cityDoc) {
          const lastCity = await City.findOne().sort({ order: -1 }).limit(1);
          const nextOrder = lastCity ? lastCity.order + 1 : 1;

          cityDoc = await City.create({
            name: city.trim(),
            countryId: updates.country || existingEmployee.country,
            status: 1,
            isDefault: 0,
            order: nextOrder,
          });

          console.log(`✅ Created new city: ${cityDoc.name}`);
        }
        updates.city = cityDoc._id;
      }

      // ---------------- EMPLOYEE STATUS NORMALIZATION ----------------
      if (
        updates.EmployeeStatus &&
        !mongoose.Types.ObjectId.isValid(updates.EmployeeStatus)
      ) {
        let statusDoc = await EmployeeStatus.findOne({
          status: updates.EmployeeStatus.trim(),
        });

        if (!statusDoc) {
          statusDoc = await EmployeeStatus.create({
            status: updates.EmployeeStatus.trim(),
          });
          console.log(`✅ Created new EmployeeStatus: ${statusDoc.status}`);
        }

        updates.EmployeeStatus = statusDoc._id;
      }

      // ---------------- PROFILE PICTURE HANDLING ----------------
      if (
        req.files &&
        req.files.profilePicture &&
        req.files.profilePicture.length > 0
      ) {
        if (existingEmployee.profilePicture) {
          const oldPath = path.join(
            __dirname,
            "..",
            existingEmployee.profilePicture
          );
          try {
            if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath);
          } catch (error) {
            console.warn(
              "⚠️ Failed to delete old profile picture:",
              error.message
            );
          }
        }

        updates.profilePicture = `uploads/profile-pictures/${req.files.profilePicture[0].filename}`;
      }

      // ---------------- DOCUMENTS HANDLING ----------------
      if (req.body.documents !== undefined) {
        let documentsJson;
        try {
          const docsStr = req.body.documents || "[]";
          documentsJson =
            typeof docsStr === "string" ? JSON.parse(docsStr) : docsStr;
        } catch (e) {
          return res
            .status(400)
            .json({ success: false, message: "Invalid documents JSON" });
        }

        const files = req.files?.documentFiles || [];

        const updatedDocuments = documentsJson.map((doc, index) => {
          if (files[index]) {
            doc.documentPath = files[index].filename;
            doc.uploadedAt = new Date();
          }

          if (doc._id) {
            const existingDocIndex = existingEmployee.documents.findIndex(
              (d) => d._id.toString() === doc._id
            );
            if (existingDocIndex !== -1) {
              return {
                ...existingEmployee.documents[existingDocIndex]._doc,
                ...doc,
              };
            }
          }

          return { ...doc, uploadedAt: doc.uploadedAt || new Date() };
        });

        updates.documents = updatedDocuments;
      }

      // ---------------- ✅ NEXT OF KIN HANDLING ----------------
      let nextOfKinsJson = [];

      if (req.body.nextOfKins !== undefined) {
        try {
          nextOfKinsJson =
            typeof req.body.nextOfKins === "string"
              ? JSON.parse(req.body.nextOfKins)
              : req.body.nextOfKins;

          if (!Array.isArray(nextOfKinsJson)) {
            return res.status(400).json({
              success: false,
              message: "Invalid nextOfKins format — must be an array",
            });
          }

          if (
            nextOfKinsJson.length > 0 &&
            !nextOfKinsJson.some((kin) => kin.isPrimary)
          ) {
            nextOfKinsJson[0].isPrimary = true;
          }

          // ✅ Country & City fix
          nextOfKinsJson = await Promise.all(
            nextOfKinsJson.map(async (kin) => {
              // Country fix
              if (
                kin.country &&
                typeof kin.country === "string" &&
                !mongoose.Types.ObjectId.isValid(kin.country)
              ) {
                let kinCountry = await Country.findOne({ name: kin.country });
                if (kinCountry) kin.country = kinCountry._id;
                else kin.country = null;
              }

              // City fix
              if (
                kin.city &&
                typeof kin.city === "string" &&
                !mongoose.Types.ObjectId.isValid(kin.city)
              ) {
                let kinCity = await City.findOne({ name: kin.city });
                if (kinCity) kin.city = kinCity._id;
                else kin.city = null;
              }

              return kin;
            })
          );

          updates.nextOfKins = nextOfKinsJson;
        } catch (error) {
          console.error("❌ Error parsing nextOfKins:", error);
          return res.status(400).json({
            success: false,
            message: "Invalid nextOfKins JSON",
            error: error.message,
          });
        }
      }

      // ---------------- EDUCATION HANDLING ----------------
      if (req.body.educations !== undefined) {
        let educationsJson;
        try {
          const edusStr = req.body.educations || "[]";
          educationsJson =
            typeof edusStr === "string" ? JSON.parse(edusStr) : edusStr;

          updates.educations = educationsJson;
        } catch (e) {
          return res
            .status(400)
            .json({ success: false, message: "Invalid educations JSON" });
        }
      }

      // ---------------- EMPLOYMENT HANDLING ----------------
      if (req.body.employments !== undefined) {
        let employmentsJson;
        try {
          const empsStr = req.body.employments || "[]";
          employmentsJson =
            typeof empsStr === "string" ? JSON.parse(empsStr) : empsStr;

          const updatedEmploymentsJson = employmentsJson.map((emp) => ({
            ...emp,
            duration: calculateDuration(emp.startDate, emp.endDate),
          }));

          updates.employments = updatedEmploymentsJson;
        } catch (e) {
          return res
            .status(400)
            .json({ success: false, message: "Invalid employments JSON" });
        }
      }

      // ---------------- APPLY UPDATES ----------------
      existingEmployee = await Employee.findByIdAndUpdate(employeeId, updates, {
        new: true,
        runValidators: true,
      })
        .populate("title", "title")
        .populate("country", "name")
        .populate("city", "name")
        .populate("visaType", "type")
        .populate("department", "name")
        .populate("jobTitle", "name")
        .populate("EmployeeStatus", "status");

      // ---------------- UNIQUE CHECKS ----------------
      if (req.body.email && req.body.email !== existingEmployee.email) {
        const emailCheck = await Employee.findOne({ email: req.body.email });
        if (emailCheck && emailCheck._id.toString() !== employeeId) {
          return res
            .status(400)
            .json({ success: false, message: "Email already exists" });
        }
      }

      if (
        req.body.nationalInsuranceNumber &&
        req.body.nationalInsuranceNumber !==
          existingEmployee.nationalInsuranceNumber
      ) {
        const ninCheck = await Employee.findOne({
          nationalInsuranceNumber: req.body.nationalInsuranceNumber,
        });
        if (ninCheck && ninCheck._id.toString() !== employeeId) {
          return res.status(400).json({
            success: false,
            message: "National Insurance Number already exists",
          });
        }
      }

      return res.json({ success: true, data: existingEmployee });
    } catch (error) {
      console.error("❌ Error updating employee:", error);

      // ✅ Cleanup files on error
      if (req.files) {
        if (req.files.profilePicture) {
          req.files.profilePicture.forEach((file) =>
            fs.unlinkSync(path.join("uploads/profile-pictures/", file.filename))
          );
        }
        if (req.files.documentFiles) {
          req.files.documentFiles.forEach((file) =>
            fs.unlinkSync(path.join("uploads/documents/", file.filename))
          );
        }
      }

      // ✅ More descriptive validation error messages
      if (error.name === "ValidationError") {
        const firstErrorKey = Object.keys(error.errors)[0];
        const firstErrorMsg =
          error.errors[firstErrorKey]?.message || "Validation failed";
        return res.status(400).json({
          success: false,
          message: `Field '${firstErrorKey}' is required or invalid`,
          error: firstErrorMsg,
        });
      }

      return res.status(500).json({
        success: false,
        message: "Failed to update employee",
        error: error.message,
      });
    }
  },
];

// DELETE employee
exports.deleteEmployee = async (req, res) => {
  console.log("Deleting employee with ID backend:", req.params.id);
  try {
    const employee = await Employee.findById(req.params.id);
    if (!employee) {
      return res
        .status(404)
        .json({ success: false, message: "Employee not found" });
    }
    // Delete profile picture if exists
    if (employee.profilePicture) {
      const filePath = path.join(
        "uploads/profile-pictures",
        employee.profilePicture
      );

      fs.unlink(filePath, (err) => {
        if (err && err.code === "ENOENT") {
          console.log("File not found, skipping delete");
        } else if (err) {
          console.log("Error deleting file:", err);
        } else {
          console.log("Profile picture deleted successfully");
        }
      });
    }
    // Delete documents
    if (employee.documents) {
      employee.documents.forEach((doc) => {
        if (doc.documentPath) {
          fs.unlinkSync(path.join("uploads/documents/", doc.documentPath));
        }
      });
    }
    await Employee.findByIdAndDelete(req.params.id);
    res.json({ success: true, message: "Employee deleted successfully" });
  } catch (error) {
    console.error("Error deleting employee:", error);
    res.status(500).json({ success: false, message: error });
  }
};
