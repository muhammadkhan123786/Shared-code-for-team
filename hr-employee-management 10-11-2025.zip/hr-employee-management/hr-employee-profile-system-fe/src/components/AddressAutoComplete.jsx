import { getCities, getCountries } from "@/utils/EmployeeUtils";
import React, { useState, useEffect, useRef } from "react";

// ✅ Check if value looks like MongoDB ObjectId
const isObjectId = (value) =>
  typeof value === "string" && /^[0-9a-fA-F]{24}$/.test(value);

const GoogleAddressAutocomplete = ({
  value = {},
  onAddressChange = () => {},
}) => {
  const [useGoogleMap, setUseGoogleMap] = useState(true);
  const [countries, setCountries] = useState([]);
  const [cities, setCities] = useState([]);
  const [loadingData, setLoadingData] = useState(true);
  const [addressData, setAddressData] = useState({
    address: "",
    country: "",
    city: "",
    postCode: "",
  });

  const inputRef = useRef(null);

  // ✅ Utility: Get name by ID
  const findNameById = (list, id) => {
    const item = list.find((item) => item._id === id);
    return item ? item.name : "";
  };

  // ✅ Sync value from parent for edit mode
  useEffect(() => {
    setAddressData({
      address: value.address || "",
      country: value.country || "",
      city: value.city || "",
      postCode: value.postCode || "",
    });
  }, [value]);

  // ✅ Fetch Countries
  useEffect(() => {
    const fetchCountries = async () => {
      try {
        const response = await getCountries();
        setCountries(response || []);
      } catch (error) {
        console.error("❌ Failed to fetch countries:", error);
      } finally {
        setLoadingData(false);
      }
    };
    fetchCountries();
  }, []);

  // ✅ Fetch Cities
  useEffect(() => {
    const fetchCities = async () => {
      try {
        const response = await getCities();
        const allCities = Array.isArray(response) ? response : [];
        const filtered = allCities.filter(
          (c) => c.countryId?._id === addressData.country
        );
        setCities(filtered);
      } catch (error) {
        console.error("❌ Failed to fetch cities:", error);
        setCities([]);
      }
    };

    if (!useGoogleMap && isObjectId(addressData.country)) {
      fetchCities();
    } else if (useGoogleMap) {
      setCities([]);
    }
  }, [addressData.country, useGoogleMap]);

  // ✅ Google Autocomplete Logic (Updated to show only street address)
  useEffect(() => {
    if (!useGoogleMap || !window.google?.maps?.places) return;

    // 🚨 FIX: Add check for HTMLInputElement (from previous conversation)
    const inputElement = inputRef.current;
    if (!inputElement || !(inputElement instanceof HTMLInputElement)) {
      return;
    }

    const autocomplete = new window.google.maps.places.Autocomplete(
      inputElement,
      {
        types: ["geocode"],
      }
    );

    autocomplete.addListener("place_changed", () => {
      const place = autocomplete.getPlace();
      if (!place || !place.address_components) return;

      let streetNumber = "";
      let route = "";
      let countryName = "";
      let cityName = "";
      let postCode = "";

      place.address_components.forEach((component) => {
        if (component.types.includes("street_number"))
          streetNumber = component.long_name;
        if (component.types.includes("route")) route = component.long_name;
        if (component.types.includes("country"))
          countryName = component.long_name;
        if (
          component.types.includes("locality") ||
          component.types.includes("administrative_area_level_2") ||
          component.types.includes("administrative_area_level_1")
        )
          cityName = component.long_name;
        if (component.types.includes("postal_code"))
          postCode = component.long_name;
      });

      // 💡 NEW LOGIC: Combine street number and route for the address field
      // This ensures only the street part is displayed in the input.
      const streetAddress = `${streetNumber} ${route}`.trim();

      // ✅ Match names with backend IDs
      const matchedCountry = countries.find(
        (c) => c.name?.toLowerCase() === countryName.toLowerCase()
      );

      // ✅ Fetch cities of that country and match name (extra safety)
      let matchedCity = null;
      if (matchedCountry) {
        const sameCountryCities = cities.filter(
          (city) => city.countryId?._id === matchedCountry._id
        );
        matchedCity = sameCountryCities.find(
          (city) => city.name?.toLowerCase() === cityName.toLowerCase()
        );
      }

      const updated = {
        // Set only the street address here
        address: streetAddress,
        // Country/City/PostCode are still captured for the backend/read-only fields
        country: matchedCountry ? matchedCountry._id : countryName,
        city: matchedCity ? matchedCity._id : cityName,
        postCode,
      };

      setAddressData(updated);
      onAddressChange(updated);
    });

    return () => {};
  }, [useGoogleMap, countries, cities, onAddressChange]);

  // ✅ Handle Google manual typing
  // This is still needed for when the user types and doesn't select a suggestion
  const handleGoogleAddressChange = (e) => {
    const updatedAddress = e.target.value;
    setAddressData((prev) => {
      const updatedState = { ...prev, address: updatedAddress };
      onAddressChange(updatedState);
      return updatedState;
    });
  };

  // ✅ Manual Inputs
  const handleManualChange = (e) => {
    const { name, value } = e.target;
    let updatedState = { ...addressData, [name]: value };

    // Reset city if country changes
    if (name === "country") updatedState.city = "";

    setAddressData(updatedState);
    onAddressChange(updatedState);
  };

  if (loadingData) return <p className="text-gray-500">Loading countries...</p>;

  return (
    <div className="space-y-4">
      <label className="flex items-center gap-2">
        <input
          type="checkbox"
          checked={useGoogleMap}
          onChange={() => setUseGoogleMap((prev) => !prev)}
        />
        <span>Use Google Map Auto-Fill</span>
      </label>

      {/* ✅ GOOGLE MAP MODE */}
      {useGoogleMap ? (
        <div className="space-y-3">
          <div>
            <label className="block text-sm font-medium mb-1">Address *</label>
            <input
              ref={inputRef}
              type="text"
              name="address"
              value={addressData.address}
              onChange={handleGoogleAddressChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="Start typing your address..."
              autoComplete="off"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            <div>
              <label className="block text-sm font-medium mb-1">Country</label>
              <input
                type="text"
                name="country"
                // Display the name, or the raw value if it's not an ID (Google Autocomplete value)
                value={
                  findNameById(countries, addressData.country) ||
                  addressData.country
                }
                readOnly
                className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 cursor-not-allowed"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">City</label>
              <input
                type="text"
                name="city"
                value={
                  findNameById(cities, addressData.city) || addressData.city
                }
                readOnly
                className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 cursor-not-allowed"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">
                Postal Code
              </label>
              <input
                type="text"
                name="postCode"
                value={addressData.postCode}
                readOnly
                className="w-full px-3 py-2 border border-gray-300 rounded-lg bg-gray-100 cursor-not-allowed"
              />
            </div>
          </div>
        </div>
      ) : (
        // ✅ MANUAL MODE
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div>
            <label className="block text-sm font-medium mb-1">Address *</label>
            <input
              type="text"
              name="address"
              value={addressData.address}
              onChange={handleManualChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="Enter address"
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Country *</label>
            <select
              name="country"
              value={addressData.country}
              onChange={handleManualChange}
              required
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select Country</option>
              {countries.map((c) => (
                <option key={c._id} value={c._id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">City *</label>
            <select
              name="city"
              value={addressData.city}
              onChange={handleManualChange}
              required
              disabled={!addressData.country}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Select City</option>
              {cities.map((c) => (
                <option key={c._id} value={c._id}>
                  {c.name}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">
              Postal Code
            </label>
            <input
              type="text"
              name="postCode"
              value={addressData.postCode}
              onChange={handleManualChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              placeholder="Enter postal code"
            />
          </div>
        </div>
      )}
    </div>
  );
};

export default GoogleAddressAutocomplete;
