// components/steps/DocumentsStep.jsx
import { useState, useEffect } from "react";
import { employeeAPI } from "@/services/employee";
import { toast } from "sonner";
import { Plus, X, Upload, FileText, Eye, Trash2, Download } from "lucide-react";

const DocumentsStep = ({
  setEmployeeId,
  employeeId,
  onClose,
  onBack,
  setCurrentStep,
}) => {
  const initialNewDocument = {
    documentType: "",
    documentTitle: "",
    description: "",
    file: null,
    isNew: true, // Flag for newly added forms
  };

  const [documents, setDocuments] = useState([initialNewDocument]);
  const [loading, setLoading] = useState(false);
  const [previewDocument, setPreviewDocument] = useState(null);

  const DOCUMENT_TYPES = [
    "CAS Letter",
    "Passport",
    "Visa Card",
    "BRP Card",
    "Driving License",
    "NI Number",
    "Bank Statement",
    "Utility Bill",
    "Tenancy Agreement",
    "Employment Contract",
    "Payslip",
    "CV/Resume",
    "References",
    "Qualifications",
    "DBS Certificate",
    "Other",
  ];

  useEffect(() => {
    if (employeeId) {
      loadDocumentsForEdit();
    }
  }, [employeeId]);

  // Load existing documents for pre-filling the form
  const loadDocumentsForEdit = async () => {
    try {
      const response = await employeeAPI.getEmployeeById(employeeId);
      if (
        response.success &&
        response.data.documents &&
        response.data.documents.length > 0
      ) {
        // Map existing documents to component state structure. Existing docs don't have 'file' object.
        const existingDocs = response.data.documents.map((doc) => ({
          ...doc,
          file: null, // No actual File object for existing docs
          isNew: false, // Flag for existing documents
        }));
        setDocuments(existingDocs);
      } else {
        // If no existing documents, start with one empty new document
        setDocuments([initialNewDocument]);
      }
    } catch (error) {
      console.error("Error loading documents for edit:", error);
      toast.error("Failed to load existing documents for editing.");
    }
  };

  const handleDocumentChange = (index, field, value) => {
    const newDocuments = [...documents];
    newDocuments[index] = {
      ...newDocuments[index],
      [field]: value,
    };
    setDocuments(newDocuments);
  };

  const handleDocumentFileUpload = (index, file) => {
    // Validate file type
    const validTypes = [
      "application/pdf",
      "image/jpeg",
      "image/jpg",
      "image/png",
      "image/webp",
      "application/msword",
      "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    ];

    if (!validTypes.includes(file.type)) {
      toast.error("Please select a valid file (PDF, Word, JPEG, PNG, WebP)");
      return;
    }

    // Validate file size (5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error("File size must be less than 5MB");
      return;
    }

    const newDocuments = [...documents];
    newDocuments[index] = {
      ...newDocuments[index],
      file: file,
      documentPath: null, // Clear existing path if a new file is uploaded
      isNew: true, // Mark as new/modified for file upload
    };
    setDocuments(newDocuments);
  };

  const addDocumentField = () => {
    setDocuments((prev) => [...prev, initialNewDocument]);
  };

  const removeDocumentField = (index) => {
    setDocuments((prev) => prev.filter((_, i) => i !== index));
  };

  const handleViewDocument = (document) => {
    // Priority: 1. New File Object -> 2. Existing Document Path
    if (document.file) {
      // For new documents (preview before upload)
      setPreviewDocument(URL.createObjectURL(document.file));
    } else if (document.documentPath) {
      // For existing documents
      const fileUrl = `http://localhost:5000/uploads/documents/${document.documentPath}`;
      window.open(fileUrl, "_blank");
    } else {
      toast.info("No file uploaded for this document.");
    }
  };

  // const handleDownloadDocument = (document) => {
  //   if (document.documentPath) {
  //     const fileUrl = `http://localhost:5000/uploads/documents/${document.documentPath}`;
  //     const link = document.createElement("a");
  //     link.href = fileUrl;
  //     link.download = document.documentTitle || "document";
  //     link.click();
  //   } else {
  //     toast.info(
  //       "Document not uploaded yet, please save first to enable download."
  //     );
  //   }
  // };

  // components/steps/DocumentsStep.jsx (The fix is in this function)

  const handleSubmit = async (e) => {
    e.preventDefault();

    const documentsMetadata = [];

    const filteredDocuments = documents.filter(
      (doc) => doc.documentTitle && (doc.file || doc.documentPath)
    );

    if (filteredDocuments.length === 0) {
      toast.error(
        "Please fill all required document fields and upload at least one file for new documents."
      );
      return;
    }

    setLoading(true);

    try {
      const submitData = new FormData();

      filteredDocuments.forEach((doc) => {
        // Prepare metadata for this document
        const metadata = {
          // Keep existing _id for existing documents so backend can identify them
          ...(doc._id && { _id: doc._id }),
          documentType: doc.documentType,
          documentTitle: doc.documentTitle,
          description: doc.description,

          ...(doc.documentPath &&
            !doc.file && { documentPath: doc.documentPath }),
        };
        documentsMetadata.push(metadata);

        if (doc.file) {
          submitData.append(`documentFiles`, doc.file);
        }
      });

      submitData.append("documents", JSON.stringify(documentsMetadata));

      const response = await employeeAPI.updateEmployee(employeeId, submitData);

      if (response.success) {
        toast.success("Documents updated successfully");
        await loadDocumentsForEdit();
        setEmployeeId(response.data._id);
        setCurrentStep(5);
      } else {
        toast.error(response.message || "Failed to update documents");
      }
    } catch (error) {
      console.error("Error updating documents:", error);
      toast.error("Error updating documents");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-black bg-opacity-50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white w-full max-w-6xl max-h-[90vh] overflow-y-auto rounded-xl shadow-2xl">
        {/* Header */}
        <div className="p-6 border-b border-gray-200 bg-gradient-to-r from-purple-600 to-purple-700 text-white rounded-t-xl">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">Documents Upload</h2>
              <p className="text-purple-100 mt-1">
                Upload and manage employee documents
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-purple-200 transition-colors p-2 rounded-lg hover:bg-purple-500"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          <div className="space-y-6">
            {/* Upload/Edit Documents */}
            <div className="bg-white rounded-lg border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <h4 className="text-lg font-semibold text-gray-900">
                  {documents.length > 0
                    ? "Edit/Upload Employee Documents"
                    : "Upload Documents"}
                </h4>
                <p className="text-sm text-gray-500 mt-1">
                  Add or modify documents for this employee record
                </p>
              </div>

              <div className="p-6 space-y-6">
                {documents.map((doc, index) => (
                  <div
                    key={doc._id || index} // Use _id for existing, index for new
                    className="border border-gray-200 rounded-lg p-6 bg-gray-50"
                  >
                    <div className="flex justify-between items-center mb-4">
                      <h5 className="text-md font-semibold text-gray-900">
                        {doc.isNew ? `New Document #${index + 1}` : ``}
                      </h5>
                      {/* Action Buttons for Existing Documents (Download/View/Delete) */}
                      {/* {!doc.isNew && doc.documentPath && (
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleViewDocument(doc)}
                            className="p-2 text-purple-600 hover:text-purple-800 hover:bg-purple-50 rounded-lg transition-colors"
                            title="View Document"
                          >
                            <Eye size={18} />
                          </button>
                          <button
                            type="button"
                            onClick={() => handleDownloadDocument(doc)}
                            className="p-2 text-green-600 hover:text-green-800 hover:bg-green-50 rounded-lg transition-colors"
                            title="Download Document"
                          >
                            <Download size={18} />
                          </button>
                          <button
                            type="button"
                            onClick={() => removeDocumentField(index)} // Remove field handles local state for deletion
                            className="p-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                            title="Delete Document"
                          >
                            <Trash2 size={18} />
                          </button>
                        </div>
                      )} */}

                      {documents.length > 1 &&
                        doc.isNew && ( // Only show remove for newly added forms if multiple exist
                          <button
                            type="button"
                            onClick={() => removeDocumentField(index)}
                            className="p-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-colors"
                            title="Remove New Document Field"
                          >
                            <X size={18} />
                          </button>
                        )}
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                        <label className="block text-sm font-medium text-gray-700">
                          Document Type
                        </label>
                        <select
                          value={doc.documentType}
                          onChange={(e) =>
                            handleDocumentChange(
                              index,
                              "documentType",
                              e.target.value
                            )
                          }
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                        >
                          <option value="">Select Document Type</option>
                          {DOCUMENT_TYPES.map((type) => (
                            <option key={type} value={type}>
                              {type}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div className="space-y-2">
                        <label className="block text-sm font-medium text-gray-700">
                          Document Title <span className="text-red-500">*</span>
                        </label>
                        <input
                          type="text"
                          value={doc.documentTitle}
                          onChange={(e) =>
                            handleDocumentChange(
                              index,
                              "documentTitle",
                              e.target.value
                            )
                          }
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                          placeholder="e.g., UK Passport Bio Page"
                          required
                        />
                      </div>

                      <div className="md:col-span-2 space-y-2">
                        <label className="block text-sm font-medium text-gray-700">
                          Upload Document{" "}
                          <span className="text-red-500">*</span>
                        </label>
                        <div className="space-y-3">
                          <div className="flex items-center gap-4">
                            <label className="flex items-center gap-3 px-6 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 cursor-pointer transition-all border-2 border-dashed border-purple-200 shadow-sm">
                              <Upload size={20} />
                              <span className="font-medium">
                                {doc.file || doc.documentPath
                                  ? "Change/Re-Upload Document"
                                  : "Choose Document"}
                              </span>
                              <input
                                type="file"
                                className="hidden"
                                accept=".pdf,.doc,.docx,.jpg,.jpeg,.png,.webp"
                                onChange={(e) => {
                                  const file = e.target.files?.[0];
                                  if (file) {
                                    handleDocumentFileUpload(index, file);
                                  }
                                }}
                              />
                            </label>

                            {(doc.file || doc.documentPath) && (
                              <div className="flex items-center gap-3 bg-white rounded-lg px-4 py-2 border border-gray-200">
                                <FileText
                                  size={20}
                                  className="text-green-500"
                                />
                                <div>
                                  <p className="text-sm font-medium text-gray-700">
                                    {/* Display file name for new uploads, or path name for existing */}
                                    {doc.file
                                      ? doc.file.name
                                      : doc.documentPath.split("/").pop() ||
                                        "Existing File"}
                                  </p>
                                  {doc.file && doc.file.size && (
                                    <p className="text-xs text-gray-500">
                                      {(doc.file.size / 1024 / 1024).toFixed(2)}{" "}
                                      MB
                                    </p>
                                  )}
                                </div>
                                {/* View/Preview Button for current file/path */}
                                <button
                                  type="button"
                                  onClick={() => handleViewDocument(doc)}
                                  className="p-1 text-purple-600 hover:text-purple-800"
                                  title="Preview Document"
                                >
                                  <Eye size={16} />
                                </button>
                              </div>
                            )}
                          </div>
                          <p className="text-sm text-gray-500">
                            <strong>Supported formats:</strong> PDF, DOC, DOCX,
                            JPG, PNG, WEBP • <strong>Max size:</strong> 5MB
                          </p>
                        </div>
                      </div>

                      <div className="md:col-span-2 space-y-2">
                        <label className="block text-sm font-medium text-gray-700">
                          Description (Optional)
                        </label>
                        <textarea
                          value={doc.description}
                          onChange={(e) =>
                            handleDocumentChange(
                              index,
                              "description",
                              e.target.value
                            )
                          }
                          rows={3}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent transition-all"
                          placeholder="Add any additional notes about this document..."
                        />
                      </div>
                    </div>
                  </div>
                ))}

                {/* Add Another Document Button */}
                <button
                  type="button"
                  onClick={addDocumentField}
                  className="flex items-center gap-3 px-6 py-3 text-purple-600 hover:text-purple-700 hover:bg-purple-50 rounded-lg border-2 border-dashed border-purple-200 transition-all w-full justify-center"
                >
                  <Plus size={20} />
                  <span className="font-medium">Add Another Document</span>
                </button>
              </div>
            </div>

            {/* Information Box */}
            <div className="bg-purple-50 border border-purple-200 rounded-lg p-6">
              <div className="flex items-start">
                <div className="flex-shrink-0">
                  <FileText className="h-6 w-6 text-purple-400" />
                </div>
                <div className="ml-4">
                  <h3 className="text-sm font-medium text-purple-800">
                    Document Requirements
                  </h3>
                  <div className="mt-2 text-sm text-purple-700">
                    <ul className="list-disc list-inside space-y-1">
                      <li>
                        Upload all required documents for employment
                        verification
                      </li>
                      <li>Accepted formats: PDF, DOC, DOCX, JPG, PNG, WEBP</li>
                      <li>Maximum file size: 5MB per document</li>
                      <li>Ensure documents are clear and readable</li>
                      <li>
                        Documents will be stored securely and can be accessed
                        anytime
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Document Preview Modal */}
          {previewDocument && (
            <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
              <div className="bg-white rounded-lg max-w-4xl max-h-[90vh] overflow-auto">
                <div className="p-4 border-b border-gray-200 flex justify-between items-center">
                  <h3 className="text-lg font-semibold">Document Preview</h3>
                  <button
                    onClick={() => setPreviewDocument(null)}
                    className="text-gray-400 hover:text-gray-600"
                  >
                    <X size={24} />
                  </button>
                </div>
                <div className="p-4">
                  <iframe
                    src={previewDocument}
                    className="w-full h-96"
                    title="Document Preview"
                  />
                  <div className="mt-4 flex justify-end">
                    <button
                      onClick={() => setPreviewDocument(null)}
                      className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400"
                    >
                      Close Preview
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Submit Buttons */}
          <div className="flex justify-between gap-4 mt-8 pt-6 border-t border-gray-200">
            <div className="flex gap-3">
              {onBack && (
                <button
                  type="button"
                  onClick={onBack}
                  className="flex items-center gap-2 px-6 py-3 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-all font-medium"
                >
                  Back
                </button>
              )}
              <button
                type="button"
                onClick={onClose}
                className="px-6 py-3 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-all font-medium"
              >
                Cancel
              </button>
            </div>
            <button
              type="submit"
              disabled={loading}
              className="flex items-center gap-3 px-8 py-3 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-all font-medium disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <>
                  <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white"></div>
                  Saving Documents...
                </>
              ) : (
                "Save Documents"
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default DocumentsStep;
