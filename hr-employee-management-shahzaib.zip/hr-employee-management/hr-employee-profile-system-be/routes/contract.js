const express = require("express");
const { CreateContract, getAllContracts, updateContract, deleteContract } = require("../controllers/contractController.js");

const contractRoute = express.Router();

contractRoute.post('/', CreateContract)
contractRoute.get('/', getAllContracts)
contractRoute.put("/:id", updateContract);
contractRoute.delete("/:id", deleteContract);

module.exports = contractRoute