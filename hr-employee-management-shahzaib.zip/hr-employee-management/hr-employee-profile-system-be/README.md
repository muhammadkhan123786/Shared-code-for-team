# hr-management
Hr Employee management system. 
