// components/steps/NextOfKinStep.jsx

import { useState, useEffect } from "react";
import { employeeAPI } from "@/services/employee";
import { toast } from "sonner";

import {
  Plus,
  X,
  User,
  Heart,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Star,
  Briefcase,
} from "lucide-react";
import GoogleAddressAutocomplete from "@/components/AddressAutocomplete";

const NextOfKinStep = ({ employeeId, onSuccess, onClose, onBack }) => {
  // ⭐️ UNIFIED STATE: Combine new and existing contacts into one state for simpler form management
  const [allKins, setAllKins] = useState([]);
  const [loading, setLoading] = useState(false); // Default structure for a new Next of Kin entry

  const initialKinState = {
    fullName: "",
    relationship: "",
    dateOfBirth: "",
    gender: "",
    address: "", // Changed initial state to "" (empty string)
    city: "",
    country: "",
    postCode: "",
    phoneNumber: "",
    alternatePhoneNumber: "",
    email: "",
    occupation: "",
    isPrimary: false,
    employeeStatus: null, // Required field from backend
    isNew: true, // Helper flag
  };

  const RELATIONSHIPS = [
    "Spouse",
    "Parent",
    "Child",
    "Sibling",
    "Grandparent",
    "Grandchild",
    "Friend",
    "Colleague",
    "Other",
  ];

  const GENDERS = ["Male", "Female", "Other"];
  const COUNTRIES = [
    "United Kingdom",
    "Ireland",
    "United States",
    "Canada",
    "Australia",
    "Other",
  ]; // ======================================================= // 💡 HELPER FUNCTION: DATA CLEANING (MODIFIED for OPTIONAL ID) // Null/Empty values ko **undefined** se replace karega taki Mongoose ignore kare.

  const cleanAddressField = (value) => {
    // Agar value populated Object hai, toh uski _id nikaalenge.
    if (typeof value === "object" && value !== null && value._id) {
      return value._id; // Extract the clean ID string
    } // ⭐️ CRITICAL CHANGE: Agar value null, undefined, ya empty string hai, toh **undefined** return karein. // Yehi Mongoose ko field skip karne deta hai, aur Cast to ObjectId error nahi aata.

    if (value === null || value === undefined || value === "") return undefined; // Warna, value ko jaisa hai waisa hi rakhenge (like if it was already an ID string).

    return value;
  }; // ======================================================= // 1. Initial Load & Prefill
  useEffect(() => {
    if (employeeId) {
      loadNextOfKins();
    } else {
      // Initialize with one empty contact if adding a new employee
      setAllKins([{ ...initialKinState, isPrimary: true }]);
    }
  }, [employeeId]);

  const loadNextOfKins = async () => {
    try {
      const response = await employeeAPI.getEmployeeById(employeeId);
      if (response.success && response.data.nextOfKins) {
        setAllKins(
          response.data.nextOfKins.map((kin) => ({
            ...kin,
            employeeStatus: kin.employeeStatus || null,
            isNew: false,
          }))
        );
      }
    } catch (error) {
      console.error("Error loading next of kin:", error);
    }
  }; // 2. Generic Change Handler

  const handleNextOfKinChange = (index, field, value) => {
    setAllKins((prevKins) => {
      const newKins = [...prevKins];
      newKins[index] = {
        ...newKins[index],
        [field]: value,
      }; // Handle Primary Checkbox logic

      if (field === "isPrimary" && value === true) {
        newKins.forEach((kin, i) => {
          if (i !== index) {
            newKins[i].isPrimary = false;
          }
        });
      }

      return newKins;
    });
  }; // 3. Address Autocomplete Handler (UPDATED with Cleaning Logic)

  const handleAddressChange = (index, addressDetails) => {
    if (!addressDetails) return; // Apply the cleaning function (returns ID string or undefined)

    const countryValue = cleanAddressField(addressDetails.country);
    const cityValue = cleanAddressField(addressDetails.city);

    setAllKins((prevKins) => {
      const newKins = [...prevKins];
      newKins[index] = {
        ...newKins[index],
        address: addressDetails.address || "", // Set the cleaned value (ID string or undefined)
        city: cityValue,
        country: countryValue,
        postCode: addressDetails.postCode || "",
      };
      return newKins;
    });
  };

  const addNextOfKinField = () => {
    const isFirstEntry = allKins.length === 0;

    setAllKins((prev) => [
      ...prev,
      {
        ...initialKinState,
        isPrimary: isFirstEntry,
      },
    ]);
  };

  const removeNextOfKinField = (index) => {
    // If the removed item was primary, and others exist, set the *first* remaining one as primary.
    const kinsAfterRemoval = allKins.filter((_, i) => i !== index);

    if (allKins[index].isPrimary && kinsAfterRemoval.length > 0) {
      kinsAfterRemoval[0].isPrimary = true;
    }

    setAllKins(kinsAfterRemoval);
  }; // 4. Submission Handler (MODIFIED - Removed City/Country Validation)

  const handleSubmit = async (e) => {
    e.preventDefault(); // --- Validation Logic ---

    const hasValidNextOfKins = allKins.every(
      (kin) =>
        kin.fullName &&
        kin.relationship &&
        kin.dateOfBirth &&
        kin.gender &&
        kin.address &&
        kin.phoneNumber // ⭐️ CITY & COUNTRY VALIDATION REMOVED (Optional kiya gaya hai)
    );

    if (!hasValidNextOfKins) {
      // Error message ko basic required fields ke liye rakha gaya hai
      toast.error(
        "Please fill all **required** fields (Name, Relationship, DOB, Gender, Address, Phone Number)."
      );
      return;
    }

    const hasPrimary = allKins.some((kin) => kin.isPrimary);
    if (!hasPrimary && allKins.length > 0) {
      toast.error("Please select a primary emergency contact.");
      return;
    } // --- End Validation Logic ---
    setLoading(true);

    try {
      // CRITICAL STEP: Ensure final cleanup maps null/"" to undefined
      const cleanedNextOfKins = allKins.map((kin) => ({
        ...kin, // Final cleanup will return ID string or **undefined**
        country: cleanAddressField(kin.country),
        city: cleanAddressField(kin.city),
      })); // 💡 Prepare the data for submission (only the necessary fields)

      const submitData = {
        nextOfKins: cleanedNextOfKins.map((kin) => ({
          fullName: kin.fullName,
          relationship: kin.relationship,
          dateOfBirth: kin.dateOfBirth,
          gender: kin.gender,
          address: kin.address, // ⭐️ City/Country will be ID string or undefined (jo Mongoose ignore karega)

          city: kin.city,
          country: kin.country,

          postCode: kin.postCode || "",
          phoneNumber: kin.phoneNumber,
          alternatePhoneNumber: kin.alternatePhoneNumber,
          email: kin.email,
          occupation: kin.occupation,
          isPrimary: kin.isPrimary,
          employeeStatus: kin.employeeStatus || null,

          ...(kin.id && { _id: kin.id }),
        })),
      };

      const response = await employeeAPI.updateEmployee(employeeId, submitData);

      if (response.success) {
        toast.success("Next of kin information updated successfully");
        onSuccess(employeeId);
      } else {
        toast.error(
          response.message || "Failed to update next of kin information"
        );
      }
    } catch (error) {
      console.error("Error updating next of kin:", error);
      toast.error("required all feild");
    } finally {
      setLoading(false);
    }
  }; // Initialize with one contact if allKins is empty after load attempt

  useEffect(() => {
    // Always ensure at least one empty form appears
    if (allKins.length === 0 && !loading) {
      setAllKins([{ ...initialKinState, isPrimary: true }]);
    }
  }, [allKins.length, loading]);

  return (
    <div className="bg-black relative bg-opacity-50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <div className="bg-white w-full max-w-7xl max-h-[90vh] overflow-hidden rounded-2xl shadow-2xl">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-purple-800 p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-white bg-opacity-20 rounded-lg">
                <Heart size={24} className="text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-white">
                  Next of Kin Information
                </h2>
                <p className="text-purple-100 mt-1">
                  Add emergency contacts and family information
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-purple-200 transition-colors p-2 rounded-full hover:bg-white hover:bg-opacity-20"
            >
              <X size={24} />
            </button>
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]"
        >
          <div className="space-y-6">
            <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <div className="bg-gradient-to-r from-gray-50 to-gray-100 px-6 py-4 border-b border-gray-200">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Plus size={20} className="text-purple-600" />
                    <h4 className="text-lg font-semibold text-gray-900">
                      {allKins.length > 0
                        ? "Manage Next of Kin"
                        : "Add Next of Kin"}
                    </h4>
                  </div>
                  <span className="text-sm text-gray-500 bg-white px-3 py-1 rounded-full border">
                    {allKins.length}
                    {allKins.length === 1 ? " contact" : " contacts"}
                  </span>
                </div>
                <p className="text-sm text-gray-500 mt-1">
                  Add emergency contacts and family members
                </p>
              </div>

              <div className="p-6 space-y-6">
                {/* ⭐️ MAPPING OVER UNIFIED STATE (allKins) for Edit/New Mode */}
                {allKins.map((kin, index) => (
                  <div
                    key={kin.id || `new-${index}`} // Use existing ID or a generated key for new contacts
                    className="border border-gray-200 rounded-xl p-6 bg-gradient-to-br from-gray-50 to-white hover:shadow-sm transition-all duration-200"
                  >
                    <div className="flex justify-between items-center mb-6 pb-4 border-b border-gray-200">
                      <div className="flex items-center gap-3">
                        <div className="p-2 bg-purple-100 rounded-lg">
                          <User size={18} className="text-purple-600" />
                        </div>
                        <h5 className="text-lg font-semibold text-gray-900">
                          Contact #{index + 1}
                        </h5>
                        {kin.isPrimary && (
                          <span className="inline-flex items-center gap-1 px-3 py-1 rounded-full text-sm font-medium bg-purple-100 text-purple-800">
                            <Star size={14} />
                            Primary Contact
                          </span>
                        )}
                      </div>
                      {allKins.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removeNextOfKinField(index)}
                          className="p-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-lg transition-all duration-200"
                        >
                          <X size={18} />
                        </button>
                      )}
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      {/* Full Name */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                          <User size={16} className="text-purple-600" />
                          Full Name *
                        </label>
                        <input
                          type="text"
                          value={kin.fullName}
                          onChange={(e) =>
                            handleNextOfKinChange(
                              index,
                              "fullName",
                              e.target.value
                            )
                          }
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                          placeholder="e.g., Sarah Johnson"
                          required
                        />
                      </div>
                      {/* Relationship */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                          <Heart size={16} className="text-purple-600" />
                          Relationship to Employee *
                        </label>
                        <select
                          value={kin.relationship}
                          onChange={(e) =>
                            handleNextOfKinChange(
                              index,
                              "relationship",
                              e.target.value
                            )
                          }
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                          required
                        >
                          <option value="">Select Relationship</option>
                          {RELATIONSHIPS.map((relationship) => (
                            <option key={relationship} value={relationship}>
                              {relationship}
                            </option>
                          ))}
                        </select>
                      </div>
                      {/* Date of Birth */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                          <Calendar size={16} className="text-purple-600" />
                          Date of Birth *
                        </label>
                        <input
                          type="date"
                          value={kin.dateOfBirth}
                          onChange={(e) =>
                            handleNextOfKinChange(
                              index,
                              "dateOfBirth",
                              e.target.value
                            )
                          }
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                          required
                        />
                      </div>
                      {/* Gender */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                          <User size={16} className="text-purple-600" />
                          Gender *
                        </label>
                        <select
                          value={kin.gender}
                          onChange={(e) =>
                            handleNextOfKinChange(
                              index,
                              "gender",
                              e.target.value
                            )
                          }
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                          required
                        >
                          <option value="">Select Gender</option>
                          {GENDERS.map((gender) => (
                            <option key={gender} value={gender}>
                              {gender}
                            </option>
                          ))}
                        </select>
                      </div>
                      {/* Address Field (using the Autocomplete component) */}
                      <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                          <MapPin size={16} className="text-purple-600" />
                          Address *
                        </label>
                        {/* ⭐️ Pass the current kin's address data and the index to the handler */}
                        <GoogleAddressAutocomplete
                          value={{
                            address: kin.address, // City and Country are IDs or strings, Autocomplete component should handle
                            city: kin.city,
                            country: kin.country,
                            postCode: kin.postCode,
                          }}
                          // Pass a function that calls handleAddressChange with the specific index
                          onAddressChange={(addressDetails) =>
                            handleAddressChange(index, addressDetails)
                          }
                        />
                        <p className="text-xs text-gray-500 mt-2">
                          Start typing address and select from suggestions. City
                          and Country are optional.
                        </p>
                      </div>
                      {/* Phone Number */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                          <Phone size={16} className="text-purple-600" />
                          Phone Number (Primary) *
                        </label>
                        <input
                          type="tel"
                          value={kin.phoneNumber}
                          onChange={(e) =>
                            handleNextOfKinChange(
                              index,
                              "phoneNumber",
                              e.target.value
                            )
                          }
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                          required
                        />
                      </div>
                      {/* Email */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                          <Mail size={16} className="text-purple-600" />
                          Email
                        </label>
                        <input
                          type="email"
                          value={kin.email}
                          onChange={(e) =>
                            handleNextOfKinChange(
                              index,
                              "email",
                              e.target.value
                            )
                          }
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                          placeholder="e.g., sarah@example.com"
                        />
                      </div>
                      {/* Alternate Phone Number */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                          <Phone size={16} className="text-purple-600" />
                          Alternate Phone (Optional)
                        </label>
                        <input
                          type="tel"
                          value={kin.alternatePhoneNumber}
                          onChange={(e) =>
                            handleNextOfKinChange(
                              index,
                              "alternatePhoneNumber",
                              e.target.value
                            )
                          }
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                          placeholder="Optional emergency number"
                        />
                      </div>
                      {/* Occupation */}
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2 flex items-center gap-2">
                          <Briefcase size={16} className="text-purple-600" />
                          Occupation (Optional)
                        </label>
                        <input
                          type="text"
                          value={kin.occupation}
                          onChange={(e) =>
                            handleNextOfKinChange(
                              index,
                              "occupation",
                              e.target.value
                            )
                          }
                          className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                          placeholder="e.g., Accountant"
                        />
                      </div>
                      {/* Primary Checkbox */}
                      <div className="md:col-span-2 pt-4">
                        <label className="inline-flex items-center">
                          <input
                            type="checkbox"
                            checked={kin.isPrimary}
                            onChange={(e) =>
                              handleNextOfKinChange(
                                index,
                                "isPrimary",
                                e.target.checked
                              )
                            }
                            className="form-checkbox h-5 w-5 text-purple-600 rounded border-gray-300 focus:ring-purple-500"
                          />
                          <span className="ml-3 text-sm font-medium text-gray-700 flex items-center gap-1">
                            <Star size={16} className="text-purple-600" />
                            Set as Primary Emergency Contact
                          </span>
                        </label>
                      </div>
                    </div>
                  </div>
                ))}
                {/* Add Next of Kin Button */}
                <button
                  type="button"
                  onClick={addNextOfKinField}
                  className="w-full flex items-center justify-center gap-2 px-6 py-3 border border-dashed border-purple-300 text-purple-700 rounded-xl hover:bg-purple-50 transition-colors duration-200"
                >
                  <Plus size={20} />
                  Add Another Next of Kin
                </button>
              </div>
            </div>
          </div>
          {/* Footer Buttons */}
          <div className="sticky bottom-0 bg-white p-6 -mx-6 mt-6 border-t border-gray-200 flex justify-end gap-3 shadow-t-lg">
            <button
              type="button"
              onClick={onBack}
              className="px-6 py-3 border border-gray-300 rounded-xl text-gray-700 hover:bg-gray-50 transition-colors duration-200"
            >
              Back
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-3 bg-purple-600 text-white font-semibold rounded-xl shadow-lg hover:bg-purple-700 transition-colors duration-200 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? "Saving..." : "Save & Continue"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default NextOfKinStep;
