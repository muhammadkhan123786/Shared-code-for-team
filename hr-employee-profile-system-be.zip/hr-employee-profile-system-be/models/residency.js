const mongoose = require("mongoose");

const residensySchema = new mongoose.Schema(
  {
    employName: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Employee",
      required: true,
    },
    visaType: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "VisaType",
      required: true,
    },
    nationality: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Nationality",
      required: true,
    },

    date: { type: String, required: true },
    docFile: { type: String, required: true },
    isDefault: {
      type: Boolean,
      default: false,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

const Residency = mongoose.model("Residency", residensySchema);

module.exports = Residency;
