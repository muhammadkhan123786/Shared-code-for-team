const mongoose = require("mongoose");

const contractSchema = new mongoose.Schema({
  title: {
    type: String,
    require: true,
    trim: true,
  },
  order: {
    type: Number,
    default: 1,
  },
  isDefault: {
    type: Boolean,
    default: true,
  },
    isActive: {
    type: Boolean,
    default: true,
  },
}, {timestamps: true});

const Contract = mongoose.model('Contract', contractSchema);

module.exports = Contract;
