const mongoose = require("mongoose");

const documentSchema = new mongoose.Schema(
  {
    employName: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Employee",
      required: true,
    },
    documentType: {
      type: String,
      required: true,
      enum: ["passport", "degree", "visa", "cnic", "contract", "other"],
    },
    fileDoc: {
      type: String,
      required: true,
    },
    isDefault: {
      type: Boolean,
      default: false,
    },
    isActive: {
      type: Boolean,
      default: true,
    },
  },
  {
    timestamps: true,
  }
);

const Document = mongoose.model("Document", documentSchema);

module.exports = Document;
