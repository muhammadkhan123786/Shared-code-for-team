const mongoose = require("mongoose");

const templateSchema = new mongoose.Schema(
  {
    subject: {
      type: String,
      required: true,
      trim: true,
    },
    header: {
      type: String,
      required: true,
      trim: true,
    },
    body: {
      type: String,
      required: true,
      trim: true,
    },
    footerFirst: {
      type: String,
      required: true,
      trim: true,
    },
    footerSecond: {
      type: String,
      required: true,
      trim: true,
    },

    document: { type: String, required: true },
    desination: {
      type: mongoose.Schema.Types.ObjectId, // Remains single ObjectId for single select
      ref: "Designation",
    }, // --- FIX: Wrapped the type definition in an array [] ---
    EmployeeStatus: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "EmployeeStatus",
      },
    ],

    isActiveFirst: {
      type: Boolean,
      default: false,
    },
    isActivesecond: {
      type: Boolean,
      default: false,
    },
    isActive: {
      type: Boolean,
      default: false,
    },
  },
  {
    timestamps: true,
  }
);

const Templates = mongoose.model("Template", templateSchema);

module.exports = Templates;
