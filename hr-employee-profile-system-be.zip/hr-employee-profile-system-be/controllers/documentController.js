const Document = require("../models/document");

// Create a new document
exports.createDocument = async (req, res) => {
  try {
    const {
      employName,
      documentType,
      isDefault = false,
      isActive = true,
    } = req.body;

    if (!employName || !documentType) {
      return res
        .status(400)
        .json({ error: "Employee and document type are required" });
    }

    if (
      !req.files ||
      !req.files.documentFiles ||
      req.files.documentFiles.length === 0
    ) {
      return res.status(400).json({ error: "Document file is required" });
    }

    const fileDoc = req.files.documentFiles[0].path.replace(/\\/g, "/");

    const document = new Document({
      employName,
      documentType,
      fileDoc,
      isDefault,
      isActive,
    });

    await document.save();

    res.status(201).json({
      message: "Document created successfully",
      data: document,
    });
  } catch (error) {
    console.error("Error creating document:", error);
    res.status(500).json({ error: "Server error" });
  }
};

// Get all documents
exports.getAllDocuments = async (req, res) => {
  try {
    const documents = await Document.find().populate(
      "employName",
      "firstName middleName lastName"
    );

    res.status(200).json({
      message: "All documents fetched successfully",
      data: documents,
    });
  } catch (error) {
    console.error("Error fetching documents:", error);
    res.status(500).json({ error: "Server error" });
  }
};

// Get a single document by ID
exports.getDocumentById = async (req, res) => {
  try {
    const { id } = req.params;
    const document = await Document.findById(id).populate(
      "employName",
      "firstName middleName lastName"
    );

    if (!document) {
      return res.status(404).json({ error: "Document not found" });
    }

    res.status(200).json({
      message: "Document fetched successfully",
      data: document,
    });
  } catch (error) {
    console.error("Error fetching document:", error);
    res.status(500).json({ error: "Server error" });
  }
};

// Update a document
exports.updateDocument = async (req, res) => {
  try {
    const { id } = req.params;

    // Find existing document
    const document = await Document.findById(id);
    if (!document) {
      return res.status(404).json({ error: "Document not found" });
    }

    // If new file uploaded, replace old one
    let fileDoc = document.fileDoc;
    if (req.files?.documentFiles?.length) {
      fileDoc = req.files.documentFiles[0].path.replace(/\\/g, "/");
    }

    // Merge other fields from req.body
    Object.assign(document, req.body, { fileDoc });

    await document.save();

    res.status(200).json({
      message: "Document updated successfully",
      data: document,
    });
  } catch (error) {
    console.error("Error updating document:", error);
    res.status(500).json({ error: "Server error" });
  }
};

exports.deleteDocument = async (req, res) => {
  try {
    const { id } = req.params;
    const document = await Document.findByIdAndDelete(id);

    if (!document) {
      return res.status(404).json({ error: "Document not found" });
    }

    res.status(200).json({ message: "Document deleted successfully" });
  } catch (error) {
    console.error("Error deleting document:", error);
    res.status(500).json({ error: "Server error" });
  }
};
