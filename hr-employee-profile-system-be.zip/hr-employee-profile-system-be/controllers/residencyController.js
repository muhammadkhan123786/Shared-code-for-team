const Residency = require("../models/residency");

exports.createResidency = async (req, res) => {
  try {
    const {
      employName,
      visaType,
      nationality,
      date,
      isDefault = false,
      isActive = true,
    } = req.body;
    if (!employName || !visaType || !nationality || !date) {
      res.status(400).json({
        error: "all feild are required",
      });
    }
    if (
      !req.files ||
      !req.files.documentFiles ||
      req.files.documentFiles.length === 0
    ) {
      return res.status(400).json({ error: "Document file is required" });
    }
    const docFile = req.files.documentFiles[0].path.replace(/\\/g, "/");
    const residency = new Residency({
      employName,
      visaType,
      nationality,
      date,
      docFile,
      isDefault: isDefault || false,
      isActive: isActive || true,
    });

    await residency.save();

    res.status(201).json({
      message: "Residency created successfully",
      data: residency,
    });
  } catch (error) {
    console.error("Error creating residency:", error);
    res.status(500).json({ error: "Server error" });
  }
};

exports.getAllResidencies = async (req, res) => {
  try {
    const residencies = await Residency.find()
      .populate("employName", "firstName middleName lastName")
      .populate("visaType", "type")
      .populate("nationality", "name");

    res.status(200).json({
      message: "All residencies fetched successfully",
      data: residencies,
    });
  } catch (error) {
    console.error("Error fetching residencies:", error);
    res.status(500).json({ error: "Server error" });
  }
};

exports.getResidencyById = async (req, res) => {
  try {
    const { id } = req.params;
    const residency = await Residency.findById(id)
      .populate("employName", "firstName middleName lastName") // 🔸 only selected fields
      .populate("visaType", "name")
      .populate("nationality", "name");

    if (!residency) {
      return res.status(404).json({ error: "Residency not found" });
    }

    res.status(200).json({
      message: "Residency fetched successfully",
      data: residency,
    });
  } catch (error) {
    console.error("Error fetching residency:", error);
    res.status(500).json({ error: "Server error" });
  }
};

exports.deleteResidency = async (req, res) => {
  try {
    const { id } = req.params;
    const residency = await Residency.findByIdAndDelete(id);

    if (!residency) {
      return res.status(404).json({ error: "Residency not found" });
    }

    res.status(200).json({ message: "Residency deleted successfully" });
  } catch (error) {
    console.error("Error deleting residency:", error);
    res.status(500).json({ error: "Server error" });
  }
};

exports.updateResidency = async (req, res) => {
  try {
    const { id } = req.params;

    // Find existing record
    const residency = await Residency.findById(id);
    if (!residency) {
      return res.status(404).json({ error: "Residency not found" });
    }

    // ✅ If new file uploaded, replace old one
    let docFile = residency.docFile;
    if (req.files?.documentFiles?.length) {
      docFile = req.files.documentFiles[0].path.replace(/\\/g, "/");
    }

    //
    Object.assign(residency, req.body, { docFile });

    await residency.save();

    res.status(200).json({
      message: "Residency updated successfully",
      data: residency,
    });
  } catch (error) {
    console.error("Error updating residency:", error);
    res.status(500).json({ error: "Server error" });
  }
};
