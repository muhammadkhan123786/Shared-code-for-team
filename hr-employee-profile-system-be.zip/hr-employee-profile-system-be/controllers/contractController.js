const Contract = require("../models/Contract.js");


exports.CreateContract = async (req, res) => {
  try {
    const { title, order = 1, isDefault = true, isActive = true } = req.body;

    if (!title) {
      return res.status(400).json({ error: "title is required" });
    }

    const existingContract = await Contract.findOne({
      title: { $regex: new RegExp(`^${title.trim()}$`, "i") },
    });

    if (existingContract) {
      return res.status(400).json({ error: "Contract already exists" });
    }

    const newContract = await Contract.create({
      title: title.trim(),
      order: parseInt(order) || 0,
      isDefault,
      isActive,
    });

    res.status(201).json({
      message: "Contract created successfully",
      data: newContract,
    });
  } catch (error) {
    if (error.code === 11000) {
      return res.status(400).json({ error: "Contract already exists" });
    }
    res.status(500).json({ error: "Failed to create Contract" });
  }
};


exports.getAllContracts = async (req, res) => {
  try {
    const contracts = await Contract.find().sort({ order: 1, createdAt: -1 });
    res.status(200).json({ data: contracts });
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch Contracts" });
  }
};


exports.updateContract = async (req, res) => {
  try {
    const { id } = req.params;
    const { title, order, isDefault, isActive } = req.body;

    const contract = await Contract.findById(id);
    if (!contract) {
      return res.status(404).json({ error: "Contract not found" });
    }

    // Check for duplicate title (case-insensitive)
    if (title) {
      const duplicate = await Contract.findOne({
        _id: { $ne: id },
        title: { $regex: new RegExp(`^${title.trim()}$`, "i") },
      });
      if (duplicate) {
        return res.status(400).json({ error: "Another contract with this title already exists" });
      }
    }

    contract.title = title ? title.trim() : contract.title;
    if (order !== undefined) contract.order = parseInt(order);
    if (isDefault !== undefined) contract.isDefault = isDefault;
    if (isActive !== undefined) contract.isActive = isActive;

    const updatedContract = await contract.save();

    res.status(200).json({
      message: "Contract updated successfully",
      data: updatedContract,
    });
  } catch (error) {
    res.status(500).json({ error: "Failed to update Contract" });
  }
};


exports.deleteContract = async (req, res) => {
  try {
    const { id } = req.params;

    const contract = await Contract.findById(id);
    if (!contract) {
      return res.status(404).json({ error: "Contract not found" });
    }

    await Contract.findByIdAndDelete(id);

    res.status(200).json({ message: "Contract deleted successfully" });
  } catch (error) {
    res.status(500).json({ error: "Failed to delete Contract" });
  }
};
