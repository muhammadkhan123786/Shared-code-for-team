const fs = require("fs");
const path = require("path");
const Templates = require("../models/template");

exports.createTemplate = async (req, res) => {
  try {
    console.log("--- Inside createTemplate Controller ---");
    console.log("req.body:", req.body);
    console.log("req.files:", req.files);

    const {
      subject,
      header,
      body,
      footerFirst,
      footerSecond,
      desination,
      EmployeeStatus,
      isActive,
      isActiveFirst,
      isActivesecond,
    } = req.body;

    const documentFile = req.files?.documentFiles?.[0]?.filename || null;
    let documentUrl = documentFile
      ? `${req.protocol}://${req.get("host")}/uploads/documents/${documentFile}`
      : null;

    // ✅ Convert string "true"/"false" to actual boolean
    const toBool = (val) => val === "true" || val === true;

    if (
      !subject ||
      !header ||
      !body ||
      !footerFirst ||
      !footerSecond ||
      !desination ||
      !EmployeeStatus ||
      !documentFile
    ) {
      if (
        documentFile &&
        fs.existsSync(path.join("uploads/documents", documentFile))
      ) {
        fs.unlinkSync(path.join("uploads/documents", documentFile));
      }
      return res.status(400).json({
        success: false,
        message: "All fields are required.",
      });
    }

    const templateData = {
      subject,
      header,
      body,
      footerFirst,
      footerSecond,
      desination,
      EmployeeStatus,
      document: documentUrl,

      isActive: toBool(isActive),
      isActiveFirst: toBool(isActiveFirst),
      isActivesecond: toBool(isActivesecond),
    };

    console.log("templateData BEFORE saving:", templateData);

    const newTemplate = new Templates(templateData);
    await newTemplate.save();

    res.status(201).json({
      success: true,
      message: "Template created successfully",
      data: newTemplate,
    });
  } catch (error) {
    console.error("❌ Error creating template:", error);

    const uploadedFile = req.files?.documentFiles?.[0]?.filename;
    if (
      uploadedFile &&
      fs.existsSync(path.join("uploads/documents", uploadedFile))
    ) {
      fs.unlinkSync(path.join("uploads/documents", uploadedFile));
    }

    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

exports.getAllTemplates = async (req, res) => {
  try {
    const templates = await Templates.find()
      .populate("desination")
      .populate("EmployeeStatus")
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: templates,
    });
  } catch (error) {
    console.error(" Error fetching templates:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

// ==================== GET BY ID ====================
exports.getTemplateById = async (req, res) => {
  try {
    const { id } = req.params;
    const template = await Templates.findById(id)
      .populate("desination")
      .populate("EmployeeStatus");

    if (!template) {
      return res.status(404).json({
        success: false,
        message: "Template not found",
      });
    }

    res.status(200).json({
      success: true,
      data: template,
    });
  } catch (error) {
    console.error(" Error fetching template:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

exports.updateTemplate = async (req, res) => {
  try {
    const { id } = req.params;
    const template = await Templates.findById(id);
    if (!template) {
      return res
        .status(404)
        .json({ success: false, message: "Template not found" });
    }

    // New uploaded file
    const documentFileName = req.files?.documentFiles?.[0]?.filename;

    // Delete old file if a new one is uploaded
    if (documentFileName && template.document) {
      const oldFilePath = path.resolve(
        "uploads/documents",
        path.basename(template.document)
      );
      if (fs.existsSync(oldFilePath)) fs.unlinkSync(oldFilePath);
    }

    // Construct new document path (if uploaded)
    const documentPath = documentFileName
      ? `${req.protocol}://${req.get(
          "host"
        )}/uploads/documents/${documentFileName}`
      : null;

    // Merge data (keep old document if no new file uploaded)
    template.set({
      ...req.body,
      ...(documentPath && { document: documentPath }),
    });

    await template.save();

    res.status(200).json({
      success: true,
      message: "Template updated successfully",
      data: template,
    });
  } catch (error) {
    console.error("Error updating template:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};

exports.deleteTemplate = async (req, res) => {
  try {
    const { id } = req.params;
    const template = await Templates.findById(id);

    if (!template) {
      return res.status(404).json({
        success: false,
        message: "Template not found",
      });
    }

    // Delete document file if exists
    if (template.document) {
      const filePath = path.join("uploads/documents", template.document);
      if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
    }

    await template.deleteOne();

    res.status(200).json({
      success: true,
      message: "Template deleted successfully",
    });
  } catch (error) {
    console.error(" Error deleting template:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
      error: error.message,
    });
  }
};
