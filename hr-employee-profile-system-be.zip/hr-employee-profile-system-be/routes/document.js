const express = require("express");
const docRouter = express.Router();
const { fileUpload } = require("../middleware/fileUpload");
const {
  createDocument,
  getAllDocuments,
  getDocumentById,
  deleteDocument,
  updateDocument,
} = require("../controllers/documentController");

docRouter.post("/", fileUpload, createDocument);
docRouter.get("/", getAllDocuments);
docRouter.get("/:id", getDocumentById);
docRouter.delete("/:id", deleteDocument);
docRouter.put("/:id", fileUpload, updateDocument);

module.exports = docRouter;
