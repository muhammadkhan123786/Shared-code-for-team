const express = require("express");
const router = express.Router();

const {
  createResidency,
  getAllResidencies,
  getResidencyById,
  deleteResidency,
  updateResidency,
} = require("../controllers/residencyController");
const { fileUpload } = require("../middleware/fileUpload");

router.post("/", fileUpload, createResidency);
router.get("/", getAllResidencies);
router.get("/:id", getResidencyById);
router.delete("/:id", deleteResidency);
router.put("/:id", fileUpload, updateResidency);

module.exports = router;
