const express = require("express");
const {
  createTemplate,
  updateTemplate,
  getAllTemplates,
  getTemplateById,
  deleteTemplate,
} = require("../controllers/template");
const { fileUpload } = require("../middleware/fileUpload");

const tempRoute = express.Router();

// Multer middleware for documentFiles
tempRoute.post("/", fileUpload, createTemplate);
tempRoute.put("/:id", fileUpload, updateTemplate);

tempRoute.get("/", getAllTemplates);

tempRoute.get("/:id", getTemplateById);

tempRoute.delete("/:id", deleteTemplate);

module.exports = tempRoute;
