const express = require("express");
const multer = require("multer");
const path = require("path");
const Employee = require("../models/Employee");
const { protect } = require("../middleware/auth");
const Country = require("../models/Country");
const City = require("../models/City");

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(
      null,
      file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname)
    );
  },
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024, // 5MB limit
  },
  fileFilter: function (req, file, cb) {
    if (
      file.mimetype.startsWith("image/") ||
      file.mimetype === "application/pdf" ||
      file.mimetype === "application/msword" ||
      file.mimetype ===
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
    ) {
      cb(null, true);
    } else {
      cb(new Error("Only images, PDF and Word documents are allowed!"), false);
    }
  },
});

// Enhanced Helper function to parse form data with better file handling
const parseFormData = async (req) => {
  console.log("=== PARSING FORM DATA ===");

  const {
    firstName,
    lastName,
    country,
    city,
    nationality,
    address,
    visaType,
    visaExpiry,
    department,
    jobTitle,
    startDate,
    salary,
    isActive,
  } = req.body;

  console.log(employeeStatus);

  let countryId = country;
  let cityId = city;

  let countryDoc = await Country.findOne({ name: country.trim() });
  console.log("outside the block", countryDoc);
  // ✅ Handle Country
  if (typeof country === "string") {
    let countryDoc = await Country.findOne({ name: country.trim() });
    console.log(countryDoc, "country doc in the last");
    if (!countryDoc) {
      const lastCountry = await Country.findOne().sort({ order: -1 }).limit(1);
      const nextOrder = lastCountry ? lastCountry.order + 1 : 1;

      countryDoc = await Country.create({
        name: country.trim(),
        status: 1,
        isDefault: 0,
        order: nextOrder,
      });

      console.log(`✅ Created new country: ${countryDoc.name}`);
    }

    countryId = countryDoc._id;
  }

  // ✅ Handle City
  if (typeof city === "string") {
    let cityDoc = await City.findOne({ name: city.trim(), countryId });

    if (!cityDoc) {
      const lastCity = await City.findOne().sort({ order: -1 }).limit(1);
      const nextOrder = lastCity ? lastCity.order + 1 : 1;

      cityDoc = await City.create({
        name: city.trim(),
        countryId,
        status: 1,
        isDefault: false,
        order: nextOrder,
      });

      console.log(`✅ Created new city: ${cityDoc.name}`);
    }

    cityId = cityDoc._id;
  }

  // ✅ Parse educations safely
  let educations = [];
  if (req.body.educations) {
    try {
      educations = JSON.parse(req.body.educations);
      console.log(`✅ Parsed ${educations.length} education entries`);
    } catch (error) {
      console.error("❌ Error parsing educations:", error);
    }
  }

  // ✅ Handle uploaded files
  const educationFiles = {};

  if (req.files && req.files.length > 0) {
    req.files.forEach((file) => {
      if (file.fieldname.startsWith("educationFiles[")) {
        const match = file.fieldname.match(/educationFiles\[(\d+)\]/);
        if (match) {
          const index = parseInt(match[1]);
          educationFiles[index] = {
            filename: file.filename,
            originalname: file.originalname,
          };
        }
      } else if (file.fieldname === "educationFiles") {
        for (let i = 0; i < educations.length; i++) {
          if (!educationFiles[i]) {
            educationFiles[i] = {
              filename: file.filename,
              originalname: file.originalname,
            };
            break;
          }
        }
      }
    });
  }

  educations.forEach((edu, index) => {
    if (educationFiles[index]) {
      edu.documentPath = educationFiles[index].filename;
    } else {
      edu.documentPath = edu.documentPath || "";
    }
  });

  // ✅ Visa file
  const visaFile = req.files?.find((file) => file.fieldname === "visaFile");
  const visaDocumentPath = visaFile ? visaFile.filename : "";

  // ✅ Final log
  console.log("=== FINAL PARSED DATA ===");
  console.log("Country ID:", countryId);
  console.log("City ID:", cityId);
  console.log("Educations:", educations);

  // ✅ Return properly mapped data
  return {
    firstName,
    lastName,
    country: countryId,
    city: cityId,
    nationality,
    address,
    visaType,
    visaExpiry,
    visaDocumentPath,
    department,
    jobTitle,
    startDate,
    salary: parseFloat(salary),
    isActive: isActive !== undefined ? isActive === "true" : true,
    educations,
    employeeStatus,
  };
};

// @desc    Get all employees for logged in user
// @route   GET /api/employees
// @access  Private
router.get("/", protect, async (req, res) => {
  try {
    console.log("Fetching employees for user:", req.user.id);

    const employees = await Employee.find({ createdBy: req.user.id }).sort({
      createdAt: -1,
    });

    console.log("Found employees:", employees.length);
    console.log("shahzaib:", employees);

    res.json({
      success: true,
      count: employees.length,
      data: employees,
    });
  } catch (error) {
    console.error("Get employees error:", error);
    res.status(500).json({
      success: false,
      message: "Server error while fetching employees",
    });
  }
});

// @desc    Create new employee
// @route   POST /api/employees
// @access  Private
router.post("/", protect, upload.any(), async (req, res) => {
  try {
    console.log("=== CREATING NEW EMPLOYEE ===");
    const formData = parseFormData(req);

    // Validation
    const requiredFields = [
      "firstName",
      "lastName",
      "country",
      "city",
      "nationality",
      "address",
      "visaType",
      "visaExpiry",
      "department",
      "jobTitle",
      "startDate",
      "salary",
    ];

    for (const field of requiredFields) {
      if (!formData[field]) {
        return res.status(400).json({
          success: false,
          message: `${field} is required`,
        });
      }
    }

    // Validate educations
    if (!formData.educations || formData.educations.length === 0) {
      return res.status(400).json({
        success: false,
        message: "At least one education entry is required",
      });
    }

    for (const edu of formData.educations) {
      if (!edu.degree || !edu.institute || !edu.passingYear) {
        return res.status(400).json({
          success: false,
          message:
            "All education fields (degree, institute, passing year) are required",
        });
      }
    }

    console.log("✅ All validations passed, creating employee...");

    // Create employee
    console.log(formData);
    const employee = await Employee.create({
      ...formData,
      createdBy: req.user.id,
    });

    console.log("✅ Employee created successfully:", employee._id);

    res.status(201).json({
      success: true,
      message: "Employee created successfully",
      data: employee,
    });
  } catch (error) {
    console.error("❌ Create employee error:", error);

    if (error.name === "ValidationError") {
      const messages = Object.values(error.errors).map((err) => err.message);
      return res.status(400).json({
        success: false,
        message: messages.join(", "),
      });
    }

    res.status(500).json({
      success: false,
      message: "Server error while creating employee",
    });
  }
});

// @desc    Update employee
// @route   PATCH /api/employees/:id
// @access  Private
router.patch("/:id", protect, upload.any(), async (req, res) => {
  try {
    console.log("=== UPDATING EMPLOYEE ===");

    let employee = await Employee.findOne({
      _id: req.params.id,
      createdBy: req.user.id,
    });

    if (!employee) {
      return res.status(404).json({
        success: false,
        message: "Employee not found",
      });
    }

    // Parse the incoming form data
    const updateData = parseFormData(req);

    // Start with existing employee data and merge updates
    const finalUpdateData = {};

    // Handle basic fields - only update if provided
    const basicFields = [
      "firstName",
      "lastName",
      "country",
      "city",
      "nationality",
      "address",
      "visaType",
      "visaExpiry",
      "department",
      "jobTitle",
      "startDate",
      "salary",
      "isActive",
    ];

    basicFields.forEach((field) => {
      if (updateData[field] !== undefined) {
        if (field === "salary") {
          finalUpdateData[field] = parseFloat(updateData[field]);
        } else if (field === "isActive") {
          finalUpdateData[field] = updateData[field] === "true";
        } else {
          finalUpdateData[field] = updateData[field];
        }
      }
    });

    // Handle visa document path
    let finalVisaDocumentPath = employee.visaDocumentPath;
    if (updateData.visaDocumentPath !== undefined) {
      finalVisaDocumentPath = updateData.visaDocumentPath;
    }
    finalUpdateData.visaDocumentPath = finalVisaDocumentPath;

    // Handle educations - use the parsed educations directly
    if (updateData.educations && updateData.educations.length > 0) {
      finalUpdateData.educations = updateData.educations;
    }

    // Validate required fields if they are being updated
    const requiredFields = [
      "firstName",
      "lastName",
      "country",
      "city",
      "nationality",
      "address",
      "visaType",
      "visaExpiry",
      "department",
      "jobTitle",
      "startDate",
      "salary",
    ];

    for (const field of requiredFields) {
      if (finalUpdateData[field] !== undefined && !finalUpdateData[field]) {
        return res.status(400).json({
          success: false,
          message: `${field} is required`,
        });
      }
    }

    console.log("✅ Final update data:", finalUpdateData);

    // Update employee
    employee = await Employee.findByIdAndUpdate(
      req.params.id,
      finalUpdateData,
      { new: true, runValidators: true }
    );

    console.log("✅ Employee updated successfully");

    res.json({
      success: true,
      message: "Employee updated successfully",
      data: employee,
    });
  } catch (error) {
    console.error("❌ Update employee error:", error);

    if (error.name === "ValidationError") {
      const messages = Object.values(error.errors).map((err) => err.message);
      return res.status(400).json({
        success: false,
        message: messages.join(", "),
      });
    }

    res.status(500).json({
      success: false,
      message: "Server error while updating employee",
    });
  }
});

// @desc    Delete employee
// @route   DELETE /api/employees/:id
// @access  Private

router.delete("/:id", protect, async (req, res) => {
  console.log("Deleting employee with ID:", req.params.id);
  try {
    let employee = await Employee.findOne({
      _id: req.params.id,
      createdBy: req.user.id,
    });

    if (!employee) {
      return res.status(404).json({
        success: false,
        message: "Employee not found",
      });
    }

    await Employee.findByIdAndDelete(req.params.id);

    res.json({
      success: true,
      message: "Employee deleted successfully",
    });
  } catch (error) {
    console.error("Delete employee error:", error);

    res.status(500).json({
      success: false,
      message: "Server error while deleting employee",
    });
  }
});

// Get employee by ID
router.get("/:id", protect, async (req, res) => {
  try {
    const employee = await Employee.findOne({
      _id: req.params.id,
      createdBy: req.user.id,
    });

    if (!employee) {
      return res.status(404).json({
        success: false,
        message: "Employee not found",
      });
    }

    res.json({
      success: true,
      data: employee,
    });
  } catch (error) {
    console.error("❌ Get employee by ID error:", error);
    res.status(500).json({
      success: false,
      message: "Server error while fetching employee",
    });
  }
});

// Add this to serve uploaded files
router.use("/uploads", express.static(path.join(__dirname, "../uploads")));

module.exports = router;
