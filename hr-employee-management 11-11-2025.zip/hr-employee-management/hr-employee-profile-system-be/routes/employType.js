const express = require("express");
const {
  createEmploytype,
  getAllEmploytypes,
  updateEmploytype,
  deleteEmploytype,
} = require("../controllers/employTypeController");

const router = express.Router();

router.post("/", createEmploytype);
router.get("/", getAllEmploytypes);
router.put("/:id", updateEmploytype);
router.delete("/:id", deleteEmploytype);

module.exports = router;
