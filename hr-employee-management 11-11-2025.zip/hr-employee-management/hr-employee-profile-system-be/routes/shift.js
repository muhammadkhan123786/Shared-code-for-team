const express = require("express");
const {
  createShift,
  getAllShifts,
  updateShift,
  deleteShift,
} = require("../controllers/shiftController");

const shiftroute = express.Router();

shiftroute.post("/", createShift);
shiftroute.get("/", getAllShifts);
shiftroute.put("/:id", updateShift);
shiftroute.delete("/:id", deleteShift);

module.exports = shiftroute;
