const mongoose = require("mongoose");

const shiftSchema = new mongoose.Schema(
  {
    description: {
      type: String,
      required: true,
      unique: true,
      trim: true,
    },

    timing: {
      startTime: {
        type: String, // example: "09:00 AM"
        required: true,
      },
      endTime: {
        type: String, // example: "05:00 PM"
        required: true,
      },
    },
    order: {
      type: Number,
      default: 1,
    },
    isDefault: {
      type: Boolean,
      required: true,
      default: false,
    },
    isActive: {
      type: Boolean,
      required: true,
      default: true,
    },
  },
  { timestamps: true }
);
module.exports = mongoose.model("Shift", shiftSchema);
