import React from "react";

const ShowEmployDataID = () => {
  return <div>ShowEmployDataID</div>;
};

export default ShowEmployDataID;
