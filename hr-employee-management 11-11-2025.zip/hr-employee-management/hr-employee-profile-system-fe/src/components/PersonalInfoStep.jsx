// components/steps/PersonalInfoStep.jsx

import { useState, useEffect, useRef, useCallback } from "react";

import { employeeAPI } from "@/services/employee";
import { toast } from "sonner";
import { Upload, FileText, X, Camera } from "lucide-react";
import GoogleAddressAutocomplete from "@/components/AddressAutoComplete";
const BASE_URL =
  import.meta.env.VITE_API_BASE_URL?.replace("/api", "") ||
  "http://localhost:5001";

const PersonalInfoStep = ({
  employeeId,
  setEmployeeId,
  onClose,
  setCurrentStep,
  titles = [],
  nationalities = [],
  visaTypes = [],
}) => {
  console.log(titles);
  const [formData, setFormData] = useState({
    title: "",
    firstName: "",
    middleName: "",
    lastName: "",
    dateOfBirth: "",
    placeOfBirth: "",
    gender: "",
    bloodGroup: "",
    employeeStatus: "",
    maritalStatus: "",
    contactNo: "",
    email: "",
    country: "",
    city: "",
    nationality: "",
    address: "",
    postCode: "",
    visaType: "",
    visaExpiry: "",
    nationalInsuranceNumber: "",
    isActive: true,
  });

  const [profilePicture, setProfilePicture] = useState(null);
  const [profilePictureFile, setProfilePictureFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [imageError, setImageError] = useState(false);
  const [emailError, setEmailError] = useState("");

  const fileInputRef = useRef(null);
  const [employeeStatuses, setEmployeeStatuses] = useState([]);
  const [loadingStatuses, setLoadingStatuses] = useState(false);

  // --- useEffect to Fetch Employee Statuses ---
  useEffect(() => {
    const fetchStatuses = async () => {
      setLoadingStatuses(true);
      try {
        const res = await fetch(`${BASE_URL}/api/employee-status`);
        const data = await res.json();
        if (data.statuses) {
          setEmployeeStatuses(data.statuses);
        }
      } catch (error) {
        console.error("Error fetching employee statuses:", error);
      } finally {
        setLoadingStatuses(false);
      }
    };
    fetchStatuses();
  }, []);

  // --- Constants (Simplified/Retained from input) ---
  const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"];
  const MARITAL_STATUSES = [
    "Single",
    "Married",
    "Divorced",
    "Widowed",
    "Separated",
  ];
  const GENDERS = ["Male", "Female", "Other"];
  const today = new Date().toISOString().split("T")[0];

  // --- Helper Functions ---
  const getImageSrc = () => {
    if (imageError || !profilePicture) {
      return "/default-avatar.png";
    }

    if (profilePicture.startsWith("blob:")) {
      return profilePicture;
    }

    return profilePicture.startsWith("http")
      ? profilePicture
      : `${BASE_URL}/uploads/profile-pictures/${profilePicture}`;
  };

  const loadEmployeeData = useCallback(async () => {
    try {
      const response = await employeeAPI.getEmployeeById(employeeId);
      if (response.success) {
        const employee = response.data;
        console.log(response.data);

        // Logic to extract _id for linked fields like title and visaType
        setFormData({
          title: employee.title?._id || employee.title || "",
          firstName: employee.firstName || "",
          middleName: employee.middleName || "",
          lastName: employee.lastName || "",
          dateOfBirth: employee.dateOfBirth
            ? employee.dateOfBirth.split("T")[0]
            : "",
          placeOfBirth: employee.placeOfBirth || "",
          gender: employee.gender || "",
          bloodGroup: employee.bloodGroup || "",
          maritalStatus: employee.maritalStatus || "",

          employeeStatus:
            employee.EmployeeStatus?._id || employee.EmployeeStatus || "",
          contactNo: employee.contactNo || "",
          email: employee.email || "",
          country: employee.country?.name || employee.country || "",
          city: employee.city?.name || employee.city || "",
          nationality: employee.nationality || "",
          address: employee.address || "",
          postCode: employee.postCode || "",
          visaType: employee.visaType?._id || employee.visaType || "",
          visaExpiry: employee.visaExpiry
            ? employee.visaExpiry.split("T")[0]
            : "",
          nationalInsuranceNumber: employee.nationalInsuranceNumber || "",
          isActive: employee.isActive ?? true,
        });

        if (employee.profilePicture) {
          setProfilePicture(employee.profilePicture);
          setImageError(false); // Reset error state when loading new image
        } else {
          setProfilePicture(null);
          setImageError(false);
        }
      }
    } catch (error) {
      console.error("Error loading employee data:", error);
      toast.error("Failed to load employee data.");
    }
  }, [employeeId]);

  const handleInputChange = (e) => {
    // This handler is now simplified as AddressAutoComplete handles its own state logic.
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleEmailChange = (e) => {
    const { value } = e.target;
    handleInputChange(e);

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (value && !emailRegex.test(value)) {
      setEmailError("Please enter a valid email address.");
    } else {
      setEmailError("");
    }
  };

  // ✅ Address Change Handler for GoogleAddressAutocomplete Component
  // This expects the shape { address, country, city, postCode } from the child component
  // PersonalInfoStep.jsx

  // ✅ Address Change Handler for GoogleAddressAutocomplete Component
  // This expects the shape { address, country, city, postCode } from the child component
  const handleAddressChange = (addressDetails) => {
    if (!addressDetails) return;

    // 1. Logic to safely extract the ID string:
    // Check if addressDetails.country is an object and not null. If so, use its _id property.
    // Otherwise, use the value directly (assuming it's already an ID string or a name string).

    const countryValue =
      typeof addressDetails.country === "object" &&
      addressDetails.country !== null
        ? addressDetails.country._id
        : addressDetails.country;

    const cityValue =
      typeof addressDetails.city === "object" && addressDetails.city !== null
        ? addressDetails.city._id
        : addressDetails.city;

    // 2. Update the state with the extracted ID strings
    setFormData((prev) => ({
      ...prev,
      address: addressDetails.address || "",

      // ⭐️ FIX: Now we save the extracted ID string (countryValue/cityValue)
      country: countryValue || "",
      city: cityValue || "",

      postCode: addressDetails.postCode || "",
    }));
  };

  // ... (rest of the component logic, profile picture handlers, and handleSubmit are unchanged)

  const handleProfilePictureChange = (e) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      const validTypes = ["image/jpeg", "image/jpg", "image/png", "image/webp"];
      if (!validTypes.includes(file.type)) {
        toast.error("Please select a valid image file (JPEG, PNG, WebP)");
        return;
      }
      // Validate file size (2MB)
      if (file.size > 2 * 1024 * 1024) {
        toast.error("File size must be less than 2MB");
        return;
      }

      setProfilePictureFile(file);
      const objectUrl = URL.createObjectURL(file);
      setProfilePicture(objectUrl);
      setImageError(false); // Reset error state for new image
    }
  };

  const handleRemoveProfilePicture = () => {
    setProfilePicture(null);
    setProfilePictureFile(null);
    setImageError(false);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
  };

  const handleImageError = () => {
    setImageError(true);
  };

  // PersonalInfoStep.jsx

  const handleSubmit = async (e) => {
    e.preventDefault();

    console.log("Submitting formData:", formData);
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (formData.email && !emailRegex.test(formData.email)) {
      toast.error("Please enter a valid email address.");
      return;
    }

    setLoading(true);

    try {
      // 1. 💡 CRITICAL STEP: CLEAN THE ADDRESS DATA IN THE FORMDATA OBJECT
      const cleanedFormData = { ...formData };

      const cleanAddressField = (value) => {
        // Agar value Object hai (jo CastError de raha hai), toh uski _id nikaalenge.
        if (typeof value === "object" && value !== null && value._id) {
          return value._id;
        }
        // Agar value empty string hai, toh null return karein (Mongoose ko pasand hai).
        if (value === "") return null;

        // Warna, value ko jaisa hai waisa hi rakhenge (assuming it's an ID string or Name string).
        return value;
      };

      cleanedFormData.country = cleanAddressField(cleanedFormData.country);
      cleanedFormData.city = cleanAddressField(cleanedFormData.city);

      // 2. Prepare FormData (Used for file upload)
      const submitData = new FormData();

      // 3. Append cleaned data to FormData
      Object.keys(cleanedFormData).forEach((key) => {
        const value = cleanedFormData[key];

        // Null ya undefined values ko skip karein.
        if (value !== null && value !== undefined) {
          // Agar country/city Object ID string hai, toh use directly append karein.
          // Aapka backend controller (jo `$set` use karta hai) is ID string ko accept karega.
          // Note: Is logic mein hum 'country[name]' wala tareeka use nahi kar rahe hain.
          // Hum maan rahe hain ki backend mein ID jaani chahiye (jo ObjectId schema ki requirement hai).
          submitData.append(key, value);
        }
      });

      // 4. Append the file
      if (profilePictureFile) {
        submitData.append("profilePicture", profilePictureFile);
      }

      console.log(
        "Submitting cleaned data (check Network tab for payload):",
        cleanedFormData
      );

      let response;
      if (employeeId) {
        // ⚠️ Ensure your updateEmployee API handles FormData correctly (multipart/form-data)
        response = await employeeAPI.updateEmployee(employeeId, submitData);
      } else {
        response = await employeeAPI.createEmployee(submitData);
      }

      if (response.success) {
        toast.success(
          `Employee ${employeeId ? "updated" : "created"} successfully`
        );
        setEmployeeId(response.data._id);
        setCurrentStep(2);
        console.log("Personal Form Submit:", response.data._id);
      } else {
        // ... (Error handling)
        toast.error(
          response.message ||
            `Failed to ${employeeId ? "update" : "create"} employee`
        );
      }
    } catch (error) {
      console.error("Error submitting form:", error);
      const errorMessage =
        error.response?.data?.error || error.message || "Error submitting form";
      toast.error(errorMessage);
    } finally {
      setLoading(false);
    }
  };

  // --- Effects ---
  useEffect(() => {
    return () => {
      if (profilePicture && profilePicture.startsWith("blob:")) {
        URL.revokeObjectURL(profilePicture);
      }
    };
  }, [profilePicture]);

  useEffect(() => {
    if (employeeId) {
      loadEmployeeData();
    }
  }, [employeeId, loadEmployeeData]);

  // --- Render ---
  return (
    <div className="bg-black bg-opacity-50 relative backdrop-blur-sm flex items-center justify-center z-50 p-4 overflow-auto">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-7xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-purple-800 p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-white">
                {employeeId
                  ? "Edit Personal Information"
                  : "Personal Information"}
              </h2>
              <p className="text-purple-100 mt-1">
                {employeeId
                  ? "Update employee personal details"
                  : "Add new employee personal details"}
              </p>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-purple-200 transition-colors p-2 rounded-full hover:bg-white hover:bg-opacity-20"
            >
              <X size={24} />
            </button>
          </div>
        </div>
        <form
          onSubmit={handleSubmit}
          className="p-6 overflow-y-auto max-h-[calc(90vh-120px)]"
        >
          <div className="space-y-8">
            {/* Profile Picture Upload */}
            <div className="bg-gray-50 rounded-xl p-6 border border-gray-200">
              <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
                <Camera size={20} className="text-purple-600" />
                Profile Picture
              </h4>
              <div className="flex items-center gap-8">
                <div className="flex-shrink-0 relative">
                  <div className="relative">
                    <img
                      src={getImageSrc()}
                      alt="Profile preview"
                      className="w-32 h-32 rounded-2xl object-cover border-4 border-white shadow-lg"
                      onError={handleImageError}
                    />
                    <div className="absolute inset-0 rounded-2xl border-2 border-purple-200"></div>
                    {/* Remove button for uploaded images */}
                    {profilePicture && (
                      <button
                        type="button"
                        onClick={handleRemoveProfilePicture}
                        className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                        title="Remove photo"
                      >
                        <X size={16} />
                      </button>
                    )}
                  </div>
                </div>
                <div className="flex-1 space-y-3">
                  <label className="flex items-center gap-3 px-6 py-3 bg-purple-600 text-white rounded-xl hover:bg-purple-700 cursor-pointer transition-all duration-200 w-fit shadow-md hover:shadow-lg">
                    <Upload size={18} />
                    {profilePicture ? "Change Picture" : "Upload Picture"}
                    <input
                      ref={fileInputRef}
                      type="file"
                      className="hidden"
                      accept=".jpg,.jpeg,.png,.webp"
                      onChange={handleProfilePictureChange}
                    />
                  </label>
                  <p className="text-sm text-gray-600">
                    Recommended: Square image, 500x500px, Max 2MB
                    <br />
                    <span className="text-xs text-gray-500">
                      JPEG, PNG, WebP formats supported
                    </span>
                  </p>
                </div>
                <div className="bg-white rounded-lg p-4 border border-gray-200">
                  <div className="flex items-center">
                    <input
                      type="checkbox"
                      name="isActive"
                      checked={formData.isActive || false}
                      onChange={handleInputChange}
                      className="h-5 w-5 text-purple-600 focus:ring-purple-500 border-gray-300 rounded"
                    />
                    <label className="ml-3 block text-sm font-medium text-gray-900">
                      Active Employee
                    </label>
                  </div>
                </div>
              </div>
            </div>
            {/* Personal Details Section */}
            <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                <h4 className="text-lg font-semibold text-gray-900">
                  Personal Details
                </h4>
              </div>
              <div className="p-6">
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {/* Title */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Title *
                    </label>
                    <select
                      name="title"
                      value={formData.title}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                      required
                    >
                      <option value="">Select Title</option>
                      {titles.length > 0 &&
                        titles.map((title) => (
                          <option key={title._id} value={title._id}>
                            {title.title}
                          </option>
                        ))}
                    </select>
                  </div>
                  {/* First Name */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      First Name *
                    </label>
                    <input
                      type="text"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                      required
                    />
                  </div>
                  {/* Middle Name */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Middle Name
                    </label>
                    <input
                      type="text"
                      name="middleName"
                      value={formData.middleName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                    />
                  </div>
                  {/* Last Name */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Last Name *
                    </label>
                    <input
                      type="text"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                      required
                    />
                  </div>
                  {/* Date of Birth */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Date of Birth *
                    </label>
                    <input
                      type="date"
                      name="dateOfBirth"
                      value={formData.dateOfBirth}
                      onChange={handleInputChange}
                      max={today}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                    />
                  </div>
                  {/* Place of Birth */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Place of Birth *
                    </label>
                    <input
                      type="text"
                      name="placeOfBirth"
                      value={formData.placeOfBirth}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                      placeholder="e.g., London, UK"
                    />
                  </div>
                  {/* Gender */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Gender *
                    </label>
                    <select
                      name="gender"
                      value={formData.gender}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                      required
                    >
                      <option value="">Select Gender</option>
                      {GENDERS.map((gender) => (
                        <option key={gender} value={gender}>
                          {gender}
                        </option>
                      ))}
                    </select>
                  </div>
                  {/* Blood Group */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Blood Group
                    </label>
                    <select
                      name="bloodGroup"
                      value={formData.bloodGroup}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                    >
                      <option value="">Select Blood Group</option>
                      {BLOOD_GROUPS.map((group) => (
                        <option key={group} value={group}>
                          {group}
                        </option>
                      ))}
                    </select>
                  </div>
                  {/* Marital Status */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Marital Status
                    </label>
                    <select
                      name="maritalStatus"
                      value={formData.maritalStatus}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                      required
                    >
                      <option value="">Select Marital Status</option>
                      {MARITAL_STATUSES.map((status) => (
                        <option key={status} value={status}>
                          {status}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Employee Status
                    </label>
                    <select
                      name="employeeStatus"
                      value={formData.employeeStatus || ""}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                      required
                    >
                      <option value="">Select Employee Status</option>
                      {loadingStatuses ? (
                        <option>Loading...</option>
                      ) : (
                        employeeStatuses.map((item) => (
                          <option key={item._id} value={item._id}>
                            {item.status}
                          </option>
                        ))
                      )}
                    </select>
                  </div>

                  {/* Nationality */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Nationality *
                    </label>
                    <select
                      name="nationality"
                      value={formData.nationality}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                      required
                    >
                      <option value="">Select Nationality</option>
                      {/* Assuming nationalities prop is an array of objects: { _id, name } */}
                      {nationalities.map((nationality) => (
                        <option key={nationality._id} value={nationality.name}>
                          {nationality.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  {/* National Insurance Number */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      National Insurance Number *
                    </label>
                    <input
                      type="text"
                      name="nationalInsuranceNumber"
                      value={formData.nationalInsuranceNumber || ""}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                      required
                    />
                  </div>
                </div>
              </div>
            </div>
            {/* Contact Information Section */}
            <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                <h4 className="text-lg font-semibold text-gray-900">
                  Contact Information
                </h4>
              </div>
              <div className="p-6">
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Email Address */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleEmailChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                      placeholder="e.g., john.doe@company.com"
                      required
                    />
                    {emailError && (
                      <p className="text-red-500 text-sm mt-2 flex items-center gap-1">
                        <span>⚠</span> {emailError}
                      </p>
                    )}
                  </div>
                  {/* Contact No */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Contact No. *
                    </label>
                    <input
                      type="tel"
                      name="contactNo"
                      value={formData.contactNo}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                      placeholder="e.g., +44 20 7946 0958"
                      required
                    />
                  </div>
                  {/* Address */}
                  <div className="md:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Address *
                    </label>

                    <GoogleAddressAutocomplete
                      value={{
                        address: formData.address,
                        city: formData.city,
                        country: formData.country,
                        postCode: formData.postCode,
                      }}
                      onAddressChange={handleAddressChange}
                    />

                    <p className="text-xs text-gray-500 mt-2">
                      Start typing your address and select from suggestions (or
                      choose manual entry inside the component)
                    </p>
                  </div>
                </div>
              </div>
            </div>
            {/* Visa Information */}
            <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
              <div className="bg-gray-50 px-6 py-4 border-b border-gray-200">
                <h4 className="text-lg font-semibold text-gray-900">
                  Visa Information
                </h4>
              </div>
              <div className="p-6">
                <div className="grid md:grid-cols-2 gap-6">
                  {/* Visa Type */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Visa Type
                    </label>
                    <select
                      name="visaType"
                      value={formData.visaType}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                    >
                      <option value="">Select Visa Type</option>
                      {visaTypes.map((visa) => (
                        <option key={visa._id} value={visa._id}>
                          {visa.type}
                        </option>
                      ))}
                    </select>
                  </div>
                  {/* Visa Expiry */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Visa Expiry Date
                    </label>
                    <input
                      type="date"
                      name="visaExpiry"
                      value={formData.visaExpiry}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-2 focus:ring-purple-500 focus:border-purple-500 transition-all duration-200"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
          {/* Footer/Action Buttons */}
          <div className="mt-8 pt-6 border-t border-gray-200 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-6 py-3 bg-gray-200 text-gray-800 rounded-xl font-semibold hover:bg-gray-300 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-6 py-3 bg-purple-600 text-white rounded-xl font-semibold hover:bg-purple-700 transition-colors disabled:bg-purple-400 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {loading ? (
                <>
                  <svg
                    className="animate-spin h-5 w-5 text-white"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="none"
                    viewBox="0 0 24 24"
                  >
                    <circle
                      className="opacity-25"
                      cx="12"
                      cy="12"
                      r="10"
                      stroke="currentColor"
                      strokeWidth="4"
                    ></circle>
                    <path
                      className="opacity-75"
                      fill="currentColor"
                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
                    ></path>
                  </svg>
                  {employeeId ? "Updating..." : "Creating..."}
                </>
              ) : (
                `Save & Continue`
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PersonalInfoStep;
