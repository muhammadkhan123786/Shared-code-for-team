import React, { useState, useEffect, useMemo, useCallback } from "react";
import axios from "axios";
import Editor from "react-simple-wysiwyg";
import {
  Search,
  Edit,
  Trash2,
  X,
  Save,
  Plus,
  Eye,
  AlertCircle,
  CheckCircle,
  Info,
  Clock,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";

// Initial state for new template
const INITIAL_TEMPLATE = {
  subject: "",
  header: "",
  body: "",
  footerFirst: "",
  footerSecond: "",
  // Using the server's typo 'desination' for key consistency
  desination: "", // Single select string (name of designation)
  EmployeeStatus: [], // Multi-select array of strings (names of statuses)
  document: null,
  isActiveFirst: false,
  isActivesecond: false,
  isActive: false,
};

// --- Utility function to get display value (for rendering only) ---
const getDisplayValue = (field) => {
  if (!field) return "N/A";
  // If it's an object, check for a common name property ('title' for Designation, 'status' for EmployeeStatus)
  if (typeof field === "object" && !Array.isArray(field)) {
    return field.title || field.status || field.name || "Populated Object";
  }
  // If it's an array, handle array of strings or array of objects
  if (Array.isArray(field)) {
    return field.map((item) => getDisplayValue(item)).join(", ");
  }
  // Otherwise, treat as a primitive string
  return String(field);
};

// --- Checkbox Component ---
const FormCheckbox = ({ label, name, isChecked, onChange }) => (
  <div className="flex flex-col items-center justify-center space-y-2">
    <label htmlFor={name} className="font-medium text-gray-700 text-sm">
      {label}
    </label>
    <input
      id={name}
      name={name}
      type="checkbox"
      checked={isChecked}
      onChange={onChange}
      className="h-5 w-5 text-[#8C00FF] rounded border-gray-300 focus:ring-[#8C00FF]"
    />
  </div>
);

// --- Input Component ---
const FormInput = ({
  label,
  name,
  value,
  onChange,
  type = "text",
  className = "",
}) => (
  <div className={`flex flex-col ${className}`}>
    <label htmlFor={name} className="mb-1 font-medium text-gray-700">
      {label}
    </label>
    <input
      id={name}
      name={name}
      type={type}
      // Ensure value is a string for input field
      value={typeof value === "object" ? "" : value}
      onChange={onChange}
      className="p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF]"
    />
  </div>
);

// --- Textarea Component ---
const FormTextarea = ({ label, name, value, onChange, className = "" }) => (
  <div className={`flex flex-col ${className}`}>
    <label htmlFor={name} className="mb-1 font-medium text-gray-700">
      {label}
    </label>
    <textarea
      id={name}
      name={name}
      value={value}
      onChange={onChange}
      className="p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF] h-32 resize-none"
    />
  </div>
);

// --- Single Select Component (For Designation) ---
const FormSelect = ({
  label,
  name,
  value,
  onChange,
  options,
  className = "",
}) => {
  // If 'value' is an object (populated), we need to select the option using its string value (title/name)
  const selectedValue =
    typeof value === "object" && value !== null
      ? getDisplayValue(value) // Get the string name from the object
      : value; // Use the primitive string

  return (
    <div className={`flex flex-col ${className}`}>
      <label htmlFor={name} className="mb-1 font-medium text-gray-700">
        {label}
      </label>
      <select
        id={name}
        name={name}
        // Use the extracted string value for the select field
        value={selectedValue}
        onChange={onChange}
        className="p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF]"
      >
        <option value="">Select {label}</option>
        {/* Options array is assumed to contain objects like { name: '...', _id: '...' } */}
        {options.map((option) => (
          // CRITICAL: The value here must be the NAME, as this is what's stored in state.
          // The submit handler will convert this name back to the _id.
          <option key={option._id} value={option.name}>
            {option.name}
          </option>
        ))}
      </select>
    </div>
  );
};

// --- Multi Select Component (For Employee Status) ---
const FormMultiSelect = ({
  label,
  name,
  value,
  onChange,
  options,
  className = "",
}) => {
  // Normalize value array: If it contains objects (populated), map them to their string names for the select element
  const normalizedValue = useMemo(() => {
    if (!Array.isArray(value)) return [];
    return value.map((item) =>
      typeof item === "object" && item !== null ? getDisplayValue(item) : item
    );
  }, [value]);

  const handleSelectChange = (e) => {
    // Collect all selected option values (which are strings/names) into an array
    const selectedOptions = Array.from(e.target.selectedOptions).map(
      (option) => option.value
    );
    onChange({ target: { name, value: selectedOptions } });
  };

  return (
    <div className={`flex flex-col ${className}`}>
      <label htmlFor={name} className="mb-1 font-medium text-gray-700">
        {label}
      </label>
      <select
        id={name}
        name={name}
        multiple
        // Use the normalized array of strings (names) for the select field
        value={normalizedValue}
        onChange={handleSelectChange}
        className="p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF] h-32"
      >
        {options.map((option) => (
          // CRITICAL: The value here must be the NAME, as this is what's stored in state.
          // The submit handler will convert this name back to the _id.
          <option key={option._id} value={option.name}>
            {option.name}
          </option>
        ))}
      </select>
      <p className="text-xs text-gray-500 mt-1">
        Hold **Ctrl** or **Cmd** to select multiple statuses.
      </p>
    </div>
  );
};

// --- Notification Component ---
const Notification = ({ notification, onDismiss }) => {
  if (!notification.message) return null;
  const { message, type } = notification;
  const isError = type === "error";
  const bgColor = isError ? "bg-red-500" : "bg-green-500";
  const Icon = isError ? AlertCircle : CheckCircle;

  return (
    <div
      className={`fixed top-5 right-5 ${bgColor} text-white p-4 rounded-xl shadow-lg flex items-center gap-3 z-50`}
    >
      <Icon size={20} />
      <span>{message}</span>
      <button onClick={onDismiss} className="ml-2 text-white hover:opacity-75">
        <X size={18} />
      </button>
    </div>
  );
};

// --- View Modal ---
const ViewTemplateModal = ({ template, onClose }) => (
  <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-40 p-4">
    <div className="bg-white rounded-2xl shadow-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-xl font-semibold text-[#450693]">View Template</h3>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-600">
          <X size={24} />
        </button>
      </div>
      <div className="space-y-4">
        {Object.entries(template).map(([key, value]) => {
          if (key === "_id" || key === "__v" || key === "document") return null;

          let displayValue;
          if (Array.isArray(value)) {
            if (value.length > 0 && typeof value[0] === "object") {
              // Agar objects ka array hai
              displayValue = value
                .map((v) => v.name || v.status || "N/A")
                .join(", ");
            } else {
              displayValue = value.join(", ");
            }
          } else if (typeof value === "boolean") {
            displayValue = value ? "Yes" : "No";
          } else if (
            typeof value === "object" &&
            value !== null &&
            value.title
          ) {
            displayValue = value.title;
          } else {
            displayValue = value;
          }

          const displayKey = key.replace(/([A-Z])/g, " $1").trim();

          return (
            <div key={key} className="grid grid-cols-3 gap-2">
              <strong className="text-gray-600 capitalize col-span-1">
                {displayKey}:
              </strong>
              <div className="text-gray-800 col-span-2 break-words">
                {displayValue}
              </div>
            </div>
          );
        })}

        {/* Display Document as image */}
        {template.document && (
          <div className="grid grid-cols-3 gap-2">
            <strong className="text-gray-600 capitalize col-span-1">
              Document:
            </strong>
            <div className="text-gray-800 col-span-2">
              <a
                href={template.document}
                target="_blank"
                rel="noopener noreferrer"
              >
                <img
                  src={template.document}
                  alt="Template Document"
                  className="max-w-xs max-h-48 object-cover rounded-md shadow"
                />
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  </div>
);

// --- Edit Modal ---
const EditTemplateModal = ({
  template,
  onSave,
  onClose,
  designations,
  employeeStatuses,
}) => {
  // Deep clone template to initialize formData correctly, especially for EmployeeStatus array
  const [formData, setFormData] = useState(() => {
    // If the template has populated objects (IDs/Names), map them to strings (Names) for the select fields
    const normalizedStatus = Array.isArray(template.EmployeeStatus)
      ? template.EmployeeStatus.map((item) => getDisplayValue(item))
      : [];
    const normalizedDesignation = getDisplayValue(template.desination);

    return {
      ...template,
      EmployeeStatus: normalizedStatus,
      desination: normalizedDesignation,
    };
  });
  const [documentFile, setDocumentFile] = useState(null);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    if (type === "checkbox") {
      setFormData((prev) => ({ ...prev, [name]: checked }));
    } else {
      setFormData((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleFileChange = (e) => setDocumentFile(e.target.files[0]);

  const handleSubmit = (e) => {
    e.preventDefault();

    // Agar user ne file select nahi ki, to existing document path use karo
    const payload = {
      ...formData,
      document: documentFile || formData.document, // existing document fallback
    };

    onSave(payload, documentFile); // documentFile optional, backend me check karein
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-40 p-4">
      <form
        onSubmit={handleSubmit}
        className="bg-white rounded-2xl shadow-lg p-6 w-full max-w-3xl max-h-[90vh] overflow-y-auto"
      >
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-semibold text-[#450693]">
            Edit Template
          </h3>
          <button
            type="button"
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            <X size={24} />
          </button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormInput
            label="Subject*"
            name="subject"
            value={formData.subject}
            onChange={handleChange}
            className="md:col-span-2"
          />
          <FormInput
            label="Header*"
            name="header"
            value={formData.header}
            onChange={handleChange}
          />
          {/* FormSelect uses the NAME string stored in formData.desination */}
          <FormSelect
            label="Designation*"
            name="desination"
            value={formData.desination}
            onChange={handleChange}
            options={designations}
          />
          <FormTextarea
            label="Body*"
            name="body"
            value={formData.body}
            onChange={handleChange}
            className="md:col-span-2"
          />
          <FormInput
            label="Footer 1*"
            name="footerFirst"
            value={formData.footerFirst}
            onChange={handleChange}
          />
          <FormInput
            label="Footer 2*"
            name="footerSecond"
            value={formData.footerSecond}
            onChange={handleChange}
          />
          {/* Employee Status (Multi Select) uses the array of NAME strings stored in formData.EmployeeStatus */}
          <FormMultiSelect
            label="Employee Status*"
            name="EmployeeStatus"
            value={formData.EmployeeStatus}
            onChange={handleChange}
            options={employeeStatuses}
          />

          <div className="flex flex-col">
            <label
              htmlFor="document"
              className="mb-1 font-medium text-gray-700"
            >
              Update Document (Pic)*
            </label>
            <input
              type="file"
              id="document"
              onChange={handleFileChange}
              className="p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#8C00FF] file:mr-2 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-[#8C00FF] file:text-white hover:file:bg-[#7a00e0]"
            />

            {/* Preview existing image if no new file selected */}
            {formData.document && !documentFile && (
              <div className="mt-2 flex items-center space-x-2">
                <img
                  src={formData.document} // ye backend se URL hona chahiye
                  alt="Current Document"
                  className="w-16 h-16 object-cover rounded"
                />
                <span className="text-sm text-gray-500 truncate">
                  Current: {formData.document.split("/").pop()}
                </span>
              </div>
            )}

            {/* Preview new file if selected */}
            {documentFile && (
              <div className="mt-2 flex items-center space-x-2">
                <img
                  src={URL.createObjectURL(documentFile)}
                  alt="New Document"
                  className="w-16 h-16 object-cover rounded"
                />
                <span className="text-sm text-gray-500 truncate">
                  New: {documentFile.name}
                </span>
              </div>
            )}
          </div>
        </div>
        <div className="flex items-center justify-around gap-4 mt-6 pt-4 border-t">
          {/* Checkboxes */}
          <FormCheckbox
            label="Is Active First"
            name="isActiveFirst"
            isChecked={formData.isActiveFirst}
            onChange={handleChange}
          />
          <FormCheckbox
            label="Is Active Second"
            name="isActivesecond"
            isChecked={formData.isActivesecond}
            onChange={handleChange}
          />
          <FormCheckbox
            label="Is Active"
            name="isActive"
            isChecked={formData.isActive}
            onChange={handleChange}
          />
        </div>
        <div className="flex justify-end gap-4 mt-8">
          <button
            type="button"
            onClick={onClose}
            className="px-6 py-3 rounded-xl font-semibold bg-gray-200 text-gray-700 hover:bg-gray-300 transition-colors"
          >
            Cancel
          </button>
          <button
            type="submit"
            className="flex items-center gap-2 bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] text-white px-6 py-3 rounded-xl font-semibold hover:opacity-90 transition-opacity"
          >
            <Save size={18} /> Save Changes
          </button>
        </div>
      </form>
    </div>
  );
};

// --- Confirm Delete Modal ---
const ConfirmDeleteModal = ({ onConfirm, onCancel }) => (
  <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center z-40 p-4">
    <div className="bg-white rounded-2xl shadow-lg p-6 w-full max-w-sm text-center">
      <AlertCircle size={48} className="mx-auto text-red-500 mb-4" />
      <h3 className="text-lg font-semibold text-gray-800 mb-2">
        Are you sure?
      </h3>
      <p className="text-gray-600 mb-6">This action cannot be undone.</p>
      <div className="flex justify-center gap-4">
        <button
          onClick={onCancel}
          className="px-6 py-2 rounded-xl font-semibold bg-gray-200 text-gray-700 hover:bg-gray-300 transition-colors"
        >
          Cancel
        </button>
        <button
          onClick={onConfirm}
          className="px-6 py-2 rounded-xl font-semibold bg-red-500 text-white hover:bg-red-600 transition-colors"
        >
          Delete
        </button>
      </div>
    </div>
  </div>
);

// --- Main Template Page ---
const TemplatePage = () => {
  const [templates, setTemplates] = useState([]);
  const [editingTemplate, setEditingTemplate] = useState(null);
  const [viewingTemplate, setViewingTemplate] = useState(null);
  const [confirmingDelete, setConfirmingDelete] = useState(null);
  const [newTemplate, setNewTemplate] = useState(INITIAL_TEMPLATE);
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");

  // PAGINATION STATE (NEW)
  const [recordsPerPage, setRecordsPerPage] = useState(10);
  const [currentPage, setCurrentPage] = useState(1);

  // API Options State
  const [designations, setDesignations] = useState([]);
  const [employeeStatuses, setEmployeeStatuses] = useState([]);

  const [notification, setNotification] = useState({ message: "", type: "" });

  // API Endpoints
  const API_URL = `${import.meta.env.VITE_API_BASE_URL}/template`;

  console.log(API_URL);

  const DESIGNATION_API = `${import.meta.env.VITE_API_BASE_URL}/designations`;
  const STATUS_API = `${import.meta.env.VITE_API_BASE_URL}/employee-status`;

  const showNotification = useCallback((message, type = "success") => {
    setNotification({ message, type });
    setTimeout(() => setNotification({ message: "", type: "" }), 3000);
  }, []);

  // --- Helper to get ID from NAME ---
  const getDesignationIdByName = (name) => {
    const designation = designations.find((d) => d.name === name);
    return designation ? designation._id : null;
  };

  // --- Helper to get IDs from NAMES ---
  const getEmployeeStatusIdsByNames = (namesArray) => {
    return namesArray
      .map((name) => {
        const status = employeeStatuses.find((s) => s.name === name);
        return status ? status._id : null;
      })
      .filter((id) => id !== null); // Filter out any IDs that weren't found
  };

  const fetchTemplates = useCallback(async () => {
    try {
      const res = await axios.get(API_URL);
      setTemplates(res.data.data || []);
    } catch (err) {
      console.error(err);
      showNotification("Error fetching templates", "error");
    }
  }, [showNotification, API_URL]);

  const fetchOptions = useCallback(async () => {
    try {
      const [designationRes, statusRes] = await Promise.all([
        axios.get(DESIGNATION_API),
        axios.get(STATUS_API),
      ]);

      // 1. Normalize Designation data: Map 'title' field to 'name'
      const rawDesignations = Array.isArray(designationRes.data)
        ? designationRes.data
        : designationRes.data.data || [];

      const normalizedDesignations = rawDesignations.map((d) => ({
        _id: d._id,
        name: d.title, // Map 'title' to 'name' for FormSelect
      }));
      setDesignations(normalizedDesignations);

      // 2. Normalize Employee Status data: Map 'status' field to 'name'
      const rawStatuses = statusRes.data.statuses || [];
      const normalizedStatuses = rawStatuses.map((s) => ({
        _id: s._id,
        name: s.status, // Map 'status' to 'name' for FormMultiSelect
      }));
      setEmployeeStatuses(normalizedStatuses);
    } catch (err) {
      console.error("Error fetching options:", err);
      showNotification(
        "Error fetching options data (Designations/Statuses).",
        "error"
      );
    }
  }, [showNotification, DESIGNATION_API, STATUS_API]);

  useEffect(() => {
    fetchTemplates();
    fetchOptions();
  }, [fetchTemplates, fetchOptions]);

  const handleAddTemplate = async () => {
    const designationId = getDesignationIdByName(newTemplate.desination);
    const employeeStatusIds = getEmployeeStatusIdsByNames(
      newTemplate.EmployeeStatus
    );

    if (
      !newTemplate.subject ||
      !designationId ||
      employeeStatusIds.length === 0 ||
      !newTemplate.document
    ) {
      showNotification(
        "Subject, Designation, Employee Status, and Document/Picture are required.",
        "error"
      );
      return;
    }

    try {
      const dataToSend = {
        ...newTemplate,
        desination: designationId,
        EmployeeStatus: employeeStatusIds,
      };

      const formData = new FormData();

      Object.keys(dataToSend).forEach((key) => {
        const value = dataToSend[key];

        // ✅ Handle file upload separately
        if (key === "document" && newTemplate.document) {
          formData.append("documentFiles", newTemplate.document);
        }
        // ✅ Handle EmployeeStatus (array)
        else if (key === "EmployeeStatus" && Array.isArray(value)) {
          value.forEach((id) => id && formData.append(key, id));
        }
        // ✅ Handle booleans explicitly (true/false)
        else if (typeof value === "boolean") {
          formData.append(key, value ? "true" : "false");
        }
        // ✅ Handle other normal fields
        else if (value !== null && value !== undefined && key !== "document") {
          formData.append(key, value.toString());
        }
      });

      await axios.post(API_URL, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });

      fetchTemplates();
      setNewTemplate(INITIAL_TEMPLATE);
      setShowAddForm(false);
      showNotification("Template added successfully");
    } catch (err) {
      console.error("API Error Response:", err.response);
      const backendError =
        err.response?.data?.error || err.response?.data?.message || err.message;
      showNotification(`Failed to add template: ${backendError}`, "error");
    }
  };

  const handleSaveEdit = async (updatedData, newFile) => {
    // 1. Convert NAMEs to ID's
    const designationId = getDesignationIdByName(updatedData.desination);
    const employeeStatusIds = getEmployeeStatusIdsByNames(
      updatedData.EmployeeStatus
    );

    const dataToSend = {
      ...updatedData,
      desination: designationId,
      EmployeeStatus: employeeStatusIds,
    };

    try {
      const formData = new FormData();
      Object.keys(dataToSend).forEach((key) => {
        // Exclude internal fields and the document object placeholder
        if (key !== "_id" && key !== "document" && key !== "__v") {
          const value = dataToSend[key];

          // FIX: Handle EmployeeStatus (array of IDs) by appending each item individually
          if (key === "EmployeeStatus" && Array.isArray(value)) {
            value.forEach((id) => {
              if (id) formData.append(key, id);
            });
          } else if (typeof value === "boolean") {
            formData.append(key, value.toString());
          } else if (value !== null && value !== undefined) {
            // This handles 'desination' (single ID string) correctly
            formData.append(key, value.toString());
          }
        }
      });
      if (newFile) formData.append("documentFiles", newFile);
      // If the API allows updating fields without sending a file, this should work.

      await axios.put(`${API_URL}/${updatedData._id}`, formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      fetchTemplates();
      setEditingTemplate(null);
      showNotification("Template updated successfully");
    } catch (err) {
      console.error("API Error Response (Edit):", err.response);
      const backendError =
        err.response?.data?.error || err.response?.data?.message || err.message;
      showNotification(`Failed to update template: ${backendError}`, "error");
    }
  };

  const handleDelete = (id) => setConfirmingDelete(id);
  const performDelete = async (id) => {
    try {
      await axios.delete(`${API_URL}/${id}`);
      setTemplates((prev) => prev.filter((t) => t._id !== id));
      showNotification("Template deleted successfully");
    } catch (err) {
      console.error(err);
      showNotification("Failed to delete template", "error");
    }
    setConfirmingDelete(null);
  };

  const handleNewTemplateChange = (e) => {
    const { name, value, type, files, checked } = e.target;

    if (type === "file") {
      setNewTemplate((prev) => ({ ...prev, document: files[0] }));
    } else if (type === "checkbox") {
      setNewTemplate((prev) => ({ ...prev, [name]: checked }));
    } else {
      setNewTemplate((prev) => ({ ...prev, [name]: value }));
    }
  };

  // --- PAGINATION / SEARCH LOGIC ---

  const filteredTemplates = useMemo(
    () =>
      templates.filter((t) =>
        (t.subject || "").toLowerCase().includes(searchTerm.toLowerCase())
      ),
    [searchTerm, templates]
  );

  const totalRecords = filteredTemplates.length;
  const totalPages = Math.ceil(totalRecords / recordsPerPage);

  // Calculate which templates to display based on current page and recordsPerPage
  const paginatedTemplates = useMemo(() => {
    const startIndex = (currentPage - 1) * recordsPerPage;
    const endIndex = startIndex + recordsPerPage;
    return filteredTemplates.slice(startIndex, endIndex);
  }, [currentPage, recordsPerPage, filteredTemplates]);

  const goToNextPage = () => {
    if (currentPage < totalPages) setCurrentPage(currentPage + 1);
  };

  const goToPrevPage = () => {
    if (currentPage > 1) setCurrentPage(currentPage - 1);
  };

  // Handler for records per page change (resets page to 1)
  const setRecordsPerPageHandler = useCallback((value) => {
    setRecordsPerPage(value);
    setCurrentPage(1);
  }, []);

  // --- END PAGINATION / SEARCH LOGIC ---

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-6 font-[Inter]">
      <Notification
        notification={notification}
        onDismiss={() => setNotification({ message: "", type: "" })}
      />
      {viewingTemplate && (
        <ViewTemplateModal
          template={viewingTemplate}
          onClose={() => setViewingTemplate(null)}
        />
      )}
      {editingTemplate && (
        <EditTemplateModal
          template={editingTemplate}
          onSave={handleSaveEdit}
          onClose={() => setEditingTemplate(null)}
          designations={designations}
          employeeStatuses={employeeStatuses}
        />
      )}
      {confirmingDelete && (
        <ConfirmDeleteModal
          onConfirm={() => performDelete(confirmingDelete)}
          onCancel={() => setConfirmingDelete(null)}
        />
      )}

      <div className="max-w-7xl mx-auto">
        <div className="mb-8 text-center">
          <div className="flex justify-center items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-[#450693] to-[#8C00FF] rounded-2xl">
              <Clock className="text-white" size={32} />
            </div>
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-[#450693] to-[#8C00FF] bg-clip-text text-transparent">
            Document Template Manager
          </h1>
          <p className="text-gray-600 mt-2">Manage Document Template Manager</p>
        </div>

        {/* Controls */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6 flex flex-col lg:flex-row gap-4 justify-between items-start lg:items-center">
          {/* Search and Records Per Page (Wrapped in a flex container) */}
          <div className="flex flex-col sm:flex-row gap-4 flex-1 w-full lg:max-w-xl">
            <div className="relative flex-1">
              <Search
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={20}
              />
              <input
                type="text"
                placeholder="Search Template by Subject..."
                value={searchTerm}
                onChange={(e) => {
                  setSearchTerm(e.target.value);
                  setCurrentPage(1); // Reset to page 1 on new search
                }}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#8C00FF] focus:border-transparent"
              />
            </div>
            {/* PAGINATION DROPDOWN (USER REQUESTED) */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600 hidden sm:inline">
                Show:
              </span>
              <select
                value={recordsPerPage}
                onChange={(e) =>
                  setRecordsPerPageHandler(Number(e.target.value))
                }
                className="border rounded-xl px-4 py-3 text-sm text-gray-700 focus:ring-2 focus:ring-[#8C00FF]"
              >
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={40}>40</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
              <span className="text-sm text-gray-600 hidden sm:inline">
                entries
              </span>
            </div>
          </div>

          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center justify-center gap-2 bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] text-white px-6 py-3 rounded-xl font-semibold hover:opacity-90 transition-opacity w-full lg:w-auto shadow-md shadow-purple-200"
          >
            <Plus size={20} /> Add Template
          </button>
        </div>

        {/* Add Form */}
        {showAddForm && (
          <div className="bg-white rounded-2xl shadow-xl p-6 mb-6 border-2 border-[#8C00FF] transition-all duration-300">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-semibold text-[#450693]">
                Add New Template
              </h3>
              <button
                onClick={() => setShowAddForm(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <X size={20} />
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
              <FormInput
                label="Subject*"
                name="subject"
                value={newTemplate.subject}
                onChange={handleNewTemplateChange}
                className="col-span-6 md:col-span-3"
              />
              <FormInput
                label="Header*"
                name="header"
                value={newTemplate.header}
                onChange={handleNewTemplateChange}
                className="col-span-6 md:col-span-3"
              />
              <div className="col-span-6">
                <label className="block mb-2 font-medium text-gray-700">
                  Body Content*
                </label>

                <Editor
                  name="body"
                  value={newTemplate.body}
                  onChange={handleNewTemplateChange}
                  containerProps={{
                    className:
                      "border border-gray-300 rounded p-2 min-h-[600px] h-[200px]",
                  }}
                  // additional props agar chaho
                />
              </div>

              <FormSelect
                label="Designation*"
                name="desination"
                value={newTemplate.desination}
                onChange={handleNewTemplateChange}
                options={designations}
                className="col-span-6 md:col-span-2"
              />
              {/* Employee Status Multi-Select */}
              <FormMultiSelect
                label="Employee Status*"
                name="EmployeeStatus"
                value={newTemplate.EmployeeStatus}
                onChange={handleNewTemplateChange}
                options={employeeStatuses}
                className="col-span-6 md:col-span-4"
              />

              <FormInput
                label="Footer 1*"
                name="footerFirst"
                value={newTemplate.footerFirst}
                onChange={handleNewTemplateChange}
                className="col-span-6 md:col-span-3"
              />
              <FormInput
                label="Footer 2*"
                name="footerSecond"
                value={newTemplate.footerSecond}
                onChange={handleNewTemplateChange}
                className="col-span-6 md:col-span-3"
              />

              <div className="flex flex-col col-span-6 md:col-span-3">
                <label
                  htmlFor="document"
                  className="mb-1 font-medium text-gray-700"
                >
                  Document / Picture Upload*
                </label>
                <input
                  type="file"
                  id="document"
                  onChange={handleNewTemplateChange}
                  className="p-3 border rounded-lg focus:ring-2 focus:ring-[#8C00FF] file:mr-2 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-[#8C00FF] file:text-white hover:file:bg-[#7a00e0]"
                />
              </div>

              {/* Checkboxes */}
              <div className="col-span-6 md:col-span-3 flex items-end justify-around gap-4 pt-2">
                <FormCheckbox
                  label="Footer 1 Active"
                  name="isActiveFirst"
                  isChecked={newTemplate.isActiveFirst}
                  onChange={handleNewTemplateChange}
                />
                <FormCheckbox
                  label="Footer 2 Active"
                  name="isActivesecond"
                  isChecked={newTemplate.isActivesecond}
                  onChange={handleNewTemplateChange}
                />
                <FormCheckbox
                  label="Active"
                  name="isActive"
                  isChecked={newTemplate.isActive}
                  onChange={handleNewTemplateChange}
                />
              </div>

              <div className="col-span-6 mt-4">
                <button
                  onClick={handleAddTemplate}
                  className="flex items-center justify-center gap-2 bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] text-white px-6 py-3 rounded-xl font-semibold hover:opacity-90 transition-opacity shadow-md"
                >
                  <Plus size={18} /> Add Template
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Table */}
        <div className="bg-white rounded-2xl shadow-lg overflow-x-auto">
          <table className="w-full min-w-max">
            <thead>
              <tr className="bg-gradient-to-r from-[#450693] to-[#8C00FF] text-white">
                <th className="p-4 text-left font-semibold">#</th>
                <th className="p-4 text-left font-semibold">Subject</th>
                <th className="p-4 text-left font-semibold">Designation</th>
                <th className="p-4 text-left font-semibold">Status</th>
                <th className="p-4 text-left font-semibold">Is Active</th>
                <th className="p-4 text-center font-semibold">Actions</th>
              </tr>
            </thead>
            <tbody>
              {paginatedTemplates.length > 0 ? (
                paginatedTemplates.map((template, index) => (
                  <tr
                    key={template._id}
                    className="border-t hover:bg-purple-50 transition-colors"
                  >
                    <td className="p-4 text-gray-700 font-medium">
                      {(currentPage - 1) * recordsPerPage + index + 1}
                    </td>
                    <td className="p-4 text-gray-700 max-w-xs truncate">
                      {template.subject}
                    </td>
                    <td className="p-4 text-gray-700">
                      {getDisplayValue(template.desination)}
                    </td>
                    <td className="p-4 text-gray-700 max-w-xs truncate">
                      {getDisplayValue(template.EmployeeStatus)}
                    </td>
                    <td className="p-4 text-center">
                      <span
                        className={`inline-block px-3 py-1 text-xs font-semibold rounded-full ${
                          template.isActive
                            ? "bg-green-100 text-green-700"
                            : "bg-red-100 text-red-700"
                        }`}
                      >
                        {template.isActive ? "Active" : "Inactive"}
                      </span>
                    </td>

                    <td className="p-4 text-center">
                      <div className="flex justify-center gap-2">
                        <button
                          onClick={() => setViewingTemplate(template)}
                          className="p-2 rounded-full text-blue-600 hover:bg-blue-100 transition-colors"
                          title="View"
                        >
                          <Eye size={18} />
                        </button>
                        <button
                          onClick={() => setEditingTemplate(template)}
                          className="p-2 rounded-full text-indigo-600 hover:bg-indigo-100 transition-colors"
                          title="Edit"
                        >
                          <Edit size={18} />
                        </button>
                        <button
                          onClick={() => handleDelete(template._id)}
                          className="p-2 rounded-full text-red-600 hover:bg-red-100 transition-colors"
                          title="Delete"
                        >
                          <Trash2 size={18} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan="6" className="p-6 text-center text-gray-500">
                    <Info size={20} className="inline mr-2" />
                    No templates found matching your search.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>

        {/* PAGINATION CONTROLS */}
        <div className="flex flex-col sm:flex-row justify-between items-center gap-4 p-6 border-t border-gray-200 text-sm text-gray-600 mt-6">
          <div>
            Showing {(currentPage - 1) * recordsPerPage + 1} to{" "}
            {Math.min(currentPage * recordsPerPage, totalRecords)} of{" "}
            {totalRecords} entries
            {searchTerm && ` (filtered from ${templates.length} total)`}
          </div>

          <div className="flex items-center gap-2">
            {/* First Page */}
            <button
              disabled={currentPage === 1}
              onClick={() => setCurrentPage(1)}
              className="px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              First
            </button>

            {/* Previous Page */}
            <button
              disabled={currentPage === 1}
              onClick={goToPrevPage}
              className="flex items-center gap-1 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <ChevronLeft size={16} />
              Previous
            </button>

            {/* Page Numbers */}
            {Array.from({ length: totalPages }, (_, i) => i + 1).map(
              (pageNumber) => (
                <button
                  key={pageNumber}
                  onClick={() => setCurrentPage(pageNumber)}
                  className={`px-4 py-2 rounded-lg transition-colors ${
                    currentPage === pageNumber
                      ? "bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] text-white"
                      : "bg-white border border-gray-300 hover:bg-gray-50"
                  }`}
                >
                  {pageNumber}
                </button>
              )
            )}

            {/* Next Page */}
            <button
              disabled={currentPage === totalPages || totalPages === 0}
              onClick={goToNextPage}
              className="flex items-center gap-1 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Next
              <ChevronRight size={16} />
            </button>

            {/* Last Page */}
            <button
              disabled={currentPage === totalPages || totalPages === 0}
              onClick={() => setCurrentPage(totalPages)}
              className="px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Last
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TemplatePage;
