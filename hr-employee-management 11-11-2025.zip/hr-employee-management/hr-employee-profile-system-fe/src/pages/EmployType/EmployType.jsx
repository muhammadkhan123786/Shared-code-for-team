import React, { useState, useEffect, useMemo, useCallback } from "react";
import axios from "axios";
import {
  Search,
  Edit,
  Trash2,
  X,
  Save,
  ChevronLeft,
  ChevronRight,
  Plus,
  Briefcase,
  ToggleLeft,
  ToggleRight,
} from "lucide-react";

// Initial state for adding a new employ type
const INITIAL_NEW_EMPLOY_TYPE_STATE = {
  name: "", // Name of the employ type (e.g., "Full-Time", "Contractor")
  status: true,
  isDefault: false,
  order: 1,
};

// --- EmployType Component ---

const EmployType = () => {
  const [employTypes, setEmployTypes] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [newEmployType, setNewEmployType] = useState(
    INITIAL_NEW_EMPLOY_TYPE_STATE
  );
  const [editingEmployType, setEditingEmployType] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);

  // --- API Configuration ---
  const API_BASE_URL =
    import.meta.env.VITE_API_BASE_URL || "http://localhost:5000/api";
  const EMPLOY_TYPE_API_URL = `${API_BASE_URL}/employ-type`;

  // --- Utility Functions ---

  // Converts boolean (true/false) to API's expected integer (1/0)
  const boolToApiValue = (bool) => (bool ? 1 : 0);

  // Normalizes the API response object to a consistent local state structure
  const normalizeEmployType = (et) => ({
    ...et,
    // FIX 1: Using 'description' from the API response for the local 'name' property
    name: et.description || et.name || et.title || "Untitled",
    // ✅ IMPROVED FIX: Be explicit about 1/0 or true/false status for robustness
    status: et.status === 1 || et.status === true || !!et.isActive,
    isDefault: !!et.isDefault,
    order: et.order || 0,
  });

  // Fetch Employ Types
  const fetchEmployTypes = useCallback(async () => {
    try {
      const res = await axios.get(EMPLOY_TYPE_API_URL);
      const employTypeData = res.data.data
        ? res.data.data.map(normalizeEmployType)
        : [];

      if (Array.isArray(employTypeData)) {
        // Sort by order then by name
        employTypeData.sort(
          (a, b) =>
            (a.order || 0) - (b.order || 0) ||
            (a.name || "").localeCompare(b.name || "")
        );
        setEmployTypes(employTypeData);
      } else {
        console.error("API response data is not an array:", res.data);
        setEmployTypes([]);
      }
    } catch (error) {
      console.error(`Error loading employ types: ${error}`);
    }
  }, [EMPLOY_TYPE_API_URL]);

  useEffect(() => {
    fetchEmployTypes();
  }, [EMPLOY_TYPE_API_URL, fetchEmployTypes]);

  // Unset Other Defaults - Logic ensures only one item is default on the server
  const unsetOtherDefaults = async (newDefaultEmployTypeId) => {
    // Check state for current default *excluding* the one being set/edited
    const currentDefault = employTypes.find(
      (et) => et.isDefault && et._id !== newDefaultEmployTypeId
    );

    if (currentDefault) {
      console.log(`Unsetting previous default: ${currentDefault.name}`);

      try {
        await axios.put(`${EMPLOY_TYPE_API_URL}/${currentDefault._id}`, {
          // 🔥 FIX: Use 'description' for name field in PUT request (to unset default)
          description: currentDefault.name,
          status: boolToApiValue(currentDefault.status),
          isDefault: 0, // Explicitly set to 0 (false)
          order: currentDefault.order,
        });
      } catch (error) {
        console.error(
          `Failed to unset default for ${currentDefault.name}:`,
          error.response?.data || error.message
        );
      }
    }
  };

  // Add Employ Type (POST)
  const handleAddEmployType = async () => {
    if (!newEmployType.name.trim()) {
      alert("Please enter employ type name.");
      return;
    }

    try {
      // 1. If the new employ type is set as default, unset all others FIRST.
      if (newEmployType.isDefault) {
        await unsetOtherDefaults(null);
      }

      // 2. Add the new employ type
      const payload = {
        // 🔥 CRITICAL FIX: Use 'description' for name field in POST request
        description: newEmployType.name,
        status: boolToApiValue(newEmployType.status),
        isDefault: boolToApiValue(newEmployType.isDefault),
        order: newEmployType.order,
      };

      await axios.post(EMPLOY_TYPE_API_URL, payload);

      await fetchEmployTypes();

      setNewEmployType(INITIAL_NEW_EMPLOY_TYPE_STATE);
      setShowAddForm(false);
      alert("Employ Type added successfully!");
    } catch (err) {
      console.error(
        "Failed to add employ type. Server Response:",
        err.response?.data || err.message
      );
      alert(
        err.response?.data?.error ||
          err.response?.data?.message ||
          "Failed to save employ type! Check console for details."
      );
    }
  };

  // Edit Handlers
  const handleEdit = (employType) => {
    setEditingEmployType(normalizeEmployType(employType));
  };

  const handleSaveEdit = async () => {
    if (!editingEmployType.name.trim()) {
      alert("Please enter employ type name.");
      return;
    }

    try {
      // 1. If the edited employ type is set as default, unset all others FIRST.
      if (editingEmployType.isDefault) {
        await unsetOtherDefaults(editingEmployType._id);
      }

      // 2. Save the edited employ type
      const payload = {
        // 🔥 CRITICAL FIX: Use 'description' for name field in PUT request
        description: editingEmployType.name,
        status: boolToApiValue(editingEmployType.status),
        isDefault: boolToApiValue(editingEmployType.isDefault),
        order: editingEmployType.order,
      };

      await axios.put(
        `${EMPLOY_TYPE_API_URL}/${editingEmployType._id}`,
        payload
      );

      // Re-fetch ensures we get the latest state including any defaults that were unset
      await fetchEmployTypes();

      setEditingEmployType(null);
      alert("Employ Type updated successfully!");
    } catch (err) {
      console.error(
        "Failed to save edit. Server Response:",
        err.response?.data || err.message
      );
      alert(err.response?.data?.error || "Error updating employ type");
    }
  };

  const handleCancelEdit = () => setEditingEmployType(null);
  const handleCancelAdd = () => {
    setShowAddForm(false);
    setNewEmployType(INITIAL_NEW_EMPLOY_TYPE_STATE);
  };

  // Delete Employ Type
  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this employ type?"))
      return;

    try {
      await axios.delete(`${EMPLOY_TYPE_API_URL}/${id}`);

      setEmployTypes((prev) => prev.filter((et) => et._id !== id));
      alert("Employ Type deleted successfully.");
    } catch (err) {
      console.error(
        "Failed to delete employ type. Server Response:",
        err.response?.data || err.message
      );
      alert(
        err.response?.data?.error ||
          "Failed to delete employ type. It might be linked to other records or restricted by the server."
      );
    }
  };

  // Toggle Status
  const handleToggleStatus = async (employType) => {
    const newStatus = !employType.status;

    // If we are deactivating the current default, prevent it. (Optional guardrail)
    if (!newStatus && employType.isDefault) {
      alert(
        "Cannot deactivate the default employ type. Please set a new default first."
      );
      return;
    }

    try {
      const payload = {
        // 🔥 CRITICAL FIX: Use 'description' for name field in status toggle request
        description: employType.name,
        status: boolToApiValue(newStatus),
        isDefault: boolToApiValue(employType.isDefault),
        order: employType.order,
      };

      // 1. Send the update request
      await axios.put(`${EMPLOY_TYPE_API_URL}/${employType._id}`, payload);

      // 2. ✅ CRITICAL FIX: Update the local state directly with the known new status.
      // This bypasses potential re-normalization issues with the API's response data shape.
      setEmployTypes((prev) =>
        prev.map((et) =>
          et._id === employType._id
            ? {
                ...et,
                status: newStatus, // Set the status explicitly to the value we know succeeded
              }
            : et
        )
      );

      alert(
        `Status toggled to ${newStatus ? "Active" : "Inactive"} successfully!`
      );
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.error || "Failed to toggle status");
    }
  };

  // --- Search, Pagination, Badges (Functionality unchanged) ---
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(20);

  const filteredEmployTypes = useMemo(() => {
    if (!Array.isArray(employTypes)) return [];

    return employTypes.filter((employType) =>
      (employType?.name || employType?.title || "")
        .toLowerCase()
        .includes(searchTerm.toLowerCase())
    );
  }, [searchTerm, employTypes]);

  const totalPages = Math.ceil(filteredEmployTypes.length / recordsPerPage);
  const indexOfLast = currentPage * recordsPerPage;
  const indexOfFirst = indexOfLast - recordsPerPage;
  const currentRecords = filteredEmployTypes.slice(indexOfFirst, indexOfLast);

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, recordsPerPage]);

  const getPageNumbers = () => {
    const pageNumbers = [];
    const maxPagesToShow = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2));
    let endPage = Math.min(totalPages, startPage + maxPagesToShow - 1);
    if (endPage - startPage + 1 < maxPagesToShow) {
      startPage = Math.max(1, endPage - maxPagesToShow + 1);
    }
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(i);
    }
    return pageNumbers;
  };

  const getStatusBadge = (status) => {
    return status === true ? (
      <span className="px-3 py-1 bg-green-100 text-green-800 text-sm font-medium rounded-full">
        Active
      </span>
    ) : (
      <span className="px-3 py-1 bg-red-100 text-red-800 text-sm font-medium rounded-full">
        Inactive
      </span>
    );
  };

  // --- JSX Render (Updated Edit/Table Logic) ---

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8 text-center">
          <div className="flex justify-center items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-[#450693] to-[#8C00FF] rounded-2xl">
              <Briefcase className="text-white" size={32} />
            </div>
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-[#450693] to-[#8C00FF] bg-clip-text text-transparent">
            Employ Type Management
          </h1>
          <p className="text-gray-600 mt-2">Manage Employee Types</p>
        </div>

        {/* Controls Section (Unchanged) */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <div className="flex flex-col lg:flex-row gap-4 justify-between items-start lg:items-center">
            {/* Search Bar */}
            <div className="relative flex-1 max-w-md">
              <Search
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={20}
              />
              <input
                type="text"
                placeholder="Search Employ Type..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#8C00FF] focus:border-transparent"
              />
            </div>

            {/* Records Per Page Selector */}
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">Show:</span>
              <select
                value={recordsPerPage}
                onChange={(e) => setRecordsPerPage(Number(e.target.value))}
                className="border rounded px-2 py-1 text-sm"
              >
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={40}>40</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
              <span className="text-sm text-gray-600">entries</span>
            </div>

            {/* Add Button */}
            <button
              onClick={() => setShowAddForm(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] text-white px-6 py-3 rounded-xl font-semibold hover:opacity-90 transition-opacity"
            >
              <Plus size={20} />
              Add Employ Type
            </button>
          </div>

          {/* Results Count */}
          <div className="mt-4 text-sm text-gray-600">
            Showing {filteredEmployTypes.length} of {employTypes.length} Employ
            Types
          </div>
        </div>

        {/* Add Employ Type Form (Unchanged functionality, ensures status/default interaction) */}
        {showAddForm && (
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-6 border-2 border-[#8C00FF]">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-[#450693]">
                Add New Employ Type
              </h3>
              <button
                onClick={handleCancelAdd}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-5 gap-4 items-end">
              <div className="lg:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Employ Type Name *
                </label>
                <input
                  type="text"
                  placeholder="Enter employ type name"
                  value={newEmployType.name}
                  onChange={(e) =>
                    setNewEmployType({ ...newEmployType, name: e.target.value })
                  }
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF]"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Display Order
                </label>
                <input
                  type="number"
                  min="0"
                  placeholder="Order"
                  value={newEmployType.order}
                  onChange={(e) =>
                    setNewEmployType({
                      ...newEmployType,
                      order: parseInt(e.target.value) || 0,
                    })
                  }
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF]"
                />
              </div>

              <div className="flex flex-col gap-3">
                {/* Status Checkbox */}
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="newEmployTypeStatus"
                    className="h-5 w-5 accent-[#8C00FF] cursor-pointer"
                    checked={newEmployType.status}
                    onChange={(e) =>
                      setNewEmployType({
                        ...newEmployType,
                        status: e.target.checked,
                      })
                    }
                  />
                  <label
                    htmlFor="newEmployTypeStatus"
                    className="text-sm font-medium text-gray-700 cursor-pointer"
                  >
                    Active
                  </label>
                </div>

                {/* Default Checkbox */}
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="newEmployTypeDefault"
                    className="h-5 w-5 accent-[#8C00FF] cursor-pointer"
                    checked={newEmployType.isDefault}
                    onChange={(e) =>
                      setNewEmployType({
                        ...newEmployType,
                        isDefault: e.target.checked,
                        // FIX: If setting as default, ensure it is active
                        status: e.target.checked ? true : newEmployType.status,
                      })
                    }
                  />
                  <label
                    htmlFor="newEmployTypeDefault"
                    className="text-sm font-medium text-gray-700 cursor-pointer"
                  >
                    Set as Default
                  </label>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={handleAddEmployType}
                  className="flex-1 bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] text-white px-4 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
                >
                  Add Employ Type
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Employ Types Table */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gradient-to-r from-[#450693] to-[#8C00FF] text-white">
                  <th className="p-4 text-left font-semibold">#</th>
                  <th className="p-4 text-left font-semibold">Order</th>
                  <th className="p-4 text-left font-semibold">
                    Employ Type Name
                  </th>
                  <th className="p-4 text-center font-semibold">Status</th>
                  <th className="p-4 text-center font-semibold">Default</th>
                  <th className="p-4 text-center font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentRecords.map((employType, index) => {
                  const isEditing = editingEmployType?._id === employType._id;

                  return (
                    <tr
                      key={employType._id}
                      className={`border-b hover:bg-gray-50 transition-colors ${
                        employType.isDefault
                          ? "bg-yellow-50 border-l-4 border-l-yellow-400"
                          : index % 2 === 0
                          ? "bg-white"
                          : "bg-gray-50"
                      }`}
                    >
                      {/* Serial Number */}
                      <td className="p-4 font-medium">
                        {indexOfFirst + index + 1}
                      </td>

                      {/* Order (Edit Mode) */}
                      <td className="p-4">
                        {isEditing ? (
                          <input
                            type="number"
                            min="0"
                            value={editingEmployType.order}
                            onChange={(e) =>
                              setEditingEmployType({
                                ...editingEmployType,
                                order: parseInt(e.target.value) || 0,
                              })
                            }
                            className="w-16 p-2 border border-gray-300 rounded-lg text-center focus:outline-none focus:ring-2 focus:ring-[#8C00FF]"
                          />
                        ) : (
                          <span className="inline-flex items-center justify-center w-8 h-8 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                            {employType.order || 0}
                          </span>
                        )}
                      </td>

                      {/* Employ Type Name (Edit Mode) */}
                      <td className="p-4">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] rounded-full flex items-center justify-center text-white">
                            <Briefcase size={16} />
                          </div>
                          <div className="flex items-center gap-2 w-full">
                            {isEditing ? (
                              <input
                                type="text"
                                // FIX: Correctly binding input value to 'name'
                                value={editingEmployType.name}
                                onChange={(e) =>
                                  setEditingEmployType({
                                    ...editingEmployType,
                                    name: e.target.value,
                                  })
                                }
                                className="flex-1 p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF]"
                              />
                            ) : (
                              <>
                                <div className="font-medium text-gray-900">
                                  {/* Using .name (which is normalized from description/title) */}
                                  {employType.name || "Missing Name"}
                                </div>
                                {employType.isDefault && (
                                  <span className="bg-yellow-500 text-white text-xs px-2 py-1 rounded-full font-medium">
                                    ⭐ Default
                                  </span>
                                )}
                              </>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* Status (Edit Mode) */}
                      <td className="p-4 text-center">
                        {isEditing ? (
                          <input
                            type="checkbox"
                            className="h-5 w-5 accent-[#8C00FF] cursor-pointer"
                            // Correctly bound to 'status'
                            checked={editingEmployType.status}
                            onChange={(e) =>
                              setEditingEmployType({
                                ...editingEmployType,
                                // FIX: Correctly updating 'status'
                                status: e.target.checked,
                              })
                            }
                          />
                        ) : (
                          getStatusBadge(employType.status)
                        )}
                      </td>

                      {/* Default (Edit Mode) */}
                      <td className="p-4 text-center">
                        {isEditing ? (
                          <input
                            type="checkbox"
                            className="h-5 w-5 accent-[#8C00FF] cursor-pointer"
                            checked={editingEmployType.isDefault}
                            onChange={(e) =>
                              setEditingEmployType({
                                ...editingEmployType,
                                isDefault: e.target.checked,
                                // FIX: If setting as default, ensure it is active
                                status: e.target.checked
                                  ? true
                                  : editingEmployType.status,
                              })
                            }
                          />
                        ) : employType.isDefault ? (
                          <span className="inline-flex items-center gap-1 text-yellow-600 font-medium">
                            <span className="w-2 h-2 bg-yellow-500 rounded-full"></span>
                            Yes
                          </span>
                        ) : (
                          <span className="text-gray-400">No</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="p-4 text-center">
                        <div className="flex justify-center gap-2">
                          {isEditing ? (
                            <>
                              <button
                                onClick={handleSaveEdit}
                                className="flex items-center gap-1 bg-green-500 text-white px-3 py-2 rounded-lg hover:bg-green-600 transition-colors"
                              >
                                <Save size={16} />
                                Save
                              </button>
                              <button
                                onClick={handleCancelEdit}
                                className="flex items-center gap-1 bg-gray-500 text-white px-3 py-2 rounded-lg hover:bg-gray-600 transition-colors"
                              >
                                <X size={16} />
                                Cancel
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                onClick={() => handleEdit(employType)}
                                className="flex items-center gap-1 bg-[#FFC400] text-white p-2 rounded-lg hover:bg-[#E6B000] transition-colors"
                                title="Edit"
                              >
                                <Edit size={16} />
                              </button>

                              <button
                                onClick={() => handleToggleStatus(employType)}
                                className={`flex items-center justify-center p-2 rounded-lg text-white transition-colors ${
                                  employType.status
                                    ? "bg-gray-500 hover:bg-gray-600"
                                    : "bg-green-500 hover:bg-green-600"
                                }`}
                                title={
                                  employType.status ? "Deactivate" : "Activate"
                                }
                              >
                                {employType.status ? "Deactivate" : "Activate"}
                              </button>

                              <button
                                onClick={() => handleDelete(employType._id)}
                                className={`flex items-center gap-1 bg-red-500 text-white p-2 rounded-lg hover:bg-red-600 transition-colors`}
                                title="Delete"
                              >
                                <Trash2 size={16} />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {/* Empty State */}
            {currentRecords.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                {searchTerm
                  ? "No employ types found matching your search."
                  : "No employ types available."}
              </div>
            )}
          </div>

          {/* Pagination (Unchanged) */}
          {filteredEmployTypes.length > 0 && (
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 p-6 border-t border-gray-200">
              <div className="text-sm text-gray-600">
                Showing {indexOfFirst + 1} to{" "}
                {Math.min(indexOfLast, filteredEmployTypes.length)} of{" "}
                {filteredEmployTypes.length} entries
              </div>

              <div className="flex items-center gap-2">
                {/* Pagination Controls */}
                <button
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(1)}
                  className="px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  First
                </button>

                <button
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(currentPage - 1)}
                  className="flex items-center gap-1 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronLeft size={16} />
                  Previous
                </button>

                {getPageNumbers().map((pageNumber) => (
                  <button
                    key={pageNumber}
                    onClick={() => setCurrentPage(pageNumber)}
                    className={`px-4 py-2 rounded-lg transition-colors ${
                      currentPage === pageNumber
                        ? "bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] text-white"
                        : "bg-white border border-gray-300 hover:bg-gray-50"
                    }`}
                  >
                    {pageNumber}
                  </button>
                ))}

                <button
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage(currentPage + 1)}
                  className="flex items-center gap-1 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Next
                  <ChevronRight size={16} />
                </button>

                <button
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage(totalPages)}
                  className="px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Last
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default EmployType;
