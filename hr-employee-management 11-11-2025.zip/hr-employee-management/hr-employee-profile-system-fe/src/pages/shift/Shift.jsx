import React, { useState, useEffect, useMemo, useCallback } from "react";
import axios from "axios";
import {
  Search,
  Edit,
  Trash2,
  X,
  Save,
  ChevronLeft,
  ChevronRight,
  Plus,
  Clock,
  ToggleLeft,
  ToggleRight,
} from "lucide-react";

const INITIAL_NEW_SHIFT_STATE = {
  description: "",
  startTime: "09:00",
  endTime: "17:00",
  isActive: true,
  isDefault: false,
  order: 1,
};

const timeToMinutes = (time24hr) => {
  if (!time24hr) return 0;
  const [hour, minute] = time24hr.split(":").map(Number);
  return hour * 60 + minute;
};

const isTimeValid = (startTime, endTime) => {
  if (!startTime || !endTime) return false;

  const startMinutes = timeToMinutes(startTime);
  const endMinutes = timeToMinutes(endTime);

  return endMinutes > startMinutes;
};

const Shifts = () => {
  const [shifts, setShifts] = useState([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [newShift, setNewShift] = useState(INITIAL_NEW_SHIFT_STATE);
  const [editingShift, setEditingShift] = useState(null);
  const [showAddForm, setShowAddForm] = useState(false);

  const API_BASE_URL =
    import.meta.env.VITE_API_BASE_URL || "http://localhost:5000/api";
  const SHIFT_API_URL = `${API_BASE_URL}/shift`;

  const boolToApiValue = (bool) => (bool ? 1 : 0);

  const formatTimeForDisplay = (time24hr) => {
    if (!time24hr || typeof time24hr !== "string") return "N/A";
    try {
      const [hour, minute] = time24hr.split(":");
      const h = parseInt(hour, 10);
      if (isNaN(h)) return time24hr;

      const ampm = h >= 12 ? "PM" : "AM";
      const h12 = h % 12 || 12;
      const paddedMinute = minute.padStart(2, "0");
      return `${h12.toString().padStart(2, "0")}:${paddedMinute} ${ampm}`;
    } catch (e) {
      console.error("Time formatting failed:", e);
      return time24hr; // Fallback
    }
  };

  const normalizeShift = (sh) => ({
    ...sh,
    description: sh.description || "Untitled Shift",
    startTime: sh.timing?.startTime || "09:00",
    endTime: sh.timing?.endTime || "17:00",
    isActive: sh.isActive === 1 || sh.isActive === true || !!sh.isActive,
    isDefault: !!sh.isDefault,
    order: sh.order || 0,
  });

  const fetchShifts = useCallback(async () => {
    try {
      const res = await axios.get(SHIFT_API_URL);
      const shiftData = res.data.data ? res.data.data.map(normalizeShift) : [];

      if (Array.isArray(shiftData)) {
        shiftData.sort(
          (a, b) =>
            (a.order || 0) - (b.order || 0) ||
            (a.description || "").localeCompare(b.description || "")
        );
        setShifts(shiftData);
      } else {
        setShifts([]);
      }
    } catch (error) {
      console.error(`Error loading shifts: ${error}`);
    }
  }, [SHIFT_API_URL]);

  useEffect(() => {
    fetchShifts();
  }, [SHIFT_API_URL, fetchShifts]);

  const unsetOtherDefaults = async (newDefaultShiftId) => {
    const currentDefault = shifts.find(
      (sh) => sh.isDefault && sh._id !== newDefaultShiftId
    );

    if (currentDefault) {
      try {
        await axios.put(`${SHIFT_API_URL}/${currentDefault._id}`, {
          description: currentDefault.description,
          timing: {
            startTime: currentDefault.startTime,
            endTime: currentDefault.endTime,
          },
          isActive: boolToApiValue(currentDefault.isActive),
          isDefault: 0,
          order: currentDefault.order,
        });
      } catch (error) {
        console.error(
          `Failed to unset default:`,
          error.response?.data || error.message
        );
      }
    }
  };

  const handleAddShift = async () => {
    // 1. Basic Check
    if (
      !newShift.description.trim() ||
      !newShift.startTime ||
      !newShift.endTime
    ) {
      alert("Please enter shift description, start time, and end time.");
      return;
    }

    if (!isTimeValid(newShift.startTime, newShift.endTime)) {
      alert("Shift End Time must be later than Start Time!");
      return;
    }

    try {
      if (newShift.isDefault) {
        await unsetOtherDefaults(null);
      }

      const payload = {
        description: newShift.description,
        timing: {
          startTime: newShift.startTime,
          endTime: newShift.endTime,
        },
        isActive: boolToApiValue(newShift.isActive),
        isDefault: boolToApiValue(newShift.isDefault),
        order: newShift.order,
      };

      await axios.post(SHIFT_API_URL, payload);
      await fetchShifts();

      setNewShift(INITIAL_NEW_SHIFT_STATE);
      setShowAddForm(false);
      alert("Shift added successfully!");
    } catch (err) {
      console.error(
        "Failed to add shift. Server Response:",
        err.response?.data || err.message
      );

      // ✅ FIX: Enhanced error message for duplicate description (409 Conflict)
      const serverMessage =
        err.response?.data?.error || err.response?.data?.message;
      if (err.response?.status === 409 && serverMessage) {
        alert(`Error: ${serverMessage}`);
      } else {
        alert(serverMessage || "Failed to save shift!");
      }
    }
  };

  const handleEdit = (shift) => {
    setEditingShift(normalizeShift(shift));
  };

  const handleSaveEdit = async () => {
    // 1. Basic Check
    if (
      !editingShift.description.trim() ||
      !editingShift.startTime ||
      !editingShift.endTime
    ) {
      alert("Please enter shift description, start time, and end time.");
      return;
    }

    // if (!isTimeValid(editingShift.startTime, editingShift.endTime)) {
    //   alert("Shift End Time must be later than Start Time!");
    //   return;
    // }

    try {
      if (editingShift.isDefault) {
        await unsetOtherDefaults(editingShift._id);
      }

      const payload = {
        description: editingShift.description,
        timing: {
          startTime: editingShift.startTime,
          endTime: editingShift.endTime,
        },
        isActive: boolToApiValue(editingShift.isActive),
        isDefault: boolToApiValue(editingShift.isDefault),
        order: editingShift.order,
      };

      await axios.put(`${SHIFT_API_URL}/${editingShift._id}`, payload);

      await fetchShifts();

      setEditingShift(null);
      alert("Shift updated successfully!");
    } catch (err) {
      console.error(
        "Failed to save edit. Server Response:",
        err.response?.data || err.message
      );

      // ✅ FIX: Enhanced error message for duplicate description (409 Conflict)
      const serverMessage =
        err.response?.data?.error || err.response?.data?.message;
      if (err.response?.status === 409 && serverMessage) {
        alert(`Error: ${serverMessage}`);
      } else {
        alert(serverMessage || "Error updating shift");
      }
    }
  };

  const handleCancelEdit = () => setEditingShift(null);
  const handleCancelAdd = () => {
    setShowAddForm(false);
    setNewShift(INITIAL_NEW_SHIFT_STATE);
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Are you sure you want to delete this shift?")) return;

    try {
      await axios.delete(`${SHIFT_API_URL}/${id}`);

      setShifts((prev) => prev.filter((sh) => sh._id !== id));
      alert("Shift deleted successfully.");
    } catch (err) {
      console.error(
        "Failed to delete shift. Server Response:",
        err.response?.data || err.message
      );
      alert(
        err.response?.data?.error ||
          "Failed to delete shift. It might be linked to other records or restricted by the server."
      );
    }
  };

  const handleToggleStatus = async (shift) => {
    const newStatus = !shift.isActive;

    if (!newStatus && shift.isDefault) {
      alert(
        "Cannot deactivate the default shift. Please set a new default first."
      );
      return;
    }

    try {
      const payload = {
        description: shift.description,
        timing: {
          startTime: shift.startTime,
          endTime: shift.endTime,
        },
        isActive: boolToApiValue(newStatus),
        isDefault: boolToApiValue(shift.isDefault),
        order: shift.order,
      };

      await axios.put(`${SHIFT_API_URL}/${shift._id}`, payload);

      // Update local state directly
      setShifts((prev) =>
        prev.map((sh) =>
          sh._id === shift._id
            ? {
                ...sh,
                isActive: newStatus,
              }
            : sh
        )
      );
      alert(
        `Status toggled to ${newStatus ? "Active" : "Inactive"} successfully!`
      );
    } catch (err) {
      console.error(err);
      alert(err.response?.data?.error || "Failed to toggle status");
    }
  };

  // --- Search & Pagination (Unchanged) ---
  const [currentPage, setCurrentPage] = useState(1);
  const [recordsPerPage, setRecordsPerPage] = useState(20);

  const filteredShifts = useMemo(() => {
    if (!Array.isArray(shifts)) return [];

    return shifts.filter((shift) =>
      (shift?.description || "")
        .toLowerCase()
        .includes(searchTerm.toLowerCase())
    );
  }, [searchTerm, shifts]);

  const totalPages = Math.ceil(filteredShifts.length / recordsPerPage);
  const indexOfLast = currentPage * recordsPerPage;
  const indexOfFirst = indexOfLast - recordsPerPage;
  const currentRecords = filteredShifts.slice(indexOfFirst, indexOfLast);

  const getPageNumbers = () => {
    const pageNumbers = [];
    const maxPagesToShow = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxPagesToShow / 2));
    let endPage = Math.min(totalPages, startPage + maxPagesToShow - 1);
    if (endPage - startPage + 1 < maxPagesToShow) {
      startPage = Math.max(1, endPage - maxPagesToShow + 1);
    }
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(i);
    }
    return pageNumbers;
  };

  const getStatusBadge = (status) => {
    return status === true ? (
      <span className="px-3 py-1 bg-green-100 text-green-800 text-sm font-medium rounded-full">
        Active
      </span>
    ) : (
      <span className="px-3 py-1 bg-red-100 text-red-800 text-sm font-medium rounded-full">
        Inactive
      </span>
    );
  };

  // --- JSX Render ---

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50 p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header (unchanged) */}
        <div className="mb-8 text-center">
          <div className="flex justify-center items-center gap-3 mb-4">
            <div className="p-3 bg-gradient-to-r from-[#450693] to-[#8C00FF] rounded-2xl">
              <Clock className="text-white" size={32} />
            </div>
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-[#450693] to-[#8C00FF] bg-clip-text text-transparent">
            Shift Management
          </h1>
          <p className="text-gray-600 mt-2">Manage Employee Work Shifts</p>
        </div>

        {/* Controls Section (unchanged) */}
        <div className="bg-white rounded-2xl shadow-lg p-6 mb-6">
          <div className="flex flex-col lg:flex-row gap-4 justify-between items-start lg:items-center">
            {/* Search Bar */}
            <div className="relative flex-1 max-w-md">
              <Search
                className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                size={20}
              />
              <input
                type="text"
                placeholder="Search Shift..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-[#8C00FF] focus:border-transparent"
              />
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">Show:</span>
              <select
                value={recordsPerPage}
                onChange={(e) => setRecordsPerPage(Number(e.target.value))}
                className="border rounded px-2 py-1 text-sm"
              >
                <option value={10}>10</option>
                <option value={20}>20</option>
                <option value={40}>40</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
              <span className="text-sm text-gray-600">entries</span>
            </div>
            <button
              onClick={() => setShowAddForm(true)}
              className="flex items-center gap-2 bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] text-white px-6 py-3 rounded-xl font-semibold hover:opacity-90 transition-opacity"
            >
              <Plus size={20} />
              Add Shift
            </button>
          </div>
          <div className="mt-4 text-sm text-gray-600">
            Showing {filteredShifts.length} of {shifts.length} Shifts
          </div>
        </div>

        {/* Add Shift Form (Time Picker Added) */}
        {showAddForm && (
          <div className="bg-white rounded-2xl shadow-lg p-6 mb-6 border-2 border-[#8C00FF]">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-semibold text-[#450693]">
                Add New Shift
              </h3>
              <button
                onClick={handleCancelAdd}
                className="text-gray-400 hover:text-gray-600 transition-colors"
              >
                <X size={20} />
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4 items-end">
              {/* Shift Description */}
              <div className="lg:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Shift Description *
                </label>
                <input
                  type="text"
                  placeholder="e.g., Morning Shift"
                  value={newShift.description}
                  onChange={(e) =>
                    setNewShift({ ...newShift, description: e.target.value })
                  }
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF]"
                />
              </div>

              {/* Start Time (Time Picker) */}
              <div className="relative">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Start Time *
                </label>
                <input
                  type="time"
                  value={newShift.startTime}
                  onChange={(e) =>
                    setNewShift({ ...newShift, startTime: e.target.value })
                  }
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF] appearance-none pr-10"
                />
              </div>

              {/* End Time (Time Picker) */}
              <div className="relative">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  End Time *
                </label>
                <input
                  type="time"
                  value={newShift.endTime}
                  onChange={(e) =>
                    setNewShift({ ...newShift, endTime: e.target.value })
                  }
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF] appearance-none pr-10"
                />
              </div>

              {/* Display Order */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Order
                </label>
                <input
                  type="number"
                  min="0"
                  placeholder="Order"
                  value={newShift.order}
                  onChange={(e) =>
                    setNewShift({
                      ...newShift,
                      order: parseInt(e.target.value) || 0,
                    })
                  }
                  className="w-full p-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF]"
                />
              </div>

              <div className="flex flex-col gap-3">
                {/* Status Checkbox */}
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="newShiftStatus"
                    className="h-5 w-5 accent-[#8C00FF] cursor-pointer"
                    checked={newShift.isActive}
                    onChange={(e) =>
                      setNewShift({
                        ...newShift,
                        isActive: e.target.checked,
                      })
                    }
                  />
                  <label
                    htmlFor="newShiftStatus"
                    className="text-sm font-medium text-gray-700 cursor-pointer"
                  >
                    Active
                  </label>
                </div>

                {/* Default Checkbox */}
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="newShiftDefault"
                    className="h-5 w-5 accent-[#8C00FF] cursor-pointer"
                    checked={newShift.isDefault}
                    onChange={(e) =>
                      setNewShift({
                        ...newShift,
                        isDefault: e.target.checked,
                        isActive: e.target.checked ? true : newShift.isActive,
                      })
                    }
                  />
                  <label
                    htmlFor="newShiftDefault"
                    className="text-sm font-medium text-gray-700 cursor-pointer"
                  >
                    Set as Default
                  </label>
                </div>
              </div>

              <div className="flex gap-2 lg:col-span-6 mt-4">
                <button
                  onClick={handleAddShift}
                  className="flex-1 bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] text-white px-4 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
                >
                  Add Shift
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Shifts Table */}
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gradient-to-r from-[#450693] to-[#8C00FF] text-white">
                  <th className="p-4 text-left font-semibold">#</th>
                  <th className="p-4 text-left font-semibold">Order</th>
                  <th className="p-4 text-left font-semibold">
                    Shift Description
                  </th>
                  <th className="p-4 text-left font-semibold">Start Time</th>
                  <th className="p-4 text-left font-semibold">End Time</th>
                  <th className="p-4 text-center font-semibold">Status</th>
                  <th className="p-4 text-center font-semibold">Default</th>
                  <th className="p-4 text-center font-semibold">Actions</th>
                </tr>
              </thead>
              <tbody>
                {currentRecords.map((shift, index) => {
                  const isEditing = editingShift?._id === shift._id;

                  return (
                    <tr
                      key={shift._id}
                      className={`border-b hover:bg-gray-50 transition-colors ${
                        shift.isDefault
                          ? "bg-yellow-50 border-l-4 border-l-yellow-400"
                          : index % 2 === 0
                          ? "bg-white"
                          : "bg-gray-50"
                      }`}
                    >
                      {/* Serial Number & Order (Unchanged) */}
                      <td className="p-4 font-medium">
                        {indexOfFirst + index + 1}
                      </td>
                      <td className="p-4">
                        {isEditing ? (
                          <input
                            type="number"
                            min="0"
                            value={editingShift.order}
                            onChange={(e) =>
                              setEditingShift({
                                ...editingShift,
                                order: parseInt(e.target.value) || 0,
                              })
                            }
                            className="w-16 p-2 border border-gray-300 rounded-lg text-center focus:outline-none focus:ring-2 focus:ring-[#8C00FF]"
                          />
                        ) : (
                          <span className="inline-flex items-center justify-center w-8 h-8 bg-blue-100 text-blue-800 rounded-full text-sm font-medium">
                            {shift.order || 0}
                          </span>
                        )}
                      </td>

                      {/* Shift Description (Default Badge Added) */}
                      <td className="p-4">
                        <div className="flex items-center gap-2 w-full">
                          {isEditing ? (
                            <input
                              type="text"
                              value={editingShift.description}
                              onChange={(e) =>
                                setEditingShift({
                                  ...editingShift,
                                  description: e.target.value,
                                })
                              }
                              className="flex-1 p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF]"
                            />
                          ) : (
                            <>
                              <div className="font-medium text-gray-900">
                                {shift.description || "Missing Description"}
                              </div>

                              {shift.isDefault && (
                                <span className="bg-yellow-500 ml-2 text-white text-xs px-2 py-1 rounded-full font-medium">
                                  ⭐ Default
                                </span>
                              )}
                            </>
                          )}
                        </div>
                      </td>

                      <td className="p-4">
                        {isEditing ? (
                          <input
                            type="time" // ✅ Time Picker
                            value={editingShift.startTime}
                            onChange={(e) =>
                              setEditingShift({
                                ...editingShift,
                                startTime: e.target.value,
                              })
                            }
                            className="w-24 p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF] appearance-none"
                          />
                        ) : (
                          <span className="font-medium text-gray-700">
                            {formatTimeForDisplay(shift.startTime)}
                          </span>
                        )}
                      </td>

                      {/* End Time (Time Picker Input in Edit Mode) */}
                      <td className="p-4">
                        {isEditing ? (
                          <input
                            type="time" // ✅ Time Picker
                            value={editingShift.endTime}
                            onChange={(e) =>
                              setEditingShift({
                                ...editingShift,
                                endTime: e.target.value,
                              })
                            }
                            className="w-24 p-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#8C00FF] appearance-none"
                          />
                        ) : (
                          <span className="font-medium text-gray-700">
                            {/* Display time in 12hr format for user readability */}
                            {formatTimeForDisplay(shift.endTime)}
                          </span>
                        )}
                      </td>

                      {/* Status (isActive) */}
                      <td className="p-4 text-center">
                        {isEditing ? (
                          <input
                            type="checkbox"
                            className="h-5 w-5 accent-[#8C00FF] cursor-pointer"
                            checked={editingShift.isActive}
                            onChange={(e) =>
                              setEditingShift({
                                ...editingShift,
                                isActive: e.target.checked,
                              })
                            }
                          />
                        ) : (
                          getStatusBadge(shift.isActive)
                        )}
                      </td>

                      {/* Default */}
                      <td className="p-4 text-center">
                        {isEditing ? (
                          <input
                            type="checkbox"
                            className="h-5 w-5 accent-[#8C00FF] cursor-pointer"
                            checked={editingShift.isDefault}
                            onChange={(e) =>
                              setEditingShift({
                                ...editingShift,
                                isDefault: e.target.checked,
                                isActive: e.target.checked
                                  ? true
                                  : editingShift.isActive,
                              })
                            }
                          />
                        ) : shift.isDefault ? (
                          <span className="inline-flex items-center gap-1 text-yellow-600 font-medium">
                            <span className="w-2 h-2 bg-yellow-500 rounded-full"></span>
                            Yes
                          </span>
                        ) : (
                          <span className="text-gray-400">No</span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="p-4 text-center">
                        <div className="flex justify-center gap-2">
                          {isEditing ? (
                            <>
                              <button
                                onClick={handleSaveEdit}
                                className="flex items-center gap-1 bg-green-500 text-white px-3 py-2 rounded-lg hover:bg-green-600 transition-colors"
                              >
                                <Save size={16} />
                                Save
                              </button>
                              <button
                                onClick={handleCancelEdit}
                                className="flex items-center gap-1 bg-gray-500 text-white px-3 py-2 rounded-lg hover:bg-gray-600 transition-colors"
                              >
                                <X size={16} />
                                Cancel
                              </button>
                            </>
                          ) : (
                            <>
                              <button
                                onClick={() => handleEdit(shift)}
                                className="flex items-center gap-1 bg-[#FFC400] text-white p-2 rounded-lg hover:bg-[#E6B000] transition-colors"
                                title="Edit"
                              >
                                <Edit size={16} />
                              </button>

                              <button
                                onClick={() => handleToggleStatus(shift)}
                                className={`flex items-center justify-center p-2 rounded-lg text-white transition-colors ${
                                  shift.isActive
                                    ? "bg-gray-500 hover:bg-gray-600"
                                    : "bg-green-500 hover:bg-green-600"
                                }`}
                                title={
                                  shift.isActive ? "Deactivate" : "Activate"
                                }
                              >
                                {shift.isActive ? "Deactivate" : "Activate"}
                              </button>

                              <button
                                onClick={() => handleDelete(shift._id)}
                                className={`flex items-center gap-1 bg-red-500 text-white p-2 rounded-lg hover:bg-red-600 transition-colors`}
                                title="Delete"
                              >
                                <Trash2 size={16} />
                              </button>
                            </>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            {/* Empty State (unchanged) */}
            {currentRecords.length === 0 && (
              <div className="text-center py-12 text-gray-500">
                {searchTerm
                  ? "No shifts found matching your search."
                  : "No shifts available."}
              </div>
            )}
          </div>

          {/* Pagination (unchanged) */}
          {filteredShifts.length > 0 && (
            <div className="flex flex-col sm:flex-row justify-between items-center gap-4 p-6 border-t border-gray-200">
              <div className="text-sm text-gray-600">
                Showing {indexOfFirst + 1} to{" "}
                {Math.min(indexOfLast, filteredShifts.length)} of{" "}
                {filteredShifts.length} entries
              </div>

              <div className="flex items-center gap-2">
                {/* Pagination Controls */}
                <button
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(1)}
                  className="px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  First
                </button>

                <button
                  disabled={currentPage === 1}
                  onClick={() => setCurrentPage(currentPage - 1)}
                  className="flex items-center gap-1 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  <ChevronLeft size={16} />
                  Previous
                </button>

                {getPageNumbers().map((pageNumber) => (
                  <button
                    key={pageNumber}
                    onClick={() => setCurrentPage(pageNumber)}
                    className={`px-4 py-2 rounded-lg transition-colors ${
                      currentPage === pageNumber
                        ? "bg-gradient-to-r from-[#8C00FF] to-[#FF3F7F] text-white"
                        : "bg-white border border-gray-300 hover:bg-gray-50"
                    }`}
                  >
                    {pageNumber}
                  </button>
                ))}

                <button
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage(currentPage + 1)}
                  className="flex items-center gap-1 px-4 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Next
                  <ChevronRight size={16} />
                </button>

                <button
                  disabled={currentPage === totalPages}
                  onClick={() => setCurrentPage(totalPages)}
                  className="px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
                >
                  Last
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Shifts;
