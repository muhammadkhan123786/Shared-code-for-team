<?php

// Handle preflight OPTIONS request
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    header("Access-Control-Allow-Origin: *");
    header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
    header("Access-Control-Allow-Headers: Content-Type, Authorization");
    http_response_code(200);
    exit();
}

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'smtp/Exception.php';
require 'smtp/PHPMailer.php';
require 'smtp/SMTP.php';

header('Content-Type: application/json');

$response = ['sent' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $json = file_get_contents('php://input');
        $data = json_decode($json, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new Exception('Invalid JSON data');
        }

        $requiredFields = ['billing', 'shipping', 'paymentMethod', 'cartItems', 'shopSummary', 'orderId', 'deliveryDate'];
        
        foreach ($requiredFields as $field) {
            if (empty($data[$field])) {
                throw new Exception('All fields are required');
            }
        }

        $orderID = $data['orderId'];
        $deliveryDate = $data['deliveryDate'];
        $billing = $data['billing'];
        $shipping = $data['shipping'];
        $paymentMethod = htmlspecialchars(trim($data['paymentMethod']));
        $cartItems = $data['cartItems'];
        $shopSummary = $data['shopSummary']; 

        // Build cart items HTML for Admin email and calculate totals
        $cartItemsHTML = '';
        
        foreach ($cartItems as $item) {
            $itemTotal = $item['price'] * $item['quantity'];
            
            $cartItemsHTML .= "
                <tr>
                    <td>{$item['name']}</td>
                    <td>{$item['quantity']}</td>
                    <td>\${$item['price']}</td>
                    <td>\${$itemTotal}</td>
                </tr>
            ";
        }

        // Admin Email HTML (including cart items and total)
        $htmlAdmin = <<<HTML
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Order Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }
        .email-container {
            max-width: 700px;
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin: auto;
            border: 1px solid #e0e0e0;
        }
        .email-header {
            background-image: linear-gradient(144deg, #c40e00, #e63900, #c40e00);
            color: #FFFFFF;
            text-align: center;
            padding: 20px;
            font-size: 24px;
            font-weight: bold;
            border-radius: 6px 6px 0 0;
            margin: -30px -30px 20px -30px;
        }
        .section-title {
            background: #f5f5f5;
            font-size: 18px;
            font-weight: bold;
            padding: 12px 15px;
            margin: 25px 0 15px 0;
            border-radius: 6px;
            color: #c40e00;
            border-left: 4px solid #c40e00;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
            font-size: 16px;
        }
        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid #e0e0e0;
            text-align: left;
        }
        th {
            background: #f9f9f9;
            font-weight: 600;
            width: 30%;
        }
        .total-row {
            font-weight: bold;
            background: #f9f9f9;
        }
        .footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
            font-size: 14px;
            color: #666;
            text-align: center;
        }
    </style>
</head>
<body>

<div class='email-container'>
    <div class='email-header'>New Order Notification</div>

    <!-- Order ID and Delivery Date -->
    <div class='section-title'>Order Details</div>
    <table>
        <tr><th>Order ID:</th><td>{$orderID}</td></tr>
        <tr><th>Estimated Delivery Date:</th><td>{$deliveryDate}</td></tr>
    </table>

    <!-- Billing Details -->
    <div class='section-title'>Billing Information</div>
    <table>
        <tr><th>First Name:</th><td>{$billing['firstName']}</td></tr>
        <tr><th>Last Name:</th><td>{$billing['lastName']}</td></tr>
        <tr><th>Company:</th><td>{$billing['company']}</td></tr>
        <tr><th>Country:</th><td>{$billing['country']}</td></tr>
        <tr><th>Address:</th><td>{$billing['address']}</td></tr>
        <tr><th>City:</th><td>{$billing['city']}</td></tr>
        <tr><th>ZIP Code:</th><td>{$billing['zip']}</td></tr>
        <tr><th>Phone:</th><td>{$billing['phone']}</td></tr>
        <tr><th>Email:</th><td>{$billing['email']}</td></tr>
    </table>

    <!-- Shipping Details -->
    <div class='section-title'>Shipping Information</div>
    <table>
        <tr><th>First Name:</th><td>{$shipping['firstName']}</td></tr>
        <tr><th>Last Name:</th><td>{$shipping['lastName']}</td></tr>
        <tr><th>Company:</th><td>{$shipping['company']}</td></tr>
        <tr><th>Country:</th><td>{$shipping['country']}</td></tr>
        <tr><th>Address:</th><td>{$shipping['address']}</td></tr>
        <tr><th>City:</th><td>{$shipping['city']}</td></tr>
        <tr><th>ZIP Code:</th><td>{$shipping['zip']}</td></tr>
        <tr><th>Phone:</th><td>{$shipping['phone']}</td></tr>
        <tr><th>Email:</th><td>{$shipping['email']}</td></tr>
    </table>

    <!-- Payment Method -->
    <div class='section-title'>Payment Details</div>
    <table>
        <tr><th>Payment Method:</th><td>{$paymentMethod}</td></tr>
    </table>

    <!-- Cart Items -->
    <div class='section-title'>Order Summary</div>
    <table>
        <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Total</th>
        </tr>
        {$cartItemsHTML}
    </table>

    <!-- Order Summary -->
    <div class='section-title'>Payment Summary</div>
    <table>
        <tr><th>Sub Total:</th><td>\${$shopSummary['subTotal']}</td></tr>
        <tr><th>Items Discount:</th><td>\${$shopSummary['discountedAmount']}</td></tr>
        <tr><th>Coupon Discount:</th><td>\${$shopSummary['couponDiscount']}</td></tr>
        <tr><th>Tax:</th><td>\${$shopSummary['taxAmount']}</td></tr>
        <tr><th>Delivery Fee:</th><td>\${$shopSummary['deliveryFee']}</td></tr>
        <tr class='total-row'><th>Total:</th><td>\${$shopSummary['cartTotal']}</td></tr>
    </table>

    <div class='footer'>
        <p>This order was received through the Falcon Cricket Club Shop</p>
    </div>
</div>

</body>
</html>
HTML;

        // Client Email HTML (including cart items and total)
        $htmlClient = <<<HTML
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Order Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }
        .email-container {
            max-width: 700px;
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin: auto;
            border: 1px solid #e0e0e0;
        }
        .email-header {
            background-image: linear-gradient(144deg, #c40e00, #e63900, #c40e00);
            color: #FFFFFF;
            text-align: center;
            padding: 20px;
            font-size: 24px;
            font-weight: bold;
            border-radius: 6px 6px 0 0;
            margin: -30px -30px 20px -30px;
        }
        .section-title {
            background: #f5f5f5;
            font-size: 18px;
            font-weight: bold;
            padding: 12px 15px;
            margin: 25px 0 15px 0;
            border-radius: 6px;
            color: #c40e00;
            border-left: 4px solid #c40e00;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
            font-size: 16px;
        }
        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid #e0e0e0;
            text-align: left;
        }
        th {
            background: #f9f9f9;
            font-weight: 600;
            width: 30%;
        }
        .total-row {
            font-weight: bold;
            background: #f9f9f9;
        }
        .footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
            font-size: 14px;
            color: #666;
            text-align: center;
        }
    </style>
</head>
<body>

<div class='email-container'>
    <div class='email-header'>Order Confirmation</div>

    <p>Dear {$billing['firstName']} {$billing['lastName']},</p>
    <p>Thank you for your order at Falcon Cricket Club Shop! Below are your details:</p>

    <!-- Order ID and Delivery Date -->
    <div class='section-title'>Order Details</div>
    <table>
        <tr><th>Order ID:</th><td>{$orderID}</td></tr>
        <tr><th>Estimated Delivery Date:</th><td>{$deliveryDate}</td></tr>
    </table>

    <!-- Billing Details -->
    <div class='section-title'>Billing Information</div>
    <table>
        <tr><th>First Name:</th><td>{$billing['firstName']}</td></tr>
        <tr><th>Last Name:</th><td>{$billing['lastName']}</td></tr>
        <tr><th>Company:</th><td>{$billing['company']}</td></tr>
        <tr><th>Country:</th><td>{$billing['country']}</td></tr>
        <tr><th>Address:</th><td>{$billing['address']}</td></tr>
        <tr><th>City:</th><td>{$billing['city']}</td></tr>
        <tr><th>ZIP Code:</th><td>{$billing['zip']}</td></tr>
        <tr><th>Phone:</th><td>{$billing['phone']}</td></tr>
        <tr><th>Email:</th><td>{$billing['email']}</td></tr>
    </table>

    <!-- Shipping Details -->
    <div class='section-title'>Shipping Information</div>
    <table>
        <tr><th>First Name:</th><td>{$shipping['firstName']}</td></tr>
        <tr><th>Last Name:</th><td>{$shipping['lastName']}</td></tr>
        <tr><th>Company:</th><td>{$shipping['company']}</td></tr>
        <tr><th>Country:</th><td>{$shipping['country']}</td></tr>
        <tr><th>Address:</th><td>{$shipping['address']}</td></tr>
        <tr><th>City:</th><td>{$shipping['city']}</td></tr>
        <tr><th>ZIP Code:</th><td>{$shipping['zip']}</td></tr>
        <tr><th>Phone:</th><td>{$shipping['phone']}</td></tr>
        <tr><th>Email:</th><td>{$shipping['email']}</td></tr>
    </table>

    <!-- Payment Method -->
    <div class='section-title'>Payment Details</div>
    <table>
        <tr><th>Payment Method:</th><td>{$paymentMethod}</td></tr>
    </table>

    <!-- Cart Items -->
    <div class='section-title'>Order Summary</div>
    <table>
        <tr>
            <th>Product</th>
            <th>Quantity</th>
            <th>Price</th>
            <th>Total</th>
        </tr>
        {$cartItemsHTML}
    </table>

    <!-- Order Summary -->
    <div class='section-title'>Payment Summary</div>
    <table>
        <tr><th>Sub Total:</th><td>\${$shopSummary['subTotal']}</td></tr>
        <tr><th>Items Discount:</th><td>\${$shopSummary['discountedAmount']}</td></tr>
        <tr><th>Coupon Discount:</th><td>\${$shopSummary['couponDiscount']}</td></tr>
        <tr><th>Tax:</th><td>\${$shopSummary['taxAmount']}</td></tr>
        <tr><th>Delivery Fee:</th><td>\${$shopSummary['deliveryFee']}</td></tr>
        <tr class='total-row'><th>Total:</th><td>\${$shopSummary['cartTotal']}</td></tr>
    </table>

    <p>If you have any questions, please contact us.</p>
    
    <div class='footer'>
        <p>Falcon Cricket Club Shop</p>
    </div>
</div>

</body>
</html>
HTML;

        // Send emails
        $mail = new PHPMailer(true);

        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'your_email@gmail.com';
        $mail->Password = 'Your App Password';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('your_email@gmail.com', 'Falcon Cricket Club');
        $mail->addAddress('your_email@gmail.com', 'Falcon Cricket Club');
        $mail->isHTML(true);
        $mail->Subject = 'New Order Request';
        $mail->Body = $htmlAdmin;

        if (!$mail->send()) {
            throw new Exception('Admin email could not be sent. Mailer Error: ' . $mail->ErrorInfo);
        }

        $mail->clearAddresses();
        $mail->addAddress($billing['email'], $billing['firstName'] . ' ' . $billing['lastName']);
        $mail->Subject = 'Your Order Confirmation - Falcon Cricket Club';
        $mail->Body = $htmlClient;

        if ($mail->send()) {
            $response['sent'] = true;
            $response['message'] = 'Order Submitted Successfully! Thank you for your purchase.';
            http_response_code(200);
        } else {
            throw new Exception('Confirmation email could not be sent. Mailer Error: ' . $mail->ErrorInfo);
        }
    } catch (Exception $e) {
        http_response_code(500);
        $response['message'] = $e->getMessage();
    }
} else {
    http_response_code(405);
    $response['message'] = 'Method not allowed';
}

echo json_encode($response);
exit();
?>