<?php

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'smtp/Exception.php';
require 'smtp/PHPMailer.php';
require 'smtp/SMTP.php';

header('Content-Type: application/json');

$response = ['sent' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (empty($_POST['email'])) {
            throw new Exception('Email address is required');
        }

        $user_email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        if (!filter_var($user_email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception('Invalid email format');
        }

        // Admin email setup
        $adminMail = new PHPMailer(true);
        $adminMail->isSMTP();
        $adminMail->Host = 'smtp.gmail.com';
        $adminMail->SMTPAuth = true;
        $adminMail->Username = 'your_email@gmail.com';
        $adminMail->Password = 'Your App Password';
        $adminMail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $adminMail->Port = 587;
        
        $adminMail->setFrom('your_email@gmail.com', 'Falcon Cricket Club');
        $adminMail->addAddress('your_email@gmail.com', 'Falcon Cricket Club');
        
        $adminMail->isHTML(true);
        $adminMail->Subject = 'New Newsletter Subscriber';
        $adminMail->Body = "
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>New Subscriber</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }
        .email-container {
            max-width: 500px;
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin: auto;
            border: 1px solid #e0e0e0;
        }
        .email-header {
            background-image: linear-gradient(144deg, #c40e00, #e63900, #c40e00);
            color: #FFFFFF;
            text-align: center;
            padding: 20px;
            font-size: 24px;
            font-weight: bold;
            border-radius: 6px 6px 0 0;
            margin: -30px -30px 20px -30px;
        }
        .content {
            font-size: 16px;
            padding: 15px;
            line-height: 1.6;
        }
        .footer {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
            font-size: 14px;
            color: #666;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class='email-container'>
        <div class='email-header'>New Newsletter Subscriber</div>
        <div class='content'>
            <p><strong>Email:</strong> $user_email</p>
        </div>
        <div class='footer'>
            <p>This is an automated notification from Falcon Cricket Club</p>
        </div>
    </div>
</body>
</html>";

        
        if (!$adminMail->send()) {
            throw new Exception('Admin notification failed: ' . $adminMail->ErrorInfo);
        }

        // User email setup (new instance)
        $userMail = new PHPMailer(true);
        $userMail->isSMTP();
        $userMail->Host = 'smtp.gmail.com';
        $userMail->SMTPAuth = true;
        $userMail->Username = 'your_email@gmail.com';
        $userMail->Password = 'Your App Password';
        $userMail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $userMail->Port = 587;
        $userMail->setFrom('your_email@gmail.com', 'Falcon Cricket Club');
        $userMail->addAddress($user_email);
        $userMail->isHTML(true);
        $userMail->Subject = 'Newsletter Subscription Confirmation';
        $userMail->Body = "
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Subscription Confirmation</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
        }
        .email-container {
            max-width: 500px;
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin: auto;
            border: 1px solid #e0e0e0;
        }
        .email-header {
            background-image: linear-gradient(144deg, #c40e00, #e63900, #c40e00);
            color: #FFFFFF;
            text-align: center;
            padding: 20px;
            font-size: 24px;
            font-weight: bold;
            border-radius: 6px 6px 0 0;
            margin: -30px -30px 20px -30px;
        }
        .content {
            font-size: 16px;
            padding: 15px;
            line-height: 1.6;
        }
        .footer {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
            font-size: 14px;
            color: #666;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class='email-container'>
        <div class='email-header'>Subscription Confirmed</div>
        <div class='content'>
            <p>Hello Cricket Enthusiast,</p>
            <p>Thank you for subscribing to Falcon Cricket Club's newsletter! You'll receive updates at:</p>
            <p><strong>$user_email</strong></p>
            <p>Stay tuned for the latest match schedules, player updates, and club events.</p>
        </div>
        <div class='footer'>
            <p>© " . date('Y') . " Falcon Cricket Club. All rights reserved.</p>
        </div>
    </div>
</body>
</html>";


        if ($userMail->send()) {
            $response['sent'] = true;
            $response['message'] = 'Thank you for subscribing to our newsletter!';
            http_response_code(200);
        } else {
            throw new Exception('Confirmation email failed: ' . $userMail->ErrorInfo);
        }
    } catch (Exception $e) {
        http_response_code(500);
        $response['message'] = $e->getMessage();
    }
} else {
    http_response_code(405);
    $response['message'] = 'Invalid request method';
}

echo json_encode($response);
exit();
?>