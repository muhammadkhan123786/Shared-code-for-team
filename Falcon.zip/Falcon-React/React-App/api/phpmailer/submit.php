<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, GET, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'smtp/Exception.php';
require 'smtp/PHPMailer.php';
require 'smtp/SMTP.php';

header('Content-Type: application/json');

$response = ['sent' => false, 'message' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Define required fields
        $requiredFields = ['name', 'email', 'number', 'message'];

        // Validate required fields
        foreach ($requiredFields as $field) {
            if (empty($_POST[$field])) {
                throw new Exception("$field is required");
            }
        }

        // Sanitize input data
        $name = htmlspecialchars(trim($_POST['name']));
        $email = htmlspecialchars(trim($_POST['email']));
        $phoneNumber = htmlspecialchars(trim($_POST['number']));
        $message = htmlspecialchars(trim($_POST['message']));

        // Validate email format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format");
        }

        // Admin Email HTML - Cricket Club Version
        $htmlAdmin = "
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>New Cricket Club Inquiry</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .email-container {
            max-width: 700px;
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
            border: 1px solid #e0e0e0;
        }
        .email-header {
            background-image: linear-gradient(144deg, #c40e00, #e63900, #c40e00);
            color: #FFFFFF;
            text-align: center;
            padding: 20px;
            font-size: 24px;
            font-weight: bold;
            border-radius: 6px 6px 0 0;
            margin: -30px -30px 20px -30px;
        }
        .section-title {
            background: #f5f5f5;
            font-size: 18px;
            font-weight: bold;
            padding: 12px 15px;
            margin: 25px 0 15px 0;
            border-radius: 6px;
            color: #c40e00;
            border-left: 4px solid #c40e00;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin: 15px 0;
            font-size: 16px;
        }
        th, td {
            padding: 12px 15px;
            border-bottom: 1px solid #e0e0e0;
            text-align: left;
        }
        th {
            background: #f9f9f9;
            font-weight: 600;
            width: 30%;
        }
        p {
            line-height: 1.6;
            margin: 0 0 15px 0;
            font-size: 16px;
        }
        .footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
            font-size: 14px;
            color: #666;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class='email-container'>
        <div class='email-header'>New Falcon Cricket Club Inquiry</div>

        <div class='section-title'>Visitor Information</div>
        <table>
            <tr><th>Name:</th><td>$name</td></tr>
            <tr><th>Email:</th><td>$email</td></tr>
            <tr><th>Phone Number:</th><td>$phoneNumber</td></tr>
        </table>

        <div class='section-title'>Message Details</div>
        <p>" . nl2br($message) . "</p>

        <div class='footer'>
            <p>This inquiry was received through the Falcon Cricket Club contact form</p>
        </div>
    </div>
</body>
</html>";

        // Client Email HTML - Cricket Club Version
        $htmlClient = "
<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>Thank You for Contacting Falcon Cricket Club</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .email-container {
            max-width: 600px;
            background: #ffffff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            margin: 20px auto;
            border: 1px solid #e0e0e0;
        }
        .header {
            background-image: linear-gradient(144deg, #c40e00, #e63900, #c40e00);
            color: #FFFFFF;
            text-align: center;
            padding: 25px;
            border-radius: 6px 6px 0 0;
            margin: -30px -30px 25px -30px;
        }
        .header h2 {
            margin: 0;
            font-size: 28px;
        }
        .header p {
            margin: 10px 0 0 0;
            font-size: 18px;
        }
        .content {
            margin: 25px 0;
            font-size: 16px;
            line-height: 1.6;
        }
        .details {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 6px;
            margin: 20px 0;
            border-left: 4px solid #c40e00;
        }
        .details h3 {
            margin-top: 0;
            color: #c40e00;
        }
        ol {
            padding-left: 20px;
        }
        li {
            margin-bottom: 10px;
        }
        .highlight {
            color: #c40e00;
            font-weight: bold;
        }
        .footer {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
            font-size: 14px;
            color: #666;
            text-align: center;
        }
        .signature {
            margin-top: 25px;
            font-style: italic;
            color: #555;
        }
    </style>
</head>
<body>
    <div class='email-container'>
        <div class='header'>
            <h2>Thank You, $name!</h2>
            <p>We've received your inquiry</p>
        </div>
        
        <div class='content'>
            <p>Dear Cricket Enthusiast,</p>
            <p>Thank you for contacting <strong>Falcon Cricket Club</strong>. We appreciate your message and will respond as soon as possible.</p>
            
            <div class='details'>
                <h3>Your Message:</h3>
                <p>" . nl2br($message) . "</p>
            </div>

            <p>Our team will review your inquiry and respond within <strong>24 hours</strong>.</p>
            
            <h3>What to Expect Next:</h3>
            <ol>
                <li>Your message will be reviewed by our management team</li>
                <li>You'll receive a personalized response from our staff</li>
                <li>If needed, we may contact you for further details</li>
            </ol>

            <div class='signature'>
                <p>Thank you for reaching out to us,</p>
                <p><strong>The Falcon Cricket Club Team</strong></p>
            </div>
        </div>

        <div class='footer'>
            <p>Need immediate assistance? Call us at <span class='highlight'>+1 (555) 123-4567</span> or reply to this email</p>
            <p>© " . date('Y') . " Falcon Cricket Club. All rights reserved.</p>
        </div>
    </div>
</body>
</html>";

        // Send emails using PHPMailer (keeping original SMTP settings)
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'your_email@gmail.com';
        $mail->Password = 'Your App Password';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        // Admin email
        $mail->setFrom('your_email@gmail.com', 'Falcon Cricket Club');
        $mail->addAddress('your_email@gmail.com', 'Falcon Cricket Club');
        $mail->isHTML(true);
        $mail->Subject = 'New Cricket Club Inquiry from ' . $name;
        $mail->Body = $htmlAdmin;
        $mail->send();

        // Client confirmation email
        $mail->clearAddresses();
        $mail->addAddress($email, $name);
        $mail->Subject = 'Thank You for Contacting Falcon Cricket Club';
        $mail->Body = $htmlClient;

        if ($mail->send()) {
            $response['sent'] = true;
            $response['message'] = 'Your inquiry has been submitted successfully! Thank you for contacting us.';
            http_response_code(200);
        } else {
            throw new Exception('Confirmation email could not be sent. Mailer Error: ' . $mail->ErrorInfo);
        }
    } catch (Exception $e) {
        http_response_code(400);
        $response['message'] = $e->getMessage();
    }
} else {
    http_response_code(405);
    $response['message'] = 'Method not allowed';
}

echo json_encode($response);
exit();
?>