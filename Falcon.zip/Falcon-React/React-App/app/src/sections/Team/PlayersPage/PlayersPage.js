import React from 'react';

import { PageTitle, Team } from '../../../components';



const PlayersPage = () => {

  return ( 
    <>

      {/* Page title */}
      <PageTitle title={'Players'} page={'Players'} />  

      {/* Players Section */}
      <Team showCoaches={false} />

    </>

  )
  
}

export default PlayersPage;