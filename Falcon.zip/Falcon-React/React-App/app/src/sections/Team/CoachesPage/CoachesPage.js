import React from 'react';

import { PageTitle } from '../../../components';
import { Coaches } from '../..';



const CoachesPage = () => {
  
  return ( 
    <>

      {/* Page title */}
      <PageTitle title={'Coaches'} page={'Coaches'} />  

      {/* Coaches Section */}
      <Coaches />

    </>
  )
  
}

export default CoachesPage;