import React from 'react';


import { PageTitle, Team } from '../../../components';



const TeamPage = () => {

  return (
    <>

      {/* Page title */}
      <PageTitle title={'Team'} page={'Team'} />  

      {/* Team Section */}
      <Team />

    </>

  );
};

export default TeamPage;