import React from 'react';

import { PageTitle } from '../../../components';
import { FAQs } from '../../../sections';



const FaqPage = () => {

  return (
    <>

      {/* Page title */}
      <PageTitle title={'faqs'} page={'faqs'} />

      {/* FAQs Section */}
      <FAQs />

    </>
  );
};

export default FaqPage;