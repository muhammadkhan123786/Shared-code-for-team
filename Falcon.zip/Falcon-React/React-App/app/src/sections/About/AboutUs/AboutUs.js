import React from 'react';
import './AboutUs.css';

import { PageTitle } from '../../../components';
import { About, Testimonials, Counter, Sponsors, PortfolioSection, Coaches, Trophies } from '../../../sections';



const AboutUs = () => {

  return (
    <>

      {/* Page title */}
      <PageTitle title={'about us'} page={'about us'} />

      <section className='about-us'>

        <About />
        <Counter />
        <Coaches />
        <Trophies />
        <PortfolioSection />
        <Testimonials />
        <Sponsors />

      </section>

    </>
  );
}

export default AboutUs;