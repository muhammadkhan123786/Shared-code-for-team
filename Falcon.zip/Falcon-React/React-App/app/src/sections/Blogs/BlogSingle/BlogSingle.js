import React from 'react';
import './BlogSingle.css';

// Importing necessary components, utilities, and icons
import { Comments, Lightbox, PageTitle, UniversalSidebar } from '../../../components';
import { blogContent } from '../../../constants';
import { countCommentsAndReplies, extractDateParts, useFilter } from '../../../utils';

import { FaFacebookF, FaInstagram, FaLinkedin, FaUserCircle, FaQuoteLeft, FaComment } from 'react-icons/fa';
import { FaXTwitter } from 'react-icons/fa6';

import { Link, useLocation } from "react-router-dom";



const BlogSingle = () => {

  // Extract necessary data and functions from the `useFilter` custom hook
  const {
    selectedCategory,   // Currently selected category filter
    selectedTag,        // Currently selected tag filter
    handleSearchSubmit, // Function to handle search form submission
  } = useFilter(blogContent, 'blog'); // Passing 'blog' as the type

  // Get the current location and extract the blog data passed via state
  const location = useLocation();
  const blog = location.state;

  // Extract comments from the blog data
  const blogComments = blog.comments;
  const totalComments = countCommentsAndReplies(blogComments);

  // Handle form submission for the comment form
  const handleSubmit = (event) => {
    event.preventDefault(); // Prevent the default form submission behavior
    event.target.reset(); // Reset the form fields
  };

  const { weekday, day, shortMonth } = extractDateParts(blog.date); // Extracting formatted date parts using utility function

  return (
    <>
      {/* Page title */}
      <PageTitle title={blog.heading} page={"blog single"} />

      {/* Blog Single Section */}
      <section className='blog-single'>

        <div className='blog-container'>

          <div className='blog-info page-info' key={blog.id}>

            <div className='image'>
              <img src={blog.image} alt={blog.heading} /> {/* Blog image */}
              <div className="date">{weekday} <br></br> <span>{day}</span> <br></br> {shortMonth}</div> {/* Blog Date */}
            </div>

            <div className='content'>

              {/* Blog Details */}
              <div className='details'>
                <Link className='label' to={`/Blogs/category/${blog.category}`}>{blog.category}</Link> {/* Blog category with navigation link */}
                <h3><div className='icon'><FaUserCircle /></div><span>By {blog.admin}</span> </h3> {/* Blog author */}
                <h3><div className='icon'><FaComment /></div><span>{totalComments} Comments</span></h3> {/* Blog Comments Length */}
              </div>

              <h3 className='main-heading'>{blog.heading}</h3> {/* Blog heading */}

              {/* Blog Paragraphs */}
              <p>{blog.paragraph.para1}</p>
              <p>{blog.paragraph.para2}</p>

              {/* Important Quote Section */}
              <div className="imp">
                <div className="icon"><FaQuoteLeft /></div>
                <div className='box-container'>
                  "{blog.important.content}" {/* Quote content */}
                  <div className='intro'>
                    <span></span>
                    <h6>{blog.important.intro}</h6> {/* Quote author */}
                  </div>
                </div>
              </div>

              <p>{blog.paragraph.para3}</p>

              {/* Lightbox Gallery for Blog Images */}
              <Lightbox images={blog.gallery} />

              <p>{blog.paragraph.para4}</p>

              <div className='end-details'>

                {/* Blog tags */}
                <div className='tags'>
                  {blog.tags.map((item, index) => (
                    <Link
                      className='item'
                      key={index}
                      to={`/Blogs/tag/${item}`}>
                      {item}
                    </Link>
                  ))}
                </div> 

                {/* Share buttons */}
                <div className='share'>
                  <h3>share:</h3>
                  <a href="/#" ><div className='icon'><FaFacebookF /></div></a> {/* Facebook share link */}
                  <a href="/#" ><div className='icon'><FaLinkedin /></div></a> {/* Linkedin share link */}
                  <a href="/#" ><div className='icon'><FaXTwitter /></div></a> {/* XTwitter share link */}
                  <a href="/#" ><div className='icon'><FaInstagram /></div></a> {/* Instagram share link */}
                </div>
                
              </div>
            </div>
          </div>

          {/* Comments section */}
          <Comments comments={blogComments} showReplyIcon={true} />

          {/* Leave a comment */}
          <div className='leave-reply'>
            <form className='form' onSubmit={handleSubmit}>
              <h3>leave a comment</h3> {/* Heading for the comment form */}
              <div className='input-box'>
                <input type="text" name="name" className='box' id="name" placeholder="name" required /> {/* Input field for name */}
                <input type="email" name="email" className='box' id="email" placeholder="email" required /> {/* Input field for email */}
              </div>
              <textarea cols="30" rows="10" name="comment" className='box' id="comment" placeholder="comment"></textarea> {/* Textarea for the comment */}
              <button type="submit" name="submit" id="submit" className='btn'>submit</button> {/* Submit button */}
            </form>
          </div>

        </div>

        {/* Blog Sidebar */}
        <UniversalSidebar
          type="blog"
          selectedCategory={selectedCategory}
          selectedTag={selectedTag}
          handleSubmit={handleSearchSubmit}
        />

      </section>

    </>

  )
}

export default BlogSingle;