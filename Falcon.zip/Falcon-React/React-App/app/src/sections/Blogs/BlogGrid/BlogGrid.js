import React from 'react';
import './BlogGrid.css';

// Importing necessary components and utilities
import { PageTitle, Blog, PagesNo, UniversalSidebar, EmptyState } from '../../../components';
import { blogContent } from '../../../constants';
import { useFilter, useFilterLoading } from '../../../utils';

import { FaRegNewspaper } from 'react-icons/fa';



const BlogGrid = () => {

  // Number of blog items to display per page
  const itemsPerPage = 6;

  // Fetch filtered and paginated blog data using the custom hook `useFilter`
  const {
    selectedCategory,   // Currently selected category filter
    selectedTag,        // Currently selected tag filter
    searchKeyword,      // Current search keyword
    filteredItems,      // List of blog items after applying filters
    displayedItems,     // Blog items to display on the current page
    currentPage,        // Current page number
    totalPages,         // Total number of pages
    handleSearchSubmit, // Function to handle search form submission
    handlePageChange,   // Function to handle page change in pagination
  } = useFilter(blogContent, itemsPerPage, 'blog');

  // Use the custom hook `useFilterLoading` to determine if filtering is in progress
  const isFiltering = useFilterLoading(filteredItems, searchKeyword);

  return (
    <>
      {/* Page title */}  
      <PageTitle title={'blog grid'} page={'blog grid'} />

      {/* Blog grid section */}
      <section className='blog grid'>

        {/* Universal sidebar for filtering blogs by category, tag, or search */}
        <UniversalSidebar
          type="blog"
          selectedCategory={selectedCategory}
          selectedTag={selectedTag}
          handleSubmit={handleSearchSubmit}
        />

        {/* Blog Container (Grid Layout) */}
        <div className='blog-container grid'>
          {isFiltering ? null : filteredItems.length === 0 ? (
            <EmptyState
              icon={FaRegNewspaper} 
              title={`No blogs found for "${searchKeyword}"`} 
              message="We couldn’t find any blog posts matching your search. Try different keywords or explore all articles." 
              buttonLink="Blog-grid" 
              buttonText="Browse All Blogs"
            />
          ) : (
            // Display blog items and pagination if results are found
            <>

              {/* List of blog items */}
              <div className='blog-items'>
                {displayedItems.map((blog) => (
                  <Blog key={blog.id} blog={blog} />
                ))}
              </div>

              {/* Pagination */}
              <PagesNo
                currentPage={currentPage}
                totalPages={totalPages}
                handlePageChange={handlePageChange}
              />

            </>
          )}
        </div>
      </section>
    </>
  );
};

export default BlogGrid;