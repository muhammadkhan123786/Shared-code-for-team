import { useLocation } from 'react-router-dom';
import './OrderConfirmation.css';

import { EmptyState, Heading, PageTitle, ShopSummary, ShopTitle } from '../../../components';
import { FaBoxOpen, FaCheckCircle } from 'react-icons/fa';



const OrderConfirmation = () => {

    // Access the location object to retrieve order data passed via route state
    const location = useLocation();
    const orderData = location.state?.orderData;

    // If no order data is found, display the empty state
    if (!orderData) {
        return (
            <>
            <PageTitle title={'Order Confirmation'} page={'Order Confirmation'} />
            <EmptyState 
                icon={FaBoxOpen} 
                title="No Orders Yet" 
                message="You haven't placed any orders yet. Start shopping to place your first order." 
                buttonLink="Shop-List" 
                buttonText="Shop Now" 
            />
        </>
        );
    }

    return (

        <>

            <PageTitle title={'Order Confirmation'} page={'Order Confirmation'} />
            
            <section className="order-details">

                {/* Order Success Message */}
                <div className="order-message order-details-item">
                    <FaCheckCircle className='icon' />
                    <span>Thank you for your order, {orderData.billing.firstName} {orderData.billing.lastName} </span>
                </div>

                {/* Address Details */}
                <div className="address-details order-details-item">

                    <Heading title='Address Details' sideHeading />
                    <div className="box-container">

                        {/* Map over billing and shipping addresses */}
                        {["Shipping Address", "Billing Address"].map((title, index) => {
                            const address = index === 0 ? orderData.shipping : orderData.billing;
                            return (
                            <div key={index} className="address">
                                <h3 className="title">{title}</h3>
                                <p><span>{address.firstName} {address.lastName}</span></p>
                                <p><span>Country:</span> {address.country}</p>
                                <p><span>City:</span> {address.city}</p>
                                <p><span>ZIP:</span> {address.zip}</p>
                                <p><span>Address:</span> {address.address}</p>
                                <p><span>Email:</span> {address.email}</p>
                                <p><span>Phone:</span> {address.phone}</p>
                            </div>
                            );
                        })}

                    </div>

                </div>

                {/* Order Items Section */}
                <div className='order-items order-details-item order-container'>
                    <div className='container'>

                        <Heading title='Order Items' sideHeading />

                        <ShopTitle titles={['product', 'Price', 'Quantity', 'Total']} />

                        {/* Display each item in the order */}
                        <div className='box-container'>
                            {orderData.cartItems.map((item, index) => (
                            <div key={index} className="order-item">
                                <div className="box product">
                                    <img src={item.image} alt={item.name} className="w-12 h-12" />
                                    <span>{item.name}</span>
                                </div>
                                <div className='box price'>${item.price.toFixed(2)}</div>
                                <div className='box quantity'>{item.quantity}</div>
                                <div className='box total'>${(item.price * item.quantity).toFixed(2)}</div>
                            </div>
                            ))}
                        </div>

                    </div>
                </div>

                {/* Order Summary Section */}
                <div className='cart-total order-details-item'>
                    <Heading title='Order Summary' sideHeading /> 

                    <div className='order-intro'>
                        <div className='order-id'>{orderData.orderId}</div> {/* Order ID */}
                        <div className='delivery'>{orderData.deliveryDate}</div> {/* Delivery Date */}
                    </div>

                    <ShopSummary cart={orderData.cartItems} discount={orderData.discount} /> {/* Shop summary */} 
                </div>

            </section>

        </>

    );
};

export default OrderConfirmation;