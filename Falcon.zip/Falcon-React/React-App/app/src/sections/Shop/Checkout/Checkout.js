import React, { useState, useEffect } from 'react';
import './Checkout.css';

import { PageTitle, Heading, ShopSummary, EmptyState, showSuccessToast } from '../../../components';
import { payment } from '../../../constants';
import { calculateDeliveryDate, generateOrderId, useCart } from '../../../utils';

import axios from "axios"; // Import axios for making HTTP requests
import { useNavigate } from 'react-router-dom'; // Import useNavigate from react-router-dom for navigation

import { FaCreditCard } from 'react-icons/fa';




// API endpoint for submitting the checkout form
const API_PATH = 'https://www.example.com/api/phpmailer/checkout.php';

// Regex patterns for email, phone, and ZIP code validation
const EMAIL_REGEX = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
const PHONE_REGEX = /^[+]?[(]?[0-9]{1,4}[)]?[-\s./0-9]*$/;
const ZIP_REGEX = /^\d{5}(?:[-\s]\d{4})?$/;



const Checkout = () => {

  const navigate = useNavigate();

  // Destructuring cart actions and state from useCart
  const { cart, clearCart, discount } = useCart();

  // State to manage form data for billing and shipping addresses
  const [formData, setFormData] = useState({
    billing: {
      firstName: '',
      lastName: '',
      company: '',
      country: '',
      address: '',
      city: '',
      zip: '',
      phone: '',
      email: ''
    },
    shipping: {
      firstName: '',
      lastName: '',
      company: '',
      country: '',
      address: '',
      city: '',
      zip: '',
      phone: '',
      email: ''
    },
    sameAddress: false, // Toggle to use billing address for shipping
    paymentMethod: payment[0].value, // Default payment method
  });

  const [isSubmitting, setIsSubmitting] = useState(false); // State to manage form submission status
  const [error, setError] = useState(''); // State to store error messages

  // State to manage shop summary details (subtotal, delivery fee, etc.)
  const [shopSummary, setShopSummary] = useState({
    subTotal: 0,
    discountedAmount: 0,
    adjustedSubTotal: 0,
    couponDiscount: 0,
    taxAmount: 0,
    deliveryFee: 0,
    cartTotal: 0,
  });

  // Effect to sync shipping address with billing address if sameAddress is true
  useEffect(() => {
    if (formData.sameAddress) {
      setFormData(prev => ({
        ...prev,
        shipping: { ...prev.billing }
      }));
    }
  }, [formData.sameAddress, formData.billing]);


  /**
   * Handles input changes for billing and shipping addresses.
   * @param {string} section - The section being updated ('billing' or 'shipping').
   * @param {Event} e - The input change event.
   */
  const handleInputChange = (section, e) => {
    const { name, value, checked } = e.target;
    
    if (section === 'sameAddress') {
      setFormData(prev => ({
        ...prev,
        [section]: checked
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        [section]: {
          ...prev[section],
          [name]: value
        }
      }));
    }
  };

  /**
   * Validates the form data.
   * @returns {Array} - An array of validation error messages.
   */
  const validateForm = () => {
    const errors = [];
    const fields = ['firstName', 'lastName', 'country', 'address', 'city', 'zip', 'phone', 'email'];

    // Validate billing address
    fields.forEach(field => {
      if (!formData.billing[field]) {
        errors.push(`Billing ${field} is required`);
      }
    });

    // Validate shipping address fields if sameAddress is false
    if (!formData.sameAddress) {
      fields.forEach(field => {
        if (!formData.shipping[field]) {
          errors.push(`Shipping ${field} is required`);
        }
      });
    }

    // Validate email format
    if (!EMAIL_REGEX.test(formData.billing.email)) {
      errors.push('Invalid billing email format');
    }

    // Validate phone format
    if (!PHONE_REGEX.test(formData.billing.phone)) {
      errors.push('Invalid billing phone format');
    }

    // Validate ZIP code format
    if (!ZIP_REGEX.test(formData.billing.zip)) {
      errors.push('Invalid billing ZIP code');
    }

    return errors;
  };

  /**
   * Handles form submission.
   * Validates the form, sends the order data to the server, and navigates to the confirmation page.
   * @param {Event} e - The form submission event.
   */
  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setError('');

    try {
      // Validate form data
      const validationErrors = validateForm();
      if (validationErrors.length > 0) {
        throw new Error(validationErrors.join(' | '));
      }

      // Generate order ID and delivery date
      const orderId = generateOrderId();
      const deliveryDate = calculateDeliveryDate();

      // Prepare order data for submission
      const orderData = {
        orderId, // Add the generated order ID
        deliveryDate, // Add the calculated delivery date
        billing: formData.billing,
        shipping: formData.shipping,
        paymentMethod: formData.paymentMethod,
        cartItems: cart,
        shopSummary, // Include shop summary details
        discount: discount,
      };

      // Simulate API call to submit the order
      const response = await axios.post(API_PATH, orderData);
      
      if (response.data.sent) {
        clearCart(); // Clear cart after successful order placement
        navigate('/OrderConfirmation', { state: { orderData } }); // Navigate to the confirmation page
        showSuccessToast("Order placed successfully!");
      } else {
        throw new Error('Order placement failed');
      }
    } catch (err) {
      console.error("Checkout error:", err.response ? err.response.data : err);
      setError(err.response && err.response.data && err.response.data.message
               ? err.response.data.message
               : err.message || 'An error occurred during checkout');
    } finally {
      setIsSubmitting(false);
    }
  };

  // If the cart is empty, show the empty state
  if (cart.length === 0) {
    return (
      <>
        <PageTitle title={'checkout'} page={'checkout'} />
        <EmptyState 
          icon={FaCreditCard} 
          title="Your Checkout is Empty" 
          message="You haven't added any items for checkout yet." 
          buttonLink="Shop-List" 
          buttonText="Continue Shopping" 
        />
      </>
    );
  }

  return (
    <>
      <PageTitle title={'checkout'} page={'checkout'} />
      <section className='checkout'>

        <form onSubmit={handleSubmit}>

          <div className='box-1'>

            {/* Billing Address */}
            <AddressSection
              title="Billing Address"
              data={formData.billing}
              onChange={(e) => handleInputChange('billing', e)}
            />

            {/* Shipping Address */}
            <AddressSection
              title="Shipping Address"
              data={formData.shipping}
              onChange={(e) => handleInputChange('shipping', e)}
              disabled={formData.sameAddress}
              sameAddressControl={
                <div className='checkbox-label'>
                  <input
                    type="checkbox"
                    id="sameAddress"
                    checked={formData.sameAddress}
                    onChange={(e) => handleInputChange('sameAddress', e)}
                  />
                  <label htmlFor="sameAddress">Same as Billing Address</label>
                  <div className="checkbox-indicator"></div>
                </div>
              }
            />

          </div>

          <div className='box-2'>

            {/* Payment Methods (keep existing structure) */}
            <div className='payment-methods checkout-item'>
              <Heading title='payment methods' sideHeading />
              <div className='box-container'>
                {payment.map((item) => (
                  <div className='item' key={item.id}>
                    <input
                      type='radio'
                      id={item.paymentID}
                      name='payment'
                      value={item.value}
                      checked={formData.paymentMethod === item.value}
                      onChange={() => setFormData(prev => ({
                        ...prev,
                        paymentMethod: item.value
                      }))}
                    />
                    <label htmlFor={item.paymentID}>{item.title}</label>
                    <div className='payment-body'>
                      <p>{item.content}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Cart Total */}
            <div className='cart-total checkout-item'>
              <Heading title='cart total' sideHeading />
              <ShopSummary cart={cart} discount={discount} onSummaryChange={setShopSummary} />
            </div>

            {/* Submit Button */}
            <div className='btn-container'>
              <button
                type="submit"
                className='btn'
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Processing...' : 'Place Order'}
              </button>
            </div>

            {/* Error Messages */}
            {error && (
              <div className="alert error">
                {error.split(' | ').map((msg, i) => (
                  <span key={i}>{msg}</span>
                ))}
              </div>
            )}
  
          </div>
        </form>
      </section>
    </>
  );
};



/**
 * AddressSection Component: Renders a form section for billing or shipping address.
 */
const AddressSection = ({ title, data, onChange, disabled, sameAddressControl }) => (
  <div className='address checkout-item'>
    <Heading title={title.toLowerCase()} sideHeading />
    
    {/* Same as Billing Address Checkbox (if applicable) */}
    {sameAddressControl && <div className='same-address'>{sameAddressControl}</div>}

    <div className='form'>

      <div className='input-box'>

        {/* First Name */}
        <input
          type="text"
          name="firstName"
          placeholder="First name"
          className='box'
          value={data.firstName}
          onChange={onChange}
          disabled={disabled}
          required
        />

        {/* Last Name */}
        <input
          type="text"
          name="lastName"
          placeholder="Last name"
          className='box'
          value={data.lastName}
          onChange={onChange}
          disabled={disabled}
          required
        />

      </div>

      {/* Company Name */}
      <div className='input-box'>
        <input
          type="text"
          name="company"
          placeholder="Company"
          className='box'
          value={data.company}
          onChange={onChange}
          disabled={disabled}
          required
        />
      </div>

      {/* Country */}
      <div className='input-box'>
        <input
          type="text"
          name="country"
          placeholder="Country"
          className='box'
          value={data.country}
          onChange={onChange}
          disabled={disabled}
          required
        />
      </div>

      {/* Address */}
      <div className='input-box'>
        <input
          type="text"
          name="address"
          placeholder="Address"
          className='box'
          value={data.address}
          onChange={onChange}
          disabled={disabled}
          required
        />
      </div>

      <div className='input-box'>

        {/* City */}
        <input
          type="text"
          name="city"
          placeholder="City"
          className='box'
          value={data.city}
          onChange={onChange}
          disabled={disabled}
          required
        />

        {/* ZIP Code */}
        <input
          type="text"
          name="zip"
          placeholder="ZIP Code"
          className='box'
          value={data.zip}
          onChange={onChange}
          disabled={disabled}
          required
        />

      </div>

      <div className='input-box'>

        {/* Phone */}
        <input
          type="number"
          name="phone"
          placeholder="Phone"
          className='box'
          value={data.phone}
          onChange={onChange}
          disabled={disabled}
          required
        />

        {/* Email */}
        <input
          type="email"
          name="email"
          placeholder="Email"
          className='box'
          value={data.email}
          onChange={onChange}
          disabled={disabled}
          required
        />

      </div>
    </div>
  </div>
);


export default Checkout;