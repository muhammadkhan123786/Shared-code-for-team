import React from 'react';
import './Wishlist.css';

import { PageTitle, ShopTitle, EmptyState } from '../../../components';
import { useWishlist, useCart } from '../../../utils';

import { RiDeleteBin5Fill } from 'react-icons/ri';
import { BsCartPlusFill, BsCartXFill } from 'react-icons/bs';
import { FaHeart } from 'react-icons/fa';
import { Link } from 'react-router-dom';



const Wishlist = () => {

  const { wishlist, removeFromWishlist, checkProductAvailability } = useWishlist(); // Get wishlist state and functions from context
  const { addToCart } = useCart(); // Get cart state and functions from context

  return (
    <>
      {/* Page title */}
      <PageTitle title={'wishlist'} page={'wishlist'} />

      <section className='wishlist'>
        {wishlist.length === 0 ? (
          // Empty Wishlist message
          <EmptyState
            icon={FaHeart}
            title="Your Wishlist is Empty"
            message="Start adding your favorite items to your wishlist."
            buttonLink="Shop-List"
            buttonText="Browse Products"
          />
        ) : (
          <>
            <div className='wishlist-container'>
              <div className='container'>
                {/* Shop title */}
                <ShopTitle titles={['product', 'price', 'Status', 'action']} />

                <div className='box-container'>
                  {/* Render Wishlist items */}
                  {wishlist.map((item) => {
                    const isAvailable = checkProductAvailability(item.id); // Check product availability
                    const status = isAvailable ? 'In Stock' : 'Out of Stock'; // Set status text
                    const statusClass = isAvailable ? 'in-stock' : 'out-of-stock'; // Set status class

                    return (
                      <div className='wishlist-item' key={item.id}>
                        <div className='box product'>
                          <img className='image' src={item.image} alt={item.name} /> {/* Product Image */}
                          <Link
                            to={{
                              pathname: '/Shop/' + item.name,
                            }}
                            location={{ item }}
                            className='name'
                            state={item}>{item.name}
                          </Link> {/* Product Name */}
                        </div>
                        <div className='box price'>${item.price}</div> {/* Product Price */}
                        <div className={`box status ${statusClass}`}>
                          {status} {/* Automatic status with dynamic class */}
                        </div> {/* Product Status */}
                        <div className='box action'>
                          {/* Remove button */}
                          <button type='button' onClick={() => removeFromWishlist(item)}>
                            <RiDeleteBin5Fill className='icon delete' />
                          </button>
                          {/* Add To Cart button */}
                          <button
                            type='button'
                            onClick={() => addToCart(item)}
                            disabled={!isAvailable} // Disable if out of stock
                          >
                            {isAvailable ? (
                              <BsCartPlusFill className='icon cart' />
                            ) : (
                              <BsCartXFill className='icon cart' />
                            )}
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
          </>
        )}
      </section>
    </>
  );
};

export default Wishlist;