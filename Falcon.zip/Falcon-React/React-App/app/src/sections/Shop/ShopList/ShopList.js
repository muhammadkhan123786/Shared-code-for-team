import React from 'react';
import './ShopList.css';

import { PageTitle, Product, PagesNo, UniversalSidebar, ShowcaseHeader, EmptyState } from '../../../components';
import { productsContent } from '../../../constants';
import { useFilter, useFilterLoading } from '../../../utils';
import { FaBoxOpen } from 'react-icons/fa';



const ShopList = () => {

  const itemsPerPage = 4;

  // Use the useFilter hook to manage filtering and pagination
  const {
    selectedCategory,
    searchKeyword,
    priceRange,
    setPriceRange,
    filteredItems,
    displayedItems,
    sortOption,
    setSortOption,  // This is the state setter for sortOption
    currentPage,
    totalPages,
    handleSearchSubmit,
    handlePageChange,
  } = useFilter(productsContent, itemsPerPage, 'shop');

  // Use the custom hook for loading state
  const isFiltering = useFilterLoading(filteredItems, searchKeyword);

  return (
    <>
      {/* Page title */}
      <PageTitle title={'shop list'} page={'shop list'} />

      <section className='shop'>

        {/* Shop sidebar */}
        <UniversalSidebar
          type="shop"
          priceRange={priceRange}
          setPriceRange={setPriceRange} 
          selectedCategory={selectedCategory} 
          handleSubmit={handleSearchSubmit}  
        />

        <div className='shop-container'>
          {/* Show the "no results" only if the filtering is done and no items match */}
          {isFiltering ? null : filteredItems.length === 0 ? (
            <EmptyState
              icon={FaBoxOpen}
              title={`No products found for "${searchKeyword}"`}
              message="We couldn’t find any products that match your search. Please try another keyword or browse our full collection." 
              buttonLink="Shop-List" 
              buttonText="Browse All Products"
            />
          ) : (
            <>
              {/* Shop header */}
              <ShowcaseHeader
                showing={displayedItems.length} 
                total={filteredItems.length}
                sortOption={sortOption} 
                handleSort={setSortOption}  // Ensure this is updating the sortOption correctly
              />

              <div className='product-container list'>
                {/* Render products */}
                {displayedItems.map((product) => (
                  <Product key={product.id} product={product} list />
                ))}
              </div>

              {/* Pagination */}
              <PagesNo 
                currentPage={currentPage} 
                totalPages={totalPages} 
                handlePageChange={handlePageChange} 
              />
            </>
          )}
        </div>
      </section>
    </>
  );
};


export default ShopList;
