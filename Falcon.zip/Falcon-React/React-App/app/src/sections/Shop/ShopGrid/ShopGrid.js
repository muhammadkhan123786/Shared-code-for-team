import React from 'react';
import './ShopGrid.css';

// Import necessary components and utilities
import { PageTitle, Product, PagesNo, UniversalSidebar, ShowcaseHeader, EmptyState } from '../../../components';
import { productsContent } from '../../../constants';
import { useFilter, useFilterLoading } from '../../../utils';
import { FaBoxOpen } from 'react-icons/fa';


const ShopGrid = () => {

  const itemsPerPage = 9; // Define the number of products displayed per page

  // Custom hook to manage filtering, sorting, and pagination
  const {
    selectedCategory,
    searchKeyword,
    priceRange,
    setPriceRange,
    filteredItems,
    displayedItems,
    sortOption,
    handleSort,
    currentPage,
    totalPages,
    handlePageChange,
    handleSearchSubmit,
  } = useFilter(productsContent, itemsPerPage, 'shop');

  // Use the custom hook for loading state
  const isFiltering = useFilterLoading(filteredItems, searchKeyword);

  return (
    <>
      <PageTitle title={'shop grid'} page={'shop grid'} />

      <section className='shop'>

        {/* Sidebar for filtering products */}
        <UniversalSidebar
          type="shop"
          priceRange={priceRange}
          setPriceRange={setPriceRange} 
          selectedCategory={selectedCategory} 
          handleSubmit={handleSearchSubmit} 
        />

        <div className='shop-container'>
          {/* Show "No results" message only if filtering is completed and no items match the search */}
          {isFiltering ? null : filteredItems.length === 0 ? (
            <EmptyState
              icon={FaBoxOpen}
              title={`No products found for "${searchKeyword}"`}
              message="We couldn’t find any products that match your search. Please try another keyword or browse our full collection." 
              buttonLink="Shop-Grid" 
              buttonText="Browse All Products"
            />
          ) : (
            <>
              {/* Header section displaying sorting options and product count */}
              <ShowcaseHeader
                showing={displayedItems.length} 
                total={filteredItems.length}
                sortOption={sortOption} 
                handleSort={handleSort}  
              />

              {/* Product List */}
              <div className='product-container grid'>
                {displayedItems.map((product) => (
                  <Product key={product.id} product={product} />
                ))}
              </div>

              {/* Pagination controls */}
              <PagesNo 
                currentPage={currentPage} 
                totalPages={totalPages} 
                handlePageChange={handlePageChange} 
              />
            </>
          )}
        </div>
      </section>
    </>
  );
};

export default ShopGrid;