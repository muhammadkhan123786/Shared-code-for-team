import React, { useState } from 'react';
import './Cart.css';

import { PageTitle, Button, ShopSummary, ShopTitle, EmptyState, StockMessage } from '../../../components';
import { useCart } from '../../../utils'; // Importing the custom hook

import { RiDeleteBin5Fill } from 'react-icons/ri';
import { FaCartArrowDown } from 'react-icons/fa';
import { Link, useNavigate } from 'react-router-dom';


const Cart = () => {

  const { 
    cart, 
    removeFromCart, 
    addToCart, 
    removeCompletely, 
    applyCoupon, 
    discount, 
    validateCheckout, 
    getProductStock,
  } = useCart();
  const navigate = useNavigate();

  const [inputCouponCode, setInputCouponCode] = useState('');

  // Function to handle applying a coupon
  const handleApplyCoupon = () => {
    applyCoupon(inputCouponCode);
  };

  // Function to handle checkout
  const handleCheckout = async () => {
    const isCheckoutValid = await validateCheckout();
  
    if (!isCheckoutValid) {
      // Alerts are already shown by validateCheckout
      return;
    }
  
    // Proceed to checkout if no issues
    navigate("/checkout");
  };

  return (
    <>
      <PageTitle title={'cart'} page={'cart'} />

      <section className='cart'>
        {cart.length === 0 ? (
          <EmptyState
            icon={FaCartArrowDown} 
            title="Your Cart is Empty" 
            message="Looks like you haven't added any items yet." 
            buttonLink="Shop-List" 
            buttonText="Shop Now" 
          />
        ) : (
          <>
            <div className='shop-btn'>
              <Button link={'Shop-list'} title={'Continue Shopping'} />
            </div>

            <div className='shopping-cart'>
              <div className='container'>
                <ShopTitle titles={['product', 'price', 'quantity', 'total', 'action']} />

                <div className='box-container'>
                  {cart.map((item) => {
                    const stock = getProductStock(item.id); // Get the stock for each product
                    const totalPrice = item.price * item.quantity;

                    return (
                      <div className='cart-item' key={item.id}>
                        <div className='cart-item-info'>
                          <div className='box product'>
                            <img className='image' src={item.image} alt={item.name} />
                            <Link
                              to={{
                                pathname: '/Shop/' + item.name,
                              }}
                              location={{ item }}
                              className='name'
                              state={item}>{item.name}
                            </Link>
                          </div>
                          <div className='box price'>${item.price}</div>
                          <div className='box quantity'>
                            <input
                              type='button'
                              defaultValue='-'
                              className='minus'
                              onClick={() => removeFromCart(item)}
                            />
                            <input
                              type='number'
                              step='1'
                              min='1'
                              max='100'
                              name='quantity'
                              value={item.quantity}
                              className='input-text'
                              readOnly
                            />
                            <input
                              type='button'
                              defaultValue='+'
                              className='plus'
                              onClick={() => addToCart(item)}
                              disabled={item.quantity >= stock}
                            />
                          </div>
                          <div className='box total'>${totalPrice}</div>
                          <div className='box action'>
                            <button type='submit' onClick={() => removeCompletely(item)}>
                              <RiDeleteBin5Fill className='icon delete' />
                            </button>
                          </div>
                        </div>
                        <StockMessage stock={stock} />
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>

            <div className='cart-bottom'>
              <div className='coupon-container'>
                <input
                  type='text'
                  name='coupon-code'
                  className='box'
                  id='coupon-code'
                  placeholder='coupon code'
                  value={inputCouponCode}
                  onChange={(e) => setInputCouponCode(e.target.value)}
                  required
                />
                <button className='btn' name='submit' id='submit' onClick={handleApplyCoupon}>
                  apply coupon
                </button>
              </div>

              <div className='cart-total'>
                <ShopSummary cart={cart} discount={discount} />
                <button 
                  onClick={handleCheckout} 
                  className='btn'
                >
                  Proceed to Checkout
                </button>
              </div>
            </div>
          </>
        )}
      </section>
    </>
  );
};

export default Cart;