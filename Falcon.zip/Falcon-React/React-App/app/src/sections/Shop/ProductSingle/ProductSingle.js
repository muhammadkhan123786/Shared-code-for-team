import React, { useState, useEffect } from 'react';
import './ProductSingle.css';

import { Button, Comments, PageTitle, Product, SidebarHeading, StockMessage } from '../../../components';
import { productsContent } from '../../../constants';
import { calculateAverageRating, countCommentsAndReplies, useWishlist } from '../../../utils';

import { FaSquare, FaStar } from 'react-icons/fa';

import { Link, useLocation } from 'react-router-dom';
import ImageGallery from 'react-image-gallery';

// Import useCart hook
import { useCart } from '../../../utils';
import { BsHeart } from 'react-icons/bs';



const ProductSingle = () => {

  // Destructuring cart actions and state from useCart
  const { cart, addToCart } = useCart();
  const { addToWishlist } = useWishlist();

  const [selectedOption, setSelectedOption] = useState('description'); // State for handling selected product information tab (description, additional info, or reviews)
  const [quantity, setQuantity] = useState(1); // State for product quantity selection

  const location = useLocation(); // Getting the location from React Router (used for accessing passed state)
  const product = location.state; // Product data passed from the previous page

  const productComments = product.comments; // Product comments

  /*--------------- 1-Average rating for product ---------------*/
  // Calculating average rating of the product using a utility function
  const averageRating = calculateAverageRating(product);

  /*--------------- 2-Handle Quantity Change ---------------*/
  // Increment quantity
  const handleIncrement = () => {
    if (quantity < product.stock) {
      setQuantity(quantity + 1);
    } else {
      alert(`Cannot increase quantity beyond available stock (${product.stock}).`);
    }
  };

  // Decrement quantity
  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity(quantity - 1);
    }
  };

  /*--------------- 3-Add to cart ---------------*/
  // Handle adding product to the cart (replaces quantity if already in cart)
  const handleAddToCart = () => {
    addToCart(product, quantity); // Replaces existing quantity with 7

  };
  

  /*--------------- 4-Update Quantity Based on Cart ---------------*/
  // Effect to update the quantity state if the product is already in the cart
  useEffect(() => {
    const cartItem = cart.find(item => item.id === product.id);
    if (cartItem) {
      setQuantity(cartItem.quantity); // Set quantity to the value in the cart
    } else {
      setQuantity(1); // Reset to 1 if the product is not in the cart
    }
  }, [cart, product.id]);

  /*--------------- 5-Product Information Tabs Change ---------------*/
  // Handle switching between product information tabs (description, additional info, or reviews)
  const handleOptionChange = (option) => {
    setSelectedOption(option);
  };

  /*--------------- 6-total number of comments and replies for the product ---------------*/
  let totalCommentsAndReplies = 0;
  if (productComments) {
    totalCommentsAndReplies = countCommentsAndReplies(productComments);
  }

  /*--------------- 7-Handle form submission for the product review ---------------*/
  // Handle review form submission (e.g., adding a new review)
  const handleSubmit = (event) => {
    event.preventDefault(); // Prevent default form submission
    event.target.reset(); // Reset the form fields
  };

  /*--------------- 8-Related Products ---------------*/
  // Extract category and tags for filtering related products
  const mainProductCategoryTitles = product.category.map((cat) => cat.title);
  const mainProductTags = product.tags;

  // Filter and limit related products based on matching categories or tags
  const filteredRelatedProducts = productsContent
    .filter((relatedProduct) => {
      // Check if categories or tags match
      const hasMatchingCategory = relatedProduct.category.some((cat) => mainProductCategoryTitles.includes(cat.title));
      const hasMatchingTag = relatedProduct.tags.some((tag) => mainProductTags.includes(tag));

      return relatedProduct.id !== product.id && (hasMatchingCategory || hasMatchingTag);
    })
    .sort((a, b) => {
      // Further sorting logic based on category and tag matching
      const aCategoryTagMatch = a.category.some((cat) => mainProductCategoryTitles.includes(cat.title)) &&
                                a.tags.some((tag) => mainProductTags.includes(tag));
      const bCategoryTagMatch = b.category.some((cat) => mainProductCategoryTitles.includes(cat.title)) &&
                                b.tags.some((tag) => mainProductTags.includes(tag));

      if (aCategoryTagMatch && !bCategoryTagMatch) return -1;
      if (!aCategoryTagMatch && bCategoryTagMatch) return 1;

      // If both have category or tag matches, prioritize by category match
      const aCategoryOnlyMatch = a.category.some((cat) => mainProductCategoryTitles.includes(cat.title));
      const bCategoryOnlyMatch = b.category.some((cat) => mainProductCategoryTitles.includes(cat.title));

      if (aCategoryOnlyMatch && !bCategoryOnlyMatch) return -1;
      if (!aCategoryOnlyMatch && bCategoryOnlyMatch) return 1;

      // Lastly, prioritize by tag match
      const aTagOnlyMatch = a.tags.some((tag) => mainProductTags.includes(tag));
      const bTagOnlyMatch = b.tags.some((tag) => mainProductTags.includes(tag));

      if (aTagOnlyMatch && !bTagOnlyMatch) return -1;
      if (!aTagOnlyMatch && bTagOnlyMatch) return 1;

      return 0; // If no priority condition is met, maintain original order
    })
    .slice(0, 4); // Limiting the number of related products to display (4)

  /*--------------- 9-Product Gallery ---------------*/
  // Create an array of images for the image gallery
  const image = [
    {
      original: product.gallery.image1,
      thumbnail: product.gallery.image1,
    },
    {
      original: product.gallery.image2,
      thumbnail: product.gallery.image2,
    },
    {
      original: product.gallery.image3,
      thumbnail: product.gallery.image3,
    },
    {
      original: product.gallery.image4,
      thumbnail: product.gallery.image4,
    },
  ];

  return ( 
    <>
      <PageTitle title={product.name} page={"Product Single"} />
      <section className='product-single'>
        <div className='product-des'>
          <div className='product-container'>
            {/* Product Image Gallery */}
            <div className='product-image'>
              <ImageGallery items={image} />
            </div>

            {/* Product Content */}
            <div className='content'>
              <div className='text'>

                {/* Product Intro */}
                <div className='introduction'>

                  <h3>{product.name}</h3> {/* Product Name */}

                  <div className='rating'>  {/* Product Rating */}
                    <div className='icon'>            
                      <FaStar /> <FaStar /> <FaStar /> <FaStar /> <FaStar /> 
                    </div> 
                    {/* Render average rating and comment count */}
                    {product.comments.length > 0 ? (
                      <h5>{averageRating} ({product.comments.length})</h5>
                    ) : (
                      <h5>Not rated</h5>
                    )}
                  </div>

                  <p className='product-text'>{product.content}</p> {/* Product Description */}

                  <div className="price">
                    ${product.disprice > 0 ? product.disprice : product.price}/- 
                    {product.disprice > 0 && <span>${product.price}</span>}
                  </div>

                  <StockMessage stock={product.stock} />

                </div>

                <div className='box'>
                  {/* Quantity Controls (only if product is in stock) */}
                  {product.stock > 0 && (
                    <div className="quantity">
                      <input type="button" defaultValue="-" className="minus" onClick={handleDecrement} />
                      <input 
                        type="number" 
                        step="1" 
                        min="1" 
                        max={product.stock} 
                        name="quantity" 
                        value={quantity} 
                        className="input-text" 
                        readOnly 
                      />
                      <input type="button" defaultValue="+" className="plus" onClick={handleIncrement} disabled={quantity >= product.stock}  />
                    </div>
                  )}

                  {/* Add to cart button */}
                  <button
                    type="submit" 
                    onClick={product.stock > 0 ? handleAddToCart : null} 
                    disabled={product.stock === 0} 
                    className={product.stock === 0 ? "disabled-button" : ""}
                  >
                    {product.stock > 0 ? <Button link={'cart'} title={'Add to Cart'} /> : "Out of Stock"}
                  </button>

                  {/* Add to Wishlist Button */}
                  <button onClick={() => addToWishlist(product)} data-tooltip="Add to Wishlist" className='wishlist-btn'>
                    <BsHeart />
                  </button>
                </div>

                {/* SKU */}
                <div className='sku'> <h6>SKU:</h6> <p>0{product.id}</p> </div>

                {/* Categories */}
                <div className='categories'> 
                  <h6>Categories:</h6>
                  {/* Render categories */}
                  {(product.category).map((item, index) => {
                    return(          
                      <Link
                        key={index}
                        to={`/Shop/category/${item}`}>
                        {item}
                      </Link>
                      ) 
                    })} 
                </div>

                {/* Tags */}
                <div className='tags'>
                  <h6>Tags:</h6>
                  {/* Render tags */}
                  {(product.tags).map((item, index) => {
                    return(                        
                      <Link
                        key={index}
                        to={`/Shop/tag/${item}`}>
                        {item}
                      </Link>
                    )
                  })}
                </div>
              </div>
            </div>
          </div> 

          {/* Product More Information */}
          <div className='product-info'>
            {/* Product Information Tab */}
            <div className="tab-buttons">
              {/* Description Tab */}
              <button
                type="button"
                className={`button ${selectedOption === 'description' ? 'active' : ''}`}
                onClick={() => handleOptionChange('description')}
              >description
              </button>

              {/* Additional Information Tab */}
              <button
                type="button"
                className={`button ${selectedOption === 'additionalInfo' ? 'active' : ''}`}
                onClick={() => handleOptionChange('additionalInfo')}
              >additional information
              </button>

              {/* Reviews Tab */}
              <button
                type="button"
                className={`button ${selectedOption === 'reviews' ? 'active' : ''}`}
                onClick={() => handleOptionChange('reviews')}
              >reviews ({totalCommentsAndReplies})
              </button>
            </div>

            {/* Description Container */}
            {selectedOption === 'description' && (
              <div className="description product-info-gallery">
                <p>{product.description}</p>
              </div>
            )} 

            {/* Additional Information Container */}
            {selectedOption === 'additionalInfo' && (
              <div className='additional-info product-info-gallery'>
                {(product.addInfo).map((item) => {
                  return (
                    <div className='item' key={item.id}>
                      <h3><FaSquare className='icon' />{item.title}</h3>
                      <span>{item.content}</span>
                    </div>
                  )
                })}
              </div>
            )}

            {/* Reviews Section */}
            {selectedOption === 'reviews' && (
              <div className='reviews product-info-gallery'>
                {/* Render comments */}
                <Comments comments={productComments} />

                <div className='leave-reply'>
                  {/* Comment Form */}
                  <form className='form' onSubmit={handleSubmit}>
                    <h2>leave a comment</h2> {/* Comment Form Title */}

                    {/* Input Fields */}
                    <div className='input-box'>
                      <input type="text" name="name" className='box' id="name" placeholder="name" required /> {/* Name Input Field */}
                      <input type="email" name="email" className='box' id="email" placeholder="email" required /> {/* Email Input Field */}
                    </div>
                    
                    <textarea cols="30" rows="10" name="comment" className='box' id="comment" placeholder="comment"></textarea> {/* Comment Textarea */}
                    
                    <button type="submit" name="submit" id="submit" className='btn'>submit</button> {/* Submit Button */}
                  </form>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Related Products */}
        <div className='related-items'>
          {/* Sidebar Heading */}
          <SidebarHeading title='Related Products' />

          {/* Related Product List */}
          <div className='box-container'>
            {
              filteredRelatedProducts.map((product) => {
                return(
                  <Product key={product.id} product={product} />
                )
              })
            }
          </div>
        </div>
      </section>
    </>
  )
}

export default ProductSingle;