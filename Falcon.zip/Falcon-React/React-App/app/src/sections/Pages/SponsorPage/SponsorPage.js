import React from 'react';
import './SponsorPage.css';

import { Heading, PageTitle } from '../../../components';
import { sponsors } from '../../../constants';



const SponsorPage = () => {
  return (
    <>
      {/* Page Title */}
      <PageTitle title={'Sponsors'} page={'Sponsors'} />

      <section className='sponsors'>

        {/* Section heading */}
        <Heading title={'Our Sponsors'} subTitle={'Proud partners'} />

        <div className='box-container'>

          {/* Loop through the sponsors array to display each sponsor's logo */}
          {sponsors.map((sponsor, index) => {
              return (
                <div className='sponsor-item' key={index}>
                  {/* Render the Sponsor logo */}
                  <img src={sponsor} alt='Sponsor Logo' />
                </div>
              );
            })
          }

        </div>

      </section>

    </>
  );
}

export default SponsorPage;