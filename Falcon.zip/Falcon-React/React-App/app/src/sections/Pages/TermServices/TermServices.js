import React from 'react';

import { PolicyTerms } from '../../../components';
import { serviceTerms } from '../../../constants';



const TermServices = () => { 

  return (
    <PolicyTerms 
      title="Terms of Services"  // Page title
      page="Terms of Services"   // Page identifier
      policies={serviceTerms}    // Passing terms of services content as props
    />
);
}

export default TermServices;