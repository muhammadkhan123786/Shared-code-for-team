import React from 'react';
import './EventSingle.css';

import { PageSidebar, PageTitle, TeamSquad } from '../../../components';
import { getTeamLogo } from '../../../utils/TeamLogo';

import { useLocation } from 'react-router-dom';


 
const EventSingle = () => { 
 
  const location = useLocation();  
  const event = location.state;


  return (
    <>
      {/* Page Title */} 
      <PageTitle title={event.teamA+' Vs '+event.teamB} page={'event single'} />

      <section className='event-single'>

        <div className='event-info'>

          <div className='event-intro'>

            <div className='intro'>

              {/* Team-1 Logo and Name */}
              <div className='team-logo'>
                <img src={getTeamLogo(event.teamA)} alt='Event' /> {/* Team-1 Logo */}
                <h3>{event.teamA}</h3> {/* Team-1 Name */}
              </div>

              <h5>VS</h5>

              {/* Team 2 Logo and Name */}
              <div className='team-logo'>
                <img src={getTeamLogo(event.teamB)} alt='Event' /> {/* Team-2 Logo */}
                <h3>{event.teamB}</h3> {/* Team-2 Name */}
              </div>

            </div>

            {/* Event content */}
            <div className='event-content'>
              <div className='time'>{event.details.date} - {event.details.time}</div> {/* Event Date and Time */}
              <div className='venue'>{event.details.venue}</div> {/* Event Venue */}
            </div>

          </div>

          {/* Team squad for team1 */}
          <TeamSquad teamName={event.teamA} teamSquad={event.playingXI.teamA} />

          {/* Team squad for team2 */}
          <TeamSquad teamName={event.teamB} teamSquad={event.playingXI.teamB} />

        </div>

        {/* Sidebar with Event details */}
        <PageSidebar
          heading={'Event'}
          details={event.details}
        />

      </section> 
    </> 
  );
}

export default EventSingle;
