import React from 'react';

import { PolicyTerms } from '../../../components'; // Importing the reusable PolicyTerms component
import { privacyPolicy } from '../../../constants'; // Importing privacy policy content from constants


 
const PrivacyPolicy = () => {
  return (
      <PolicyTerms 
        title="Privacy Policy" 
        page="privacy-policy" 
        policies={privacyPolicy} // Passes the privacy policy content
      />
  );
};

export default PrivacyPolicy;
