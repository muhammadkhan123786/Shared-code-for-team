import React from 'react';

// Import necessary components
import { Lightbox, PageSidebar, PageTitle } from '../../../components';

import { RiTeamLine } from 'react-icons/ri';
import { BiSolidCricketBall } from 'react-icons/bi';

// Import useLocation to access route state
import { useLocation } from 'react-router-dom';



const PortfolioSingle = () => {

  // Get portfolio details passed via router state
  const location = useLocation();
  const portfolio = location.state;

  return (
    <>
      {/* Page Title Section */}
      <PageTitle title={portfolio.title} page={"Portfolio Single"} />

      <section className='portfolio-single page-single'>

        <div className='portfolio-info page-info'>

          {/* Portfolio Image */}
          <div className='image'>
            <img src={portfolio.image} alt={portfolio.title} />
          </div>

          <div className='content'>

            {/* Portfolio Title */}
            <h3 className='main-heading'>{portfolio.title}</h3>

            {/* Portfolio Description */}
            {portfolio.paragraphs.map((paragraph, index) => (
              <p key={index} className={index === 0 ? 'important' : ''}>
                {paragraph}
              </p>
            ))}

            {/* Portfolio Image Gallery */}
            <Lightbox images={portfolio.gallery} />

            {/* Team LineUps Section */}
            <div className='sub-section'>

              <h3 className='sub-heading'>Team LineUps:</h3>
              <p>List of players selected to represent each side in {portfolio.title}.</p>

              {/* Team LineUps */}
              <ul>
                {portfolio.teamLineup.map((item, index) => {
                  return <li key={index}><RiTeamLine className='icon' />{item}</li>
                })}
              </ul>

            </div>

            {/* Event Highlights */}
            <div className='sub-section'>

              <h3 className='sub-heading'>Event Highlights:</h3>
              <p>Key moments, performances, and standout actions from {portfolio.title}.</p>

              {/* Event Highlights List */}
              <ul>
                {portfolio.eventHighlights.map((highlight, index) => {
                  return <li key={index}><BiSolidCricketBall className='icon' />{highlight}</li>
                })}
              </ul>

            </div>

          </div>

        </div>

        {/* Sidebar with Portfolio details */}
        <PageSidebar
          heading={'Portfolio'}
          details={portfolio.details}
        />

      </section>

    </> 
  );
}

export default PortfolioSingle;