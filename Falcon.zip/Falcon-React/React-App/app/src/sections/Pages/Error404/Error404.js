import React from 'react';
import './Error404.css';

import { Button, PageTitle } from '../../../components';



const Error404 = () => { 

  return (
    <>
      {/* Page Title */}
      <PageTitle title={'Error 404'} page={'Error 404'} />

      <section className="error-404">
        <div className="box-container">
          <div className="content">
            <h2>404</h2>
            <h5><span>Sorry!</span> Page Not Found</h5>
            <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorum quae eius delectus fugiat sint.</p>
            {/* Button to navigate back to the homepage */}
            <Button link={''} title={'Go Back Home'} />
          </div>
        </div>
    </section>
    </> 
  );
}

export default Error404;