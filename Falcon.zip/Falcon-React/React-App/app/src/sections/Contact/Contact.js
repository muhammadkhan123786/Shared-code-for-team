import React, { useState, useEffect } from 'react';
import './Contact.css';

import { Heading, PageTitle } from '../../components';
import { contactContent } from '../../constants';

import { FaComment, FaEnvelope, FaPhoneAlt, FaUserAlt } from 'react-icons/fa';
import axios from "axios";

// API path for sending form data
const API_PATH = 'https://www.example.com/api/phpmailer/submit.php';

// Regular expressions for email and phone number validation
const EMAIL_REGEX = /^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/;
const PHONE_REGEX = /^[+]?[(]?[0-9]{1,4}[)]?[-\s./0-9]*$/;



const Contact = () => {

  // State to manage form input values
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    number: '',
    message: ''
  });
  
  // State for handling success and error messages
  const [mailSent, setMailSent] = useState(false);
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Effect to clear success message after 3 seconds
  useEffect(() => {
    if (mailSent) {
      const timer = setTimeout(() => setMailSent(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [mailSent]);

  // Function to handle form submission
  const handleSubmitForm = async (e) => {
    e.preventDefault(); // Prevent default form submission behavior
    setIsSubmitting(true);
    setError('');

    try {

      // Client-side validation
      const validationErrors = [];

      if (!formData.name.trim()) validationErrors.push('Name is required');
      if (!formData.email.trim()) {
        validationErrors.push('Email is required');
      } else if (!EMAIL_REGEX.test(formData.email)) {
        validationErrors.push('Invalid email format');
      }
      if (!formData.number.trim()) {
        validationErrors.push('Phone number is required');
      } else if (!PHONE_REGEX.test(formData.number)) {
        validationErrors.push('Invalid phone number format');
      }
      if (!formData.message.trim()) validationErrors.push('Message is required');

      if (validationErrors.length > 0) {
        throw new Error(validationErrors.join(' | ')); // Concatenate errors with '|'
      }

      // Prepare form data for API request
      const postData = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        postData.append(key, value);
      });

      // Sending form data to API
      const response = await axios.post(API_PATH, postData, {
        headers: { 'Content-Type': 'multipart/form-data' }
      });

      if (!response.data.sent) {
        throw new Error(response.data.message || 'Message submission failed');
      }

      // On success, reset form and show success message
      setMailSent(true);
      setFormData({ name: '', email: '', number: '', message: '' });
    } catch (err) {
      setError(err.response?.data?.message || err.message || 'An error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  // Function to handle input changes and update state
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  return (
    <>
      {/* Page Title */}
      <PageTitle title={'contact'} page={'contact'} />
    
      <section className='contact' id='contact'>

        <div className='contact-info'>

          {/* Loop through the contact array and display each contact info item */}
          {contactContent.map((contact) => (
            <div className='info-item' key={contact.id}>

              {/* Display the contact icon */}
              <div className='icon'>{contact.icon}</div>

              {/* Display the contact title and details */}
              <div className='content'>
                <h4>{contact.title}</h4>
                {/* Loop through the content array and display each item as a paragraph */}
                {contact.content.map((value, index) => (
                  <p key={index}>{value}</p>
                ))}
              </div>

            </div>
          ))}

        </div>

        <div className='contact-container'>

          {/* Contact Form */}
          <form className='dark-form' onSubmit={handleSubmitForm}>

            <Heading title={'get in touch'} subTitle={'Contact Us'} linear />

            <div className='input-box'>

              {/* Name Input Field */}
              <div className='input-field'>
                <label htmlFor="name"><FaUserAlt /></label>
                <input
                  type="text"
                  className='box'
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="Name"
                  disabled={isSubmitting}
                  required
                />
              </div>

              {/* Email Input Field */}
              <div className='input-field'>
                <label htmlFor="email"><FaEnvelope /></label>
                <input
                  type="email"
                  className='box'
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="Email"
                  disabled={isSubmitting}
                  required 
                />
              </div>

              {/* Phone Number Input Field */}
              <div className='input-field'>
                <label htmlFor="number"><FaPhoneAlt /></label>
                <input
                  type="tel"
                  className='box'
                  id="number"
                  name="number"
                  value={formData.number}
                  onChange={handleInputChange}
                  placeholder="Phone Number"
                  disabled={isSubmitting}
                  required 
                />
              </div>

            </div>

            {/* Message Input Field */}
            <div className='input-box'>
              <div className='input-field text-area'>
                <label htmlFor="message"><FaComment /></label>
                <textarea
                  cols="30"
                  rows="10"
                  id="message"
                  className='box'
                  name="message"
                  value={formData.message}
                  onChange={handleInputChange}
                  placeholder="Message"
                  disabled={isSubmitting}
                  required 
                ></textarea>
              </div>
            </div>

            {/* Submit Button */}
            <button type="submit" className='btn' disabled={isSubmitting}>
              {isSubmitting ? 'Submitting...' : 'Submit'}
            </button>

            {/* Error and Success Messages */}
            {error && <div className="alert error">{error.split(' | ').map((msg, i) => (<span key={i}>{msg}</span>))}</div>}
            {mailSent && <div className="alert success"><span>Message sent successfully</span></div>}
          </form>
        </div>

        {/* Embedded Google Map */}
        <iframe 
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2381.622589899471!2d-6.260309684365894!3d53.34980597997906!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x48670e9d6c3d63df%3A0x27fbd49abffecb4c!2sDublin%2C%20Ireland!5e0!3m2!1sen!2s!4v1626525931747!5m2!1sen!2s"
          allowFullScreen 
          loading="lazy"
          title='Office Address'
        ></iframe>

      </section>
    </>
  );
};

export default Contact;