/*Home*/
export { default as HomePage } from './HomePage/HomePage';
export { default as Home } from './HomePage/Home/Home';
export { default as About } from './HomePage/About/About';
export { default as Counter } from './HomePage/Counter/Counter';
export { default as PortfolioSection } from './HomePage/PortfolioSection/PortfolioSection';
export { default as Testimonials } from './HomePage/Testimonials/Testimonials';
export { default as NewsletterSection } from './HomePage/NewsletterSection/NewsletterSection'; 
export { default as Blogs } from './HomePage/Blogs/Blogs'; 
export { default as Sponsors } from './HomePage/Sponsors/Sponsors';
export { default as FAQs } from './HomePage/FAQs/FAQs';


/*Home*/
export { default as HomeEvents } from './HomePage/HomeEvents/HomeEvents';
export { default as HomeShop } from './HomePage/HomeShop/HomeShop';
export { default as Coaches } from './HomePage/Coaches/Coaches';
export { default as PlayerSlider } from './HomePage/PlayerSlider/PlayerSlider';
export { default as ResultAndPoint } from './HomePage/ResultAndPoint/ResultAndPoint';
export { default as Trophies } from './HomePage/Trophies/Trophies';


/*About*/
export { default as AboutUs } from './About/AboutUs/AboutUs';
export { default as TestimonialsPage } from './About/TestimonialsPage/TestimonialsPage';
export { default as FaqPage } from './About/FaqPage/FaqPage';


/*Team*/
export { default as TeamPage } from './Team/TeamPage/TeamPage';
export { default as PlayersPage } from './Team/PlayersPage/PlayersPage';
export { default as CoachesPage } from './Team/CoachesPage/CoachesPage';


/*Pages*/
export { default as PointTable } from './Pages/PointTable/PointTable';

export { default as EventPage } from './Pages/EventPage/EventPage'; 
export { default as EventSingle } from './Pages/EventSingle/EventSingle'; 

export { default as FixturePage } from './Pages/FixturePage/FixturePage';
export { default as FixtureSingle } from './Pages/FixtureSingle/FixtureSingle'; 

export { default as PortfolioPage } from './Pages/PortfolioPage/PortfolioPage';
export { default as PortfolioSingle } from './Pages/PortfolioSingle/PortfolioSingle';

export { default as Error404 } from './Pages/Error404/Error404';
export { default as TermServices } from './Pages/TermServices/TermServices';
export { default as PrivacyPolicy } from './Pages/PrivacyPolicy/PrivacyPolicy';

export { default as SponsorPage } from './Pages/SponsorPage/SponsorPage';


/*Blog*/
export { default as BlogGrid } from './Blogs/BlogGrid/BlogGrid';
export { default as BlogList } from './Blogs/BlogList/BlogList';
export { default as BlogSingle } from './Blogs/BlogSingle/BlogSingle';


/*Shop*/
export { default as ShopGrid } from './Shop/ShopGrid/ShopGrid';
export { default as ShopList } from './Shop/ShopList/ShopList';
export { default as ProductSingle } from './Shop/ProductSingle/ProductSingle';
export { default as Wishlist } from './Shop/Wishlist/Wishlist';
export { default as Cart } from './Shop/Cart/Cart';
export { default as Checkout } from './Shop/Checkout/Checkout';
export { default as OrderConfirmation } from './Shop/OrderConfirmation/OrderConfirmation';
export { default as Login } from './Shop/Login/Login';
export { default as Register } from './Shop/Register/Register';
export { default as ForgotPwd } from './Shop/ForgotPwd/ForgotPwd';


/*Contact*/
export { default as Contact } from './Contact/Contact';