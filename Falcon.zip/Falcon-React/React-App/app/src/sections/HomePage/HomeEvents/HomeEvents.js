import React from 'react';
import './HomeEvents.css';

import { Link } from 'react-router-dom';

import { Heading } from '../../../components';
import { events } from '../../../constants';
import { getTeamLogo } from '../../../utils';


 
const HomeEvents = () => {    

  // Get the first 3 upcoming events
  const homeEvents = events.slice(0, 3);

  return (

    <section className='home-events linear-bg'> 

      {/* Section heading */}
      <Heading title={'upcoming events'} subTitle={"Future matches"} linear />

      {/* Render each upcoming event */}
      <div className='box-container'>
        {homeEvents.map((event) => {
          return( 
            <div className='upcoming-item' key={event.id}>
              <div className='content'>
                <div className='time'>{event.details.date} - {event.details.time}</div> {/* Event date and time */}
                <div className='team-content'>
                  <div className='team-logo'>
                    <img src={getTeamLogo(event.teamA)} alt='Event' /> {/* Team A logo */}
                    <h3>{event.teamA}</h3> {/* Team A name */}
                  </div>
                  <h6>vs</h6>
                  <div className='team-logo'>
                    <img src={getTeamLogo(event.teamB)} alt='Event' /> {/* Team B logo */}
                    <h3>{event.teamB}</h3> {/* Team B name */}
                  </div>
                </div>
                <div className='venue'>{event.details.venue}</div> {/* Event venue */}
              </div>
              <div className='btn-container'>
                <a href="/#" className='btn'>ticket</a>  {/* Ticket button */}
                <Link 
                  to={{
                    pathname: '/Events/' + event.teamA+'-Vs-'+event.teamB,
                  }}
                  state={event}
                  className='btn'>details
                </Link> {/* Details button */}
              </div>
            </div>
          )
        })}
      </div>

    </section>
  );
}

export default HomeEvents;