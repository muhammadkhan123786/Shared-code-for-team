import React from "react";
import "./NewsletterSection.css";

// Import required components
import { Heading, Newsletter } from "../../../components";



const NewsletterSection = () => {
  return (
    <section className="newsletter-subscribe">
      <div className="content">

          <Heading title={"Subscribe To Our Newsletter"} linear /> {/* Section heading with linear style */}
          <p>Be the first to receive updates on upcoming matches, training sessions, and club events by joining our newsletter.</p>

          <Newsletter variant='default' idPrefix='1' /> {/* Newsletter subscription form */}

      </div>
    </section>
  );
};

export default NewsletterSection;