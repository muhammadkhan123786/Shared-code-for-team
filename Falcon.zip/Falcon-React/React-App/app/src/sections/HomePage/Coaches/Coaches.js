import React from 'react';

import { coaches } from '../../../constants';
import { TeamItem, Heading } from '../../../components';



const Coaches = () => {

  return (
    <section className="team-container">

      {/* Section heading */}
      <Heading title={'Team Coaches'} subTitle={'Expert guidance'} />

      {/* Container for listing all coaches */}
      <div className="box-container">
        {coaches.map(coach => (
        // Passing coach data and specifying type as "coaches"
        <TeamItem key={coach.id} team={coach} type='coaches' />
        ))}
      </div>

    </section>
  );
};

export default Coaches;