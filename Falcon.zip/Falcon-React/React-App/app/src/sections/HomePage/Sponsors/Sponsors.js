import React from 'react';
import './Sponsors.css';

// Import Sponsors Data
import { sponsors } from '../../../constants';

// Import Swiper core and required modules
import { Autoplay } from 'swiper/modules';

// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';



const Sponsors = () => {

  return (
    <section className='sponsors'>

      {/* Sponsor Slider Container */}
      <div className='sponsor-slider'>

        <Swiper
          // Install Swiper modules
          modules={[Autoplay]}
          spaceBetween={20}
          loop={true}
          autoplay={{ delay: 5000, disableOnInteraction: false }} // Auto-scroll every 5 seconds
          breakpoints={{
            0: { slidesPerView: 2 },      // 2 slides for small screens
            450: { slidesPerView: 3 },    // 3 slides for medium screens
            768: { slidesPerView: 4 },    // 4 slides for tablets
            1024: { slidesPerView: 5 },   // 5 slides for desktops
          }} 
        >
        {/* Map over the sponsors array to render each sponsor logo */}
        {sponsors.map((sponsor, index) => {
            return (
              /* Render the sponsor image */
              <SwiperSlide className='sponsor-item' key={index}><img src={sponsor} alt='Sponsor Logo' /></SwiperSlide>
            )
          })
        }
        </Swiper>
      </div>
    </section>
  );
}

export default Sponsors;