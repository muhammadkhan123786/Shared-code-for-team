import React from 'react';

// Importing all sections used in the homepage
import { Home, About, Counter, Testimonials, Blogs, NewsletterSection, Sponsors, HomeEvents, PlayerSlider, ResultAndPoint, HomeShop, Trophies, PortfolioSection, Coaches } from '../../sections';


const HomePage = () => {

  return (
    <div className='homepage'>
      <Home /> {/* Home Section */}
      <About /> {/* About Section */}
      <HomeEvents /> {/* Services Slider */}
      <PlayerSlider /> {/* Prayer Timings */}
      <ResultAndPoint /> {/* Banner Section */}
      <PortfolioSection /> {/* Project Section */}
      <Counter /> {/* Counter Section */}
      <HomeShop /> {/* Banner Section */}
      <Trophies /> {/* Upcoming Events Section */}
      <Coaches />
      <Testimonials />
      <Blogs /> {/* Latest blog posts */}
      <NewsletterSection /> {/* Newsletter subscription Section */}
      <Sponsors /> {/* Sponsors Slider */}
    </div>
  )

}

export default HomePage;