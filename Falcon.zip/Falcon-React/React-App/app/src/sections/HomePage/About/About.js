import React from 'react';
import './About.css';

import { Button, Heading} from '../../../components';
import { about } from '../../../constants';

import { BiSolidCricketBall } from 'react-icons/bi';



const About = () => {

  const { sub, heading, description, points, image, button } = about;

  return (
    <section className="about">

      {/* About Image */}
      <div className='image'>
        <img className='sub-image1' src={image.src1} alt={image.alt1} />
        <img className='sub-image2' src={image.src2} alt={image.alt2} />
      </div>

      {/* Introduction Content */}
      <div className="content">

        {/* Section Heading */}
        <Heading title={heading} subTitle={sub} sideHeading />

        {/* Description */}
        {description.map((paragraph, index) => (
          <p key={index}>{paragraph}</p>
        ))}

        {/* Key Features */}
        <div className="about-features">
          {points.map((point, index) => (
            <ul key={index}>
              <li>
                <div className='icon'><BiSolidCricketBall /></div>
                <span>{point}</span>
              </li>
            </ul>
          ))}
        </div>

        {/* Button Component: Links to a specific page or action */}
        <Button link={button.link} title={button.text} />

      </div>
    </section>
  );
};

export default About;