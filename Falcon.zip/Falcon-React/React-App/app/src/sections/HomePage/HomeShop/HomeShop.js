import React from 'react';
import './HomeShop.css';

import { productsContent } from '../../../constants';
import { Heading, Product } from '../../../components';
import { getPopular } from '../../../utils';

 

const HomeShop = () => {

  // Get popular products
  const popularProducts = getPopular(productsContent).slice(0, 8);
 
  return (  
    <section className='home-shop'>

      {/* Section heading */}
      <Heading title={'Popular Products'} subTitle={"Best sellers"} />

      <div className='box-container'>
        { 
        // Render each popular product
          popularProducts.map((product) => {
            return (
              <Product
                key={product.id}
                product={product}
              />   
            )
          })
        }
      </div>

    </section>
  )
  
}

export default HomeShop;