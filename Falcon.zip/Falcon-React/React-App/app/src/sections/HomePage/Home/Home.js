import React from 'react';
import './Home.css';

import { Button } from '../../../components';
import { home } from '../../../constants';

// import Swiper core and required modules
import { Navigation, Pagination, Autoplay } from 'swiper/modules';

// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css';   
import 'swiper/css/pagination';  
import 'swiper/css/navigation'; 

 

const Home = () => { 
  return (

    <section className='home' id='home'>

      <div className='home-slider'>

      <Swiper 
        // Enable navigation, pagination, and autoplay features
        modules={[Navigation, Pagination, Autoplay]}
        loop={true} // Infinite loop
        autoplay={{ delay: 4000, disableOnInteraction: true }} // 4s auto slide
        navigation // Show next/prev arrows
        pagination={{ clickable: true }} // Enable dots that users can click
      >
        { 
        // Dynamically create a slide for each item in homeContent array
          home.map((home) => { 
            return (
            <SwiperSlide className='home-item' key={home.id}>
          
              {/* Background image for the slide */}
              <img src={home.image} alt='home-pic' />

              {/* Text content overlay */}
              <div className='content'> 
                <div className='text'> 
                  <h5>{home.subtitle}</h5> {/* Subtitle with leaf icons */}
                  <h1>{home.title}</h1> {/* Slider Title */}
                  <p>{home.content}</p> {/* Slider Content */}
                  <Button link={home.buttonLink} title={home.buttonText} /> {/* CTA button linking to menu */}
                </div>
              </div>

            </SwiperSlide>
            )
          })
        }

        </Swiper>

      </div>

    </section>

  )
}

export default Home;