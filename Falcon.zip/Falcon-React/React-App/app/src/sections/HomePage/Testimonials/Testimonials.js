import React from 'react';
import './Testimonials.css';

import { Heading } from '../../../components';
import { testiContent } from '../../../constants';

import { FaQuoteLeft } from 'react-icons/fa';
import { VscQuote } from 'react-icons/vsc';

// Import Swiper core and required modules
import { Pagination, Autoplay } from 'swiper/modules';

// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import 'swiper/css'; 
import 'swiper/css/pagination';



const Testimonials = () => { 
  return (
    <section className='testimonials' id='testimonials'>

    <Heading title={'Club Testimonials'} subTitle={'What Fans Say'} />

      <div className='testimonial-slider'>
      <Swiper 
      // install Swiper modules
      modules={[Pagination, Autoplay]}
      spaceBetween={20}
      loop={true}
      autoplay={{ delay: 4000, disableOnInteraction: false }}
      pagination={{ clickable: true }}
      breakpoints= {{
        768:{ 
          slidesPerView: 1,
        },
        1024:{
          slidesPerView: 2,
        }
      }}
      >
        {
          testiContent.map((testimonial) => { 
            return (
              <SwiperSlide className='testi-item' key={testimonial.id}>

                <img src={testimonial.image} alt={testimonial.name} /> {/* Author Pic */}

                {/* Left-side quote icon */}
                <FaQuoteLeft className='quote-left'/>

                {/* Testimonial text container */}
                <div className='comment'>
                  {/* Opening and closing quotes */}
                  <VscQuote className='quote-start'/>
                  <VscQuote className='quote-end'/>
                  {/* Testimonial message */}
                  <p>{testimonial.content}</p>
                </div>

                {/* Client name and title */}
                <div className='intro'>
                  <h3>{testimonial.name}</h3>
                  <h5>{testimonial.title}</h5>
                </div>

              </SwiperSlide>
            )
          })
        }

      </Swiper>
      </div>
      
    </section>

  )
}

export default Testimonials;