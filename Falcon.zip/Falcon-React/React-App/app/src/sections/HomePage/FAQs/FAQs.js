import React from 'react';
import './FAQs.css';

// Import required components and constants
import { Faqs, Heading } from '../../../components';
import { faqsContent, images } from '../../../constants';



const FAQs = () => {
  return (
    <section className='faq-section'>

      {/* Section heading */}
      <Heading title={'Frequently Asked Questions'} subTitle={"FAQ's"} />

      <div className='box-container'>

        {/* Faq Accordion container */}
        <Faqs faqs={faqsContent} />

        {/* Faq Image */}
        <div className='image'>
          <img src={images.FAQs} alt='FAQs-Pic' />
        </div>

      </div>

    </section>
  )
}

export default FAQs;