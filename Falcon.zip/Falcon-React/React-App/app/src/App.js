import React from 'react';

import { Header, Footer, ScrollTop, ScrollToTop, ProfileSingle } from './components';
import { HomePage, AboutUs, TestimonialsPage, BlogGrid, BlogList, BlogSingle, Login, Register, ForgotPwd, ShopGrid, ShopList, Cart, Checkout, Contact, ProductSingle, Wishlist, TeamPage, OrderConfirmation, FaqPage, SponsorPage, EventPage, EventSingle, Error404, TermServices, PrivacyPolicy, PointTable, PortfolioPage, PortfolioSingle, FixturePage, FixtureSingle, CoachesPage, PlayersPage } from './sections';

import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { ToastContainer } from 'react-toastify';



const App = () => {

  return (

    <div className='App'>

      {/* Component to Scroll to Top on Route Change */}
      <ScrollToTop />

      {/* Render the header component */}
      <Header />

      <Routes>

        {/*Home*/}
        <Route path='/' element={<HomePage />} />

        {/*About*/}
        <Route path='/About-us' element={<AboutUs />} />
        <Route path='/Testimonials' element={<TestimonialsPage />} /> 
        <Route path='/Faqs' element={<FaqPage />} />

        {/*Team*/}
        <Route path='/Team' element={<TeamPage />} />  
        <Route path='/Coaches' element={<CoachesPage />} />  
        <Route path='/Coaches/:id' element={<ProfileSingle type="coach" />} />
        <Route path='/Coaches/Coach-Single' element={<ProfileSingle type="coach" />} /> 
        <Route path='/Players' element={<PlayersPage />} />  
        <Route path='/Players/:id' element={<ProfileSingle type="player" />} />    
        <Route path='/Players/Player-Single' element={<ProfileSingle type="player" />} /> 


        {/*Pages*/}
        <Route path='/Point-Table' element={<PointTable />} />

        <Route path='/Events' element={<EventPage />} />   
        <Route path='/Events/:id' element={<EventSingle />} />   
        <Route path='/Events/Event-Single' element={<EventSingle />} /> 

        <Route path='/Fixtures' element={<FixturePage />} />   
        <Route path='/Fixtures/:id' element={<FixtureSingle />} />   
        <Route path='/Fixtures/Fixture-Single' element={<FixtureSingle />} /> 

        <Route path='/Portfolio' element={<PortfolioPage />} />   
        <Route path='/Portfolio/:id' element={<PortfolioSingle />} />   
        <Route path='/Portfolio/Portfolio-Single' element={<PortfolioSingle />} /> 

        <Route path='*' element={<Error404 />} />
        <Route path='/Services-Terms' element={<TermServices />} />
        <Route path='/Privacy-Policy' element={<PrivacyPolicy />} />

        <Route path='/Sponsors' element={<SponsorPage />} />

        {/*Blogs*/}
        <Route path='/Blog-grid' element={<BlogGrid />} /> 
        <Route path='/Blogs/category/:category' element={<BlogList />} /> 
        <Route path='/Blogs/tag/:tag' element={<BlogList />} /> 
        <Route path='/Blogs/search/:search' element={<BlogList />} /> 
        <Route path='/Blog-list' element={<BlogList />} /> 
        <Route path='/Blogs/:id' element={<BlogSingle  />} />
        <Route path='/Blogs/Blog-Single' element={<BlogSingle />} />

        {/*Shop*/}
        <Route path='/Shop-grid' element={<ShopGrid />} />  
        <Route path='/Shop/category/:category' element={<ShopList />} /> 
        <Route path='/Shop/tag/:tag' element={<ShopList />} /> 
        <Route path='/Shop/search/:search' element={<ShopList />} /> 
        <Route path='/Shop-list' element={<ShopList />} />
        <Route path='/Shop/:id' element={<ProductSingle />} />
        <Route path='/Shop/Product-Single' element={<ProductSingle />} /> 
        <Route path='/Wishlist' element={<Wishlist />} />
        <Route path='/Cart' element={<Cart />} />
        <Route path='/Checkout' element={<Checkout />} />
        <Route path='/OrderConfirmation' element={<OrderConfirmation />} />
        <Route path='/Login' element={<Login />} />  
        <Route path='/Register' element={<Register />} /> 
        <Route path='/Forgot-pwd' element={<ForgotPwd />} /> 

        {/*Contact*/}
        <Route path='/Contact-us' element={<Contact />} /> 

      </Routes>

      {/* Render the footer component */}
      <Footer />

      {/* Scroll to top button */}
      <ScrollTop />
      <ToastContainer />

    </div>

  )
}

export default App;
