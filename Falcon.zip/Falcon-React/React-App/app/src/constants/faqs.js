const faqs = [
    { 
        id: 1, 
        heading: 'What facilities does the Cricket Club provide?',
        content: 'We offer practice nets, professional coaching, gym access, turf pitches, and regular tournaments to support players at all levels.',
    },
    {
        id: 2,
        heading: 'What are the training timings?',
        content: 'Training sessions vary by age group and team schedules. You can check our updated training timetable on the website or at the club office.',
    },
    { 
        id: 3,
        heading: 'Do you provide coaching programs?',
        content: 'Yes, we provide coaching for juniors, seniors, and professionals, including batting, bowling, fielding, and fitness training.',
    },
    {
        id: 4,
        heading: 'How can I register or become a member?',
        content: 'You can register online through our membership portal or visit the club reception. Membership gives access to training, matches, and exclusive events.',
    },
    {
        id: 5,
        heading: 'Do you host tournaments and events?',
        content: 'Yes, we organize local leagues, inter-club tournaments, charity matches, and social events to promote cricket and community spirit.',
    },
];

export default faqs;