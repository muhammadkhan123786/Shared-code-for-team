const privacyPolicy = [
  {
    id: "overview",
    title: "1. Overview",
    content: [
      "At Falcon Cricket & Sports Club, we respect the privacy of our players, members, and visitors.",
      "This Privacy Policy explains how we collect, use, and safeguard your personal information when you register, participate in club activities, or use our website and digital services.",
      "By joining our club or engaging with our services, you agree to the terms of this Privacy Policy."
    ]
  },
  {
    id: "data-privacy",
    title: "2. Data Privacy",
    content: [
      "We collect personal and non-personal information to manage memberships, organize tournaments, and improve our services.",
      "The information we collect may include:"
    ],
    list: [
      "Full name, contact details, and membership/registration information",
      "Player profiles and performance statistics",
      "Payment and subscription records",
      "Event registrations and participation details",
      "Feedback, queries, or communications with our club management"
    ]
  },
  {
    id: "terms-of-service",
    title: "3. Terms of Service",
    content: [
      "Our Terms of Service govern the use of the Falcon Cricket & Sports Club website, facilities, and services.",
      "By accessing our grounds, participating in matches, or using our online resources, you agree to follow club rules, community conduct, and fair play principles."
    ]
  },
  {
    id: "user-rights",
    title: "4. Member Rights",
    content: [
      "As a registered member or participant, you have the following rights regarding your personal information:"
    ],
    list: [
      "Right to access, update, or request deletion of your personal information",
      "Right to withdraw consent for data usage",
      "Right to correct inaccurate or incomplete details"
    ]
  },
  {
    id: "data-security",
    title: "5. Data Security",
    content: [
      "We implement secure measures to protect member and player information from unauthorized access, misuse, or disclosure.",
      "This includes encryption, secure servers, and restricted access to sensitive records."
    ]
  },
  {
    id: "cookies",
    title: "6. Cookies",
    content: [
      "Our website may use cookies to enhance user experience and optimize performance.",
      "Cookies allow us to improve navigation, personalize content, and track website analytics."
    ]
  },
  {
    id: "third-party",
    title: "7. Third-Party Services",
    content: [
      "We may collaborate with trusted third-party providers for payment processing, event registrations, and digital tools.",
      "These providers operate under their own privacy policies, and we encourage members to review them when applicable."
    ]
  },
  {
    id: "data-storage",
    title: "8. Data Storage",
    content: [
      "Your personal information is securely stored in compliance with privacy regulations.",
      "We retain member and event records only as long as necessary for club operations or legal purposes."
    ]
  },
  {
    id: "data-transfers",
    title: "9. Data Transfers",
    content: [
      "If your information is stored or processed outside your country, we ensure it is handled securely and in compliance with privacy laws."
    ]
  },
  {
    id: "policy-updates",
    title: "10. Policy Updates",
    content: [
      "This Privacy Policy may be updated to reflect changes in club operations, technology, or legal requirements.",
      "The latest version will always be available on our website."
    ]
  }
];

export default privacyPolicy;