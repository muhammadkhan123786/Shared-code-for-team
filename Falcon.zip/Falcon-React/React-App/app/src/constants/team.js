import images from "./images";

const players = [
  {
    id: 1,
    name: "John Snow",
    role: "Batter/Captain",
    type: "batter",
    image: images.player1,
    personalInfo: {
      dateOfBirth: "1992-04-10",
      nationality: "English",
      height: "6 ft 0 in",
      weight: "80 kg",
      battingStyle: "Right-hand bat",
      bowlingStyle: "Right-arm offbreak",
      majorTeams: ["England", "London Lions"]
    },
    biography: `John Snow is a dynamic right-hand batter and captain, renowned for his consistency and ability to anchor innings under pressure. He has led his club and international sides with determination, guiding his team to several key victories with both leadership and strong batting performances.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 98,
      innings: 90,
      runs: 3750,
      highestScore: 132,
      average: 41.7,
      strikeRate: 86.2,
      hundreds: 8,
      fifties: 22
    },
    bowlingStats: {
      matches: 98,
      wickets: 20,
      bestBowling: "3/19",
      average: 40.2,
      economyRate: 5.1,
      strikeRate: 60.5,
      fiveWicketHauls: 0,
      tenWicketHauls: 0
    }
  },
  {
    id: 2,
    name: "Bob Woolmer",
    role: "Batter",
    type: "batter",
    image: images.player2,
    personalInfo: {
      dateOfBirth: "1993-08-25",
      nationality: "South African",
      height: "5 ft 11 in",
      weight: "78 kg",
      battingStyle: "Left-hand bat",
      bowlingStyle: "Right-arm medium-fast",
      majorTeams: ["South Africa", "Cape Town Challengers"]
    },
    biography: `Bob Woolmer is a stylish left-hand batter known for his elegant stroke play and sharp cricketing mind. With solid technique and patience at the crease, he has played key roles in both domestic and international matches, often turning games in his team’s favor with dependable batting performances.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 88,
      innings: 82,
      runs: 3200,
      highestScore: 128,
      average: 39.5,
      strikeRate: 82.4,
      hundreds: 7,
      fifties: 19
    },
    bowlingStats: {
      matches: 88,
      wickets: 15,
      bestBowling: "2/22",
      average: 45.1,
      economyRate: 5.4,
      strikeRate: 70.2,
      fiveWicketHauls: 0,
      tenWicketHauls: 0
    }
  },

  {
    id: 3,
    name: "Mike Hendrick",
    role: "Batter",
    type: "batter",
    image: images.player3,
    personalInfo: {
      dateOfBirth: "1994-12-02",
      nationality: "English",
      height: "6 ft 2 in",
      weight: "84 kg",
      battingStyle: "Right-hand bat",
      bowlingStyle: "Right-arm medium",
      majorTeams: ["England", "Manchester Royals"]
    },
    biography: `Mike Hendrick is a reliable right-hand batter, admired for his strong defense and ability to build long innings. Known as a steady run-scorer at both club and international levels, he often plays the anchor role, providing stability to the batting lineup in crucial matches.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 76,
      innings: 70,
      runs: 2800,
      highestScore: 122,
      average: 40.0,
      strikeRate: 80.6,
      hundreds: 6,
      fifties: 15
    },
    bowlingStats: {
      matches: 76,
      wickets: 10,
      bestBowling: "2/18",
      average: 48.5,
      economyRate: 5.7,
      strikeRate: 75.0,
      fiveWicketHauls: 0,
      tenWicketHauls: 0
    }
  },

  {
    id: 4,
    name: "Mike Smith",
    role: "Batter",
    type: "batter",
    image: images.player4,
    personalInfo: {
      dateOfBirth: "1995-09-14",
      nationality: "Australian",
      height: "5 ft 10 in",
      weight: "79 kg",
      battingStyle: "Left-hand bat",
      bowlingStyle: "Right-arm offbreak",
      majorTeams: ["Australia", "Melbourne Stars"]
    },
    biography: `Mike Smith is a talented left-hand batter with a reputation for aggressive stroke play. Known for his ability to take on bowlers early, he often provides quick starts at the top of the order. His fearless approach and consistency have made him a key figure in both domestic and international competitions.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 64,
      innings: 60,
      runs: 2500,
      highestScore: 118,
      average: 38.2,
      strikeRate: 92.5,
      hundreds: 5,
      fifties: 13
    },
    bowlingStats: {
      matches: 64,
      wickets: 8,
      bestBowling: "2/21",
      average: 44.7,
      economyRate: 6.1,
      strikeRate: 72.3,
      fiveWicketHauls: 0,
      tenWicketHauls: 0
    }
  },

  {
    id: 5,
    name: "John Lever",
    role: "Batter",
    type: "batter",
    image: images.player5,
    personalInfo: {
      dateOfBirth: "1991-03-22",
      nationality: "English",
      height: "6 ft 0 in",
      weight: "81 kg",
      battingStyle: "Right-hand bat",
      bowlingStyle: "Right-arm medium-fast",
      majorTeams: ["England", "London Royals"]
    },
    biography: `John Lever is a technically sound right-hand batter, known for his patience and ability to build long partnerships. With a calm presence at the crease, he often plays the role of stabilizer in the batting lineup, guiding his team through challenging situations with maturity and skill.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 70,
      innings: 66,
      runs: 2650,
      highestScore: 120,
      average: 39.8,
      strikeRate: 81.4,
      hundreds: 4,
      fifties: 16
    },
    bowlingStats: {
      matches: 70,
      wickets: 12,
      bestBowling: "3/27",
      average: 42.9,
      economyRate: 5.5,
      strikeRate: 68.2,
      fiveWicketHauls: 0,
      tenWicketHauls: 0
    }
  },

  {
    id: 6,
    name: "Peter Willey",
    role: "All-Rounder",
    type: "allrounder",
    image: images.player6,
    personalInfo: {
      dateOfBirth: "1990-11-05",
      nationality: "English",
      height: "5 ft 11 in",
      weight: "83 kg",
      battingStyle: "Right-hand bat",
      bowlingStyle: "Right-arm offbreak",
      majorTeams: ["England", "Durham Dynamos"]
    },
    biography: `Peter Willey is a dependable all-rounder, equally valuable with both bat and ball. His aggressive middle-order batting and economical bowling have made him a versatile player in all formats. Known for his cricketing intelligence, he contributes in multiple departments and often changes the course of matches with crucial performances.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 95,
      innings: 85,
      runs: 3100,
      highestScore: 112,
      average: 36.7,
      strikeRate: 89.1,
      hundreds: 6,
      fifties: 18
    },
    bowlingStats: {
      matches: 95,
      wickets: 72,
      bestBowling: "5/33",
      average: 31.4,
      economyRate: 4.8,
      strikeRate: 46.2,
      fiveWicketHauls: 2,
      tenWicketHauls: 0
    }
  },

  {
    id: 7,
    name: "Clive Radley",
    role: "All-Rounder",
    type: "allrounder",
    image: images.player7,
    personalInfo: {
      dateOfBirth: "1989-07-19",
      nationality: "English",
      height: "5 ft 10 in",
      weight: "80 kg",
      battingStyle: "Right-hand bat",
      bowlingStyle: "Right-arm medium",
      majorTeams: ["England", "Middlesex Lions"]
    },
    biography: `Clive Radley is a versatile all-rounder who has made a name for himself with consistent contributions in both batting and bowling. Known for his solid middle-order batting and ability to provide breakthroughs with the ball, he is regarded as a dependable performer who brings balance and stability to his side.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 102,
      innings: 96,
      runs: 3450,
      highestScore: 124,
      average: 37.5,
      strikeRate: 85.6,
      hundreds: 5,
      fifties: 20
    },
    bowlingStats: {
      matches: 102,
      wickets: 65,
      bestBowling: "4/29",
      average: 33.8,
      economyRate: 5.0,
      strikeRate: 50.7,
      fiveWicketHauls: 1,
      tenWicketHauls: 0
    }
  },

  {
    id: 8,
    name: "Graham Dilley",
    role: "All-Rounder",
    type: "All-Rounder",
    image: images.player8,
    personalInfo: {
      dateOfBirth: "1987-05-10",
      nationality: "English",
      height: "6 ft 3 in",
      weight: "84 kg",
      battingStyle: "Left-hand bat",
      bowlingStyle: "Right-arm fast-medium",
      majorTeams: ["England", "Kent Spitfires"]
    },
    biography: `Graham Dilley is a dynamic all-rounder known for his powerful lower-order hitting and effective seam bowling. Standing tall, he generates bounce and movement that troubles top-order batters, while his aggressive batting often provides crucial runs in pressure situations.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 90,
      innings: 75,
      runs: 1850,
      highestScore: 89,
      average: 27.4,
      strikeRate: 92.1,
      hundreds: 0,
      fifties: 8
    },
    bowlingStats: {
      matches: 90,
      wickets: 95,
      bestBowling: "5/34",
      average: 29.5,
      economyRate: 4.7,
      strikeRate: 42.8,
      fiveWicketHauls: 3,
      tenWicketHauls: 0
    }
  },

  {
    id: 9,
    name: "Vic Marks",
    role: "All-Rounder",
    type: "allrounder",
    image: images.player9,
    personalInfo: {
      dateOfBirth: "1955-06-25",
      nationality: "English",
      height: "5 ft 11 in",
      weight: "78 kg",
      battingStyle: "Right-hand bat",
      bowlingStyle: "Right-arm offbreak",
      majorTeams: ["England", "Somerset"]
    },
    biography: `Vic Marks is a steady all-rounder renowned for his reliable middle-order batting and effective off-spin bowling. Known for his calm temperament and ability to adapt to match situations, he has contributed significantly to both domestic and international cricket.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 110,
      innings: 95,
      runs: 2600,
      highestScore: 102,
      average: 32.1,
      strikeRate: 76.4,
      hundreds: 2,
      fifties: 15
    },
    bowlingStats: {
      matches: 110,
      wickets: 125,
      bestBowling: "5/41",
      average: 30.8,
      economyRate: 4.3,
      strikeRate: 50.6,
      fiveWicketHauls: 2,
      tenWicketHauls: 0
    }
  },

  {
    id: 10,
    name: "Jack Richards",
    role: "All-Rounder",
    type: "allrounder",
    image: images.player10,
    personalInfo: {
      dateOfBirth: "1958-08-10",
      nationality: "English",
      height: "5 ft 10 in",
      weight: "77 kg",
      battingStyle: "Right-hand bat",
      bowlingStyle: "Right-arm medium",
      majorTeams: ["England", "Surrey"]
    },
    biography: `Jack Richards was a versatile cricketer who contributed as both a dependable middle-order batter and a capable bowler. Known for his adaptability and strong work ethic, he played crucial roles in domestic cricket and represented England with distinction.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 85,
      innings: 70,
      runs: 1800,
      highestScore: 95,
      average: 27.5,
      strikeRate: 74.8,
      hundreds: 0,
      fifties: 10
    },
    bowlingStats: {
      matches: 85,
      wickets: 40,
      bestBowling: "4/32",
      average: 34.2,
      economyRate: 4.6,
      strikeRate: 47.1,
      fiveWicketHauls: 0,
      tenWicketHauls: 0
    }
  },

  {
    id: 11,
    name: "Chris Smith",
    role: "Bowler",
    type: "bowler",
    image: images.player11,
    personalInfo: {
      dateOfBirth: "1958-10-15",
      nationality: "English",
      height: "6 ft 1 in",
      weight: "83 kg",
      battingStyle: "Left-hand bat",
      bowlingStyle: "Right-arm fast-medium",
      majorTeams: ["England", "Warwickshire"]
    },
    biography: `Chris Smith was a talented bowler known for his consistency and ability to trouble batters with movement off the pitch. While primarily a bowler, he also contributed handy runs down the order, making him a valuable team player in both domestic and international matches.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 75,
      innings: 40,
      runs: 620,
      highestScore: 55,
      average: 16.8,
      strikeRate: 68.2,
      hundreds: 0,
      fifties: 2
    },
    bowlingStats: {
      matches: 75,
      wickets: 145,
      bestBowling: "6/41",
      average: 27.4,
      economyRate: 3.9,
      strikeRate: 44.8,
      fiveWicketHauls: 3,
      tenWicketHauls: 0
    }
  },

  {
    id: 12,
    name: "Richard Ellison",
    role: "Bowler",
    type: "bowler",
    image: images.player12,
    personalInfo: {
      dateOfBirth: "1959-09-21",
      nationality: "English",
      height: "6 ft 0 in",
      weight: "81 kg",
      battingStyle: "Right-hand bat",
      bowlingStyle: "Right-arm medium-fast",
      majorTeams: ["England", "Kent"]
    },
    biography: `Richard Ellison was a skillful swing bowler who gained recognition for his match-winning performances with the ball, especially in English conditions. His ability to move the ball both ways made him a challenging bowler for top-order batters. Though primarily a bowler, he also chipped in with useful runs down the order.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 65,
      innings: 38,
      runs: 540,
      highestScore: 48,
      average: 14.2,
      strikeRate: 64.7,
      hundreds: 0,
      fifties: 0
    },
    bowlingStats: {
      matches: 65,
      wickets: 125,
      bestBowling: "5/35",
      average: 29.1,
      economyRate: 3.8,
      strikeRate: 47.2,
      fiveWicketHauls: 4,
      tenWicketHauls: 0
    }
  },

  {
    id: 13,
    name: "Tim Robinson",
    role: "Bowler",
    type: "bowler",
    image: images.player13,
    personalInfo: {
      dateOfBirth: "1958-11-03",
      nationality: "English",
      height: "5 ft 11 in",
      weight: "80 kg",
      battingStyle: "Right-hand bat",
      bowlingStyle: "Right-arm medium",
      majorTeams: ["England", "Nottinghamshire"]
    },
    biography: `Tim Robinson was a dependable cricketer recognized for his contributions at the domestic level. While primarily known as a reliable bowler, he also added depth to the lower batting order. His consistent line and length allowed him to restrict runs and pick up crucial wickets in tight games.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 70,
      innings: 42,
      runs: 620,
      highestScore: 52,
      average: 15.5,
      strikeRate: 61.3,
      hundreds: 0,
      fifties: 1
    },
    bowlingStats: {
      matches: 70,
      wickets: 138,
      bestBowling: "6/40",
      average: 28.4,
      economyRate: 3.6,
      strikeRate: 45.1,
      fiveWicketHauls: 6,
      tenWicketHauls: 1
    }
  },

  {
    id: 14,
    name: "James Whitaker",
    role: "Bowler",
    type: "bowler",
    image: images.player14,
    personalInfo: {
      dateOfBirth: "1962-05-05",
      nationality: "English",
      height: "6 ft 0 in",
      weight: "81 kg",
      battingStyle: "Right-hand bat",
      bowlingStyle: "Right-arm medium",
      majorTeams: ["England", "Leicestershire"]
    },
    biography: `James Whitaker was a dependable English cricketer recognized for his steady bowling and his valuable contributions in domestic cricket. He built his reputation through consistency and determination, often stepping up in crucial moments for Leicestershire and England.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 55,
      innings: 38,
      runs: 480,
      highestScore: 46,
      average: 14.1,
      strikeRate: 59.7,
      hundreds: 0,
      fifties: 0
    },
    bowlingStats: {
      matches: 55,
      wickets: 95,
      bestBowling: "5/32",
      average: 31.8,
      economyRate: 3.9,
      strikeRate: 49.2,
      fiveWicketHauls: 3,
      tenWicketHauls: 0
    }
  },

  {
    id: 15,
    name: "Chris Lewis",
    role: "Bowler",
    type: "bowler",
    image: images.player15,
    personalInfo: {
      dateOfBirth: "1968-02-14",
      nationality: "English",
      height: "6 ft 2 in",
      weight: "83 kg",
      battingStyle: "Right-hand bat",
      bowlingStyle: "Right-arm fast-medium",
      majorTeams: ["England", "Surrey", "Nottinghamshire"]
    },
    biography: `Chris Lewis was an athletic English fast-medium bowler known for his pace, sharp seam movement, and ability to contribute valuable lower-order runs. A naturally gifted cricketer, he represented England across formats in the 1990s and was considered one of the most versatile players of his era.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 85,
      innings: 65,
      runs: 1120,
      highestScore: 95,
      average: 21.5,
      strikeRate: 72.4,
      hundreds: 0,
      fifties: 5
    },
    bowlingStats: {
      matches: 85,
      wickets: 145,
      bestBowling: "6/67",
      average: 32.1,
      economyRate: 4.2,
      strikeRate: 47.5,
      fiveWicketHauls: 4,
      tenWicketHauls: 0
    }
  },

  {
    id: 16,
    name: "Steve Watkin",
    role: "Bowler",
    type: "bowler",
    image: images.player16,
    personalInfo: {
      dateOfBirth: "1964-09-05",
      nationality: "Welsh",
      height: "6 ft 0 in",
      weight: "80 kg",
      battingStyle: "Right-hand bat",
      bowlingStyle: "Right-arm medium-fast",
      majorTeams: ["England", "Glamorgan"]
    },
    biography: `Steve Watkin was a reliable right-arm medium-fast bowler from Wales, recognized for his accuracy, swing, and ability to provide crucial breakthroughs. He represented England in the early 1990s and was a key figure for Glamorgan throughout his domestic career.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
    battingStats: {
      matches: 35,
      innings: 20,
      runs: 260,
      highestScore: 42,
      average: 13.0,
      strikeRate: 58.4,
      hundreds: 0,
      fifties: 0
    },
    bowlingStats: {
      matches: 35,
      wickets: 75,
      bestBowling: "5/49",
      average: 29.4,
      economyRate: 3.7,
      strikeRate: 47.8,
      fiveWicketHauls: 1,
      tenWicketHauls: 0
    }
  }

];

const coaches = [

  {
    id: 17,
    name: "Colin Cowdrey",
    role: "Head Coach", 
    type: "coach",
    image: images.coach1,
    personalInfo: {
      dateOfBirth: "1932-12-24",
      nationality: "English",
      height: "6 ft 0 in",
      weight: "82 kg",
      coachingRole: "Head Coach",
      coachingExperience: "15 years",
      certifications: ["ECB Level 3 Coaching", "ICC High Performance Coaching"],
      majorTeamsCoached: ["Kent", "England"]
    },
    biography: `Colin Cowdrey, one of England’s most distinguished cricketers, transitioned into a respected coaching figure after his playing career. Known for his elegant batting and leadership as England’s captain, he carried his deep knowledge of the game into coaching, mentoring players with a focus on technique, discipline, and team spirit.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
  },
  {
    id: 18,
    name: "Barry Wood",
    role: "Assistant Coach", 
    type: "coach",
    image: images.coach2,
    personalInfo: {
      dateOfBirth: "1942-12-26",
      nationality: "English",
      height: "5 ft 10 in",
      weight: "76 kg",
      coachingRole: "Assistant Coach",
      coachingExperience: "10 years",
      certifications: ["ECB Level 2 Coaching", "Specialist Batting Coach Certification"],
      majorTeamsCoached: ["Lancashire", "England A"]
    },
    biography: `Barry Wood, a former England cricketer, is widely respected for his technical expertise and mentoring skills. As an assistant coach, he specializes in batting and player development, focusing on improving consistency, shot selection, and adaptability under pressure. His experience as an international batsman brings immense value to his coaching role.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
  },
  {
    id: 19,
    name: "Peter Lever",
    role: "Batting Coach", 
    type: "coach",
    image: images.coach3,
    personalInfo: {
      dateOfBirth: "1940-09-17",
      nationality: "English",
      height: "6 ft 0 in",
      weight: "80 kg",
      coachingRole: "Batting Coach",
      coachingExperience: "14 years",
      certifications: ["ECB Level 3 Coaching", "ICC Specialist Batting Coach"],
      majorTeamsCoached: ["England U19", "Lancashire"]
    },
    biography: `Peter Lever, a former England cricketer, is known for his technical precision and deep understanding of batting mechanics. As a batting coach, he has guided several emerging and established players, focusing on technique, temperament, and adaptability in various match situations. His extensive international and domestic experience makes him a valuable mentor for aspiring batters.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
  },
  {
    id: 20,
    name: "Frank Hayes",
    role: "Bowling Coach", 
    type: "coach",
    image: images.coach4,
    personalInfo: {
      dateOfBirth: "1946-10-09",
      nationality: "English",
      height: "6 ft 1 in",
      weight: "82 kg",
      coachingRole: "Bowling Coach",
      coachingExperience: "11 years",
      certifications: ["ECB Level 3 Coaching", "ICC Specialist Bowling Coach"],
      majorTeamsCoached: ["England Lions", "Lancashire"]
    },
    biography: `Frank Hayes, a former English cricketer, transitioned into coaching with a focus on developing effective bowling strategies. Known for his tactical insights and technical corrections, he has worked with both pace and spin bowlers. His mentorship emphasizes discipline, control, and match awareness, helping bowlers excel in high-pressure environments.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
  },
  {
    id: 21,
    name: "Robin Jackman",
    role: "Fielding Coach", 
    type: "coach",
    image: images.coach5,
    personalInfo: {
      dateOfBirth: "1945-08-13",
      nationality: "English",
      height: "5 ft 10 in",
      weight: "79 kg",
      coachingRole: "Fielding Coach",
      coachingExperience: "10 years",
      certifications: ["ECB Level 3 Coaching", "ICC Specialist Fielding Coach"],
      majorTeamsCoached: ["Surrey", "England A"]
    },
    biography: `Robin Jackman, a former England cricketer, built a reputation as a sharp tactician and later specialized in fielding development. Known for his attention to detail, he focused on improving agility, reflexes, and catching techniques. His coaching has been instrumental in raising fielding standards and inspiring young cricketers to excel in the modern, fast-paced game.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
  },
  {
    id: 22,
    name: "David Steele",
    role: "Team Manager", 
    type: "coach",
    image: images.coach6,
    personalInfo: {
      dateOfBirth: "1941-09-29",
      nationality: "English",
      height: "5 ft 9 in",
      weight: "77 kg",
      managementRole: "Team Manager",
      managementExperience: "15 years",
      certifications: ["ECB Team Management Certification", "Sports Leadership Diploma"],
      majorTeamsManaged: ["Northamptonshire", "England Youth"]
    },
    biography: `David Steele, remembered as one of England’s most resilient cricketers, transitioned into management with the same determination he showed on the field. As Team Manager, he focuses on building discipline, ensuring smooth operations, and maintaining player welfare. His leadership style emphasizes unity, preparation, and professionalism, making him a respected figure within the squad.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
  },
  {
    id: 23,
    name: "Graham Stevenson",
    role: "Team Analyst", 
    type: "coach",
    image: images.coach7,
    personalInfo: {
      dateOfBirth: "1955-12-16",
      nationality: "English",
      height: "6 ft 0 in",
      weight: "80 kg",
      specialization: "Team Performance Analysis",
      experience: "10 years",
      certifications: ["ECB Performance Analysis Certification", "Sports Data Analytics Diploma"],
      majorTeamsAnalyzed: ["Yorkshire", "England Lions"]
    },
    biography: `Graham Stevenson, a former English cricketer, brought his cricketing knowledge into performance analysis after retirement. As a Team Analyst, he specializes in studying match data, player performances, and opposition strategies. His analytical insights provide the team with a competitive edge, ensuring well-prepared game plans and tactical decisions.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
  },
  {
    id: 24,
    name: "Richard Ellison",
    role: "Media Manager", 
    type: "coach",
    image: images.coach8,
    personalInfo: {
      dateOfBirth: "1959-09-21",
      nationality: "English",
      height: "6 ft 1 in",
      weight: "82 kg",
      specialization: "Media & Communications",
      experience: "8 years",
      certifications: ["Sports Media Management Certification", "Public Relations Diploma"],
      majorTeamsWorkedWith: ["Kent", "England Cricket Board"]
    },
    biography: `Richard Ellison, a former English fast-medium bowler, transitioned into cricket media and communications after his playing career. As Media Manager, he oversees press relations, digital media strategies, and public communications for the team. His experience as an international cricketer allows him to bridge the gap between players and the media, ensuring the team maintains a strong and professional public presence.`,
    accounts: {
      facebook: "",
      linkedin: "",
      twitter: "",
      instagram: ""
    },
  }

];

export { players, coaches };