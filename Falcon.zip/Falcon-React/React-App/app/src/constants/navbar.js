import blogs from './blogs';
import products from './products';
import portfolio from './portfolio';
import events from './events';
import fixtures from './fixtures';
import { coaches, players } from './team';



const navbar = [
    {
        id: 1,
        mainLink : {link: '/', title: 'home'},
        subLink: [],
    },
    {
        id: 2,
        mainLink : {link: '#', title: 'about'},
        subLink: [
            {id: 1, link: '/About-us', title: 'about us'},
            {id: 2, link: '/Testimonials', title: 'testimonials'},
            {id: 3, link: '/Faqs', title: 'faqs'},
        ],
    },
    {
        id: 3,
        mainLink : {link: '#', title: 'Team'},
        subLink: [
            { id: 1, link: "/Team", title: "Team" },
            { id: 2, link: "/Coaches", title: "Coaches" },
            { id: 3, link: "/Coaches/Coach-Single", title: "Coach Single",  state: coaches[0] },
            { id: 4, link: "/Players", title: "Players" },
            { id: 5, link: "/Players/Player-Single", title: "Player Single", state: players[0] },
        ],
    },
    {
        id: 4,
        mainLink: { title: "Pages", link: "#" },
        subLink: [
            { id: 1, link: "/Point-Table", title: "Point Table" },
            {
                id: 2,
                title: "Event",
                children: [
                    { id: 1, link: "/Events", title: "Events" },
                    { id: 2, link: "/Events/Event-Single", title: "Event Single", state: events[0] },
                ],
            },
            {
                id: 3,
                title: "Fixture",
                children: [
                    { id: 1, link: "/Fixtures", title: "Fixtures" },
                    { id: 2, link: "/Fixtures/Fixture-Single", title: "Fixture Single", state: fixtures[0] },
                ],
            },
            {
                id: 4,
                title: "Portfolio",
                children: [
                    { id: 1, link: "/Portfolio", title: "Portfolio" },
                    { id: 2, link: "/Portfolio/Portfolio-Single", title: "Portfolio Single", state: portfolio[0] },
                ],
            },
            {
                id: 5,
                title: "Information Hub",
                children: [
                    { id: 1, link: "*", title: "Error 404" },
                    { id: 2, link: "/Services-Terms", title: "Terms of Services" },
                    { id: 3, link: "/Privacy-Policy", title: "Privacy Policy" },
                ],
            },
            { id: 6, link: "/Sponsors", title: "Sponsors" },
        ],
    },
    {
        id: 5,
        mainLink : {link: '#', title: 'blog'},
        subLink: [
            {id: 1, link: '/Blog-grid', title: 'blog grid'},
            {id: 2, link: '/Blog-list', title: 'blog list'},
            {id: 3, link: '/Blogs/Blog-Single', title: 'blog single', state: blogs[0]},
        ],
    },
    {
        id: 6,
        mainLink : {link: '#', title: 'shop'},
        subLink: [
            {id: 1, link: '/Shop-grid', title: 'shop grid'},
            {id: 2, link: '/Shop-list', title: 'shop list'},
            {id: 3, link: '/Shop/Product-Single', title: 'product single', state: products[0]},
            {id: 4, link: '/Wishlist', title: 'wishlist'},
            {id: 5, link: '/Cart', title: 'cart'},
            {id: 6, link: '/Checkout', title: 'checkout'},
            {id: 7, link: '/OrderConfirmation', title: 'Order Confirmation'},
            {id: 8, link: '/Login', title: 'login'},
            {id: 9, link: '/Register', title: 'register'},
            {id: 10, link: '/Forgot-pwd', title: 'forgot Password'},
        ],
    },
    {
        id: 7,
        mainLink : {link: '/Contact-us', title: 'contact'},
        subLink: [],
    },
];

export default navbar;