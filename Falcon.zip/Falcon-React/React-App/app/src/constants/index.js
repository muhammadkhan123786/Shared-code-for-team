/*Global*/
export { default as images } from './images';
export { default as navbar } from './navbar';


/*Home*/
export { default as home } from './home';
export { default as counter } from './counter';
export { default as trophies } from './trophies';


/*About*/
export { default as about } from './about';
export { default as testiContent } from './testimonials';
export { default as faqsContent } from './faqs';


/*Team*/
export { players, coaches } from './team';


/*Pages*/   
export { default as pointTable } from './pointTable';
export { default as cricketTeams } from './cricketTeams';
export { default as events } from './events';
export { default as fixtures } from './fixtures';
export { default as portfolio } from './portfolio';
export { default as privacyPolicy } from './privacyPolicy';
export { default as serviceTerms } from './serviceTerms';
export { default as sponsors } from './sponsors';


/*Blogs*/
export { default as blogContent } from './blogs';


/*Shop*/
export { default as productsContent} from './products';
export { payment } from './paymentMethods';


/*Contact*/
export { default as contactContent } from './contacts';