import { FaEnvelope, FaMapMarkedAlt, FaPhoneAlt } from "react-icons/fa";

const contacts = [
    {
        id: 1,
        icon: <FaMapMarkedAlt />,
        title: "address",
        content: ["Falcon Cricket Academy, Phoenix Park, Dublin"]
    },
    {
        id: 2,
        icon: <FaPhoneAlt />,
        title: "call us",
        content: ["+123-456-7890", "+111-222-333"],
    },
    {
        id: 3,
        icon: <FaEnvelope />,
        title: "mail us",
        content: ["info@example.com", "xyz@gmail.com"],
    },
];

export default contacts;