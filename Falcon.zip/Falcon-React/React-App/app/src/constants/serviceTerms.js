const serviceTerms = [
  { 
    id: "overview",
    title: "1. Overview", 
    content: [
      "This section provides a general summary of the terms governing your participation in and use of the Falcon Cricket & Sports Club’s facilities, events, training sessions, and activities.",
      "By becoming a member, registering for events, or using our resources, you agree to follow the guidelines set forth in these Terms & Conditions."
    ]
  }, 
  { 
    id: "acceptable-use", 
    title: "2. Code of Conduct", 
    content: [
      "All players, members, and visitors must maintain discipline, sportsmanship, and respect both on and off the field.",
      "Misconduct such as abusive language, unsporting behavior, damage to club property, or actions against the spirit of the game are strictly prohibited."
    ]
  },
  { 
    id: "registration", 
    title: "3. Membership & Registration", 
    content: [
      "Enrollment in the club, matches, or training programs requires prior registration through official channels.",
      "Membership fees and event charges must be paid through approved methods. Receipts will be issued on request.",
      "Failure to complete registration or membership payment may result in loss of access to matches, events, or facilities."
    ]
  },
  { 
    id: "member-responsibilities", 
    title: "4. Member Responsibilities", 
    content: [
      "Members must provide accurate information during registration or team selection.",
      "All players are expected to arrive on time, wear proper kits, and maintain discipline during matches and training.",
      "Any safety hazards, injuries, or incidents should be immediately reported to the club’s management."
    ]
  },
  { 
    id: "limitation-liability", 
    title: "5. Limitation of Liability", 
    content: [
      "The Falcon Cricket & Sports Club shall not be held responsible for lost or damaged personal belongings.",
      "The club is not liable for injuries, delays, or cancellations caused by weather, accidents, or factors beyond our control."
    ]
  },
  { 
    id: "termination", 
    title: "6. Suspension or Termination", 
    content: [
      "The club reserves the right to suspend or terminate membership in cases of serious misconduct or violation of these Terms & Conditions.",
      "Such actions may be taken with or without prior notice depending on the nature of the offense."
    ]
  },
  { 
    id: "intellectual-property", 
    title: "7. Media & Intellectual Property", 
    content: [
      "All logos, event branding, training materials, and digital content created by the Falcon Cricket & Sports Club remain the property of the club.",
      "Photos and videos taken during matches or events may be used for promotional purposes unless members request otherwise in writing."
    ]
  },
  { 
    id: "governing-law", 
    title: "8. Governing Law", 
    content: [
      "These Terms & Conditions are governed by the laws of [Your Country/State] along with fair-play principles of cricket and sports ethics.",
      "Any disputes will first be addressed through the club’s management before pursuing legal options in [City/Region]."
    ]
  },
  { 
    id: "contact-info", 
    title: "9. Contact Information", 
    content: [
      "For questions or concerns regarding these Terms & Conditions or our services, please contact us:",
      "Email: info@falconclub.com",
      "Phone: +[Your Phone Number]"
    ]
  }
];

export default serviceTerms;