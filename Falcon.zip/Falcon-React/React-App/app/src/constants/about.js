import images from "./images";

const About = {
  sub: "About Us",
  heading: "Your Trusted Cricket & Sports Club",
  description: [
    "Welcome to Falcon Cricket & Sports Club, the home of passion, performance, and sportsmanship. Established to nurture talent and promote cricket, our club is dedicated to building champions both on and off the field.",
  ],
  points: [
    "Professional Coaching & Training Programs",
    "State-of-the-Art Practice Facilities",
    "Participation in Local & National Tournaments",
    "Youth Development & Community Engagement",
  ],
  image: {
    src1: images.about1,
    src2: images.about2,
    alt1: "Falcon Cricket Club Training Session",
    alt2: "Falcon Cricket Club Team Celebration",
  },
  button: {
    text: "Join the Club",
    link: "Contact-us",
  },
};

export default About;