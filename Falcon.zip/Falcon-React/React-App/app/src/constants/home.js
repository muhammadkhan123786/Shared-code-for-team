import images from "./images";

const home = [
  {
    id: 1,
    image: images.home1,
    subtitle: "Welcome to United Falcon",
    title: "United, we play, United, we win!",
    content: "The Falcon is the popular and most powerful team in the Tournament. It is establish to provide an opportunity to improve cricketing skill of young talented cricketers.",
    buttonText: "Contact Us",
    buttonLink: "Contact-us",
  },
  {
    id: 2,
    image: images.home2,
    subtitle: "Welcome to United Falcon",
    title: "Teamwork makes the dream work!",
    content: "The Falcon is the popular and most powerful team in the Tournament. It is establish to provide an opportunity to improve cricketing skill of young talented cricketers.",
    buttonText: "Contact Us",
    buttonLink: "Contact-us",
  },
  {
    id: 3,
    image: images.home3,
    subtitle: "Welcome to United Falcon",
    title: "Bringing out the best in each other!",
    content: "The Falcon is the popular and most powerful team in the Tournament. It is establish to provide an opportunity to improve cricketing skill of young talented cricketers.",
    buttonText: "Contact Us",
    buttonLink: "Contact-us",
  },
];

export default home;