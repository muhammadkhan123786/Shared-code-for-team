import { FaTrophy, FaUsers, FaRunning, FaCalendarAlt } from 'react-icons/fa';

const counter = [
    {
        id: 1,
        icon: <FaTrophy />, // Trophy icon for Matches Played
        title: 'Matches Played',
        count: '250',
    },
    {
        id: 2,
        icon: <FaRunning />, // Running icon for Active Players
        title: 'Active Players',
        count: '120',
    },
    {
        id: 3,
        icon: <FaCalendarAlt />, // Calendar icon for Events Organized
        title: 'Events Organized',
        count: '85',
    },
    {
        id: 4,
        icon: <FaUsers />, // Users icon for Club Members
        title: 'Club Members',
        count: '1500',
    },
];

export default counter;