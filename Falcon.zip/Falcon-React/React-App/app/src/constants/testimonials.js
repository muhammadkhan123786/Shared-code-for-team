import images from "./images";

const testimonials = [  
    { 
        id: 1,
        name: 'James Anderson', 
        title: 'Club Player',
        content: 'Joining United Falcon has sharpened my game and boosted my confidence. The training sessions are challenging and rewarding.',
        image: images.testimonial1,
    }, 
    { 
        id: 2,
        name: 'Sana Malik', 
        title: 'Club Supporter',
        content: "I’ve been following the club for years, and the energy during matches is unmatched. The team spirit truly brings the community together.",
        image: images.testimonial2,
    },
    { 
        id: 3,
        name: 'David Miller', 
        title: 'Former Captain',
        content: 'Leading United Falcon was an incredible experience. The club instills discipline, teamwork, and a winning mentality.',
        image: images.testimonial3,
    },
    { 
        id: 4,
        name: 'Aisha Thompson', 
        title: 'Parent of Player',
        content: "My daughter has grown so much as a cricketer since joining United Falcon. The coaches are supportive and encourage players to reach their potential.",
        image: images.testimonial4,
    },
];

export default testimonials;