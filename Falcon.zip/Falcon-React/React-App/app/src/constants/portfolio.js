import images from "./images";

const portfolio = [
    {
        id: 1,
        image: images.portfolio1,
        title: "Most Epic Match, NC-2",
        details: {
            matchDate: "Jan 15, 2024",
            category: "National Cup",
            matchType: "Group Stage / Final",
            venue: "Main Stadium, Karachi",
            ticketPrice: "₹500 / Online Streaming Free",
            matchOfficial: "Match Commissioner",
            duration: "Full Day"
        },
        paragraphs: [
            "The National Cup Match NC-2 showcased a thrilling contest between top cricket teams, engaging fans with exceptional skills, teamwork, and sportsmanship. Every session kept the audience on the edge of their seats.",
            "Organized with meticulous planning, the match included live commentary, professional umpiring, and full media coverage, ensuring a seamless experience for both in-stadium spectators and online viewers."
        ],
        gallery: [
            images.portfolio1Gallery1,
            images.portfolio1Gallery2,
            images.portfolio1Gallery3,
            images.portfolio1Gallery4,
            images.portfolio1Gallery5,
            images.portfolio1Gallery6
        ],
        teamLineup: [
            "Openers: James Anderson (RHB), John Smith (RHB) – set the innings foundation",
            "Top Order: Robert Johnson (RHB), Michael Davis (RHB), William Brown (RHB) – stabilize and accelerate scoring",
            "Middle Order All-Rounders: David Martinez (LHB, Leg Spin), Joseph Taylor (RHB, Leg Spin), Lucas Baker (All-Rounder) – provide balance with batting and bowling",
            "Wicket-Keeper: Kevin King (RHB) – lead field coordination and key dismissals",
            "Bowlers: Charles Wilson (RMF), Thomas Thompson (RF), Daniel Garcia (RMF) – execute strategic bowling spells"
        ],
        eventHighlights: [
            "Team A scored 250/7 in 50 overs",
            "James Anderson top-scored with 85 runs off 60 balls",
            "David Martinez took 3 wickets for 42 runs",
            "Lucas Baker contributed 45 runs and 2 wickets",
            "Team B managed 245/9 in 50 overs – Team A won by 5 runs",
            "Player of the Match: James Anderson for batting brilliance"
        ]
    },
    {
        id: 2,
        image: images.portfolio2,
        title: "Training Sessions",
        details: {
            sessionDate: "Feb 5-10, 2024",
            category: "Champion Trophy",
            sessionType: "Pre-Tournament Training",
            venue: "Main Stadium & Practice Grounds, Karachi",
            ticketPrice: "Free / Online Streaming Optional",
            sessionLead: "Head Coach & Training Staff",
            duration: "6 Days"
        },
        paragraphs: [
            "The Champion Trophy Training Sessions were organized to prepare teams for the upcoming tournament. Players focused on skill enhancement, strategic practice, and overall fitness to ensure peak performance.",
            "Led by experienced coaches, the sessions included specialized drills for batting, bowling, fielding, and wicket-keeping, alongside team strategy discussions and simulated match scenarios."
        ],
        gallery: [
            images.portfolio2Gallery1,
            images.portfolio2Gallery2,
            images.portfolio2Gallery3,
            images.portfolio2Gallery4,
            images.portfolio2Gallery5,
            images.portfolio2Gallery6
        ],
        teamLineup: [
            "Openers & Top Order Batsmen: Focus on technique and timing",
            "Middle Order & All-Rounders: Enhance batting, bowling, and fielding skills",
            "Bowlers: Perfect line, length, pace, and spin variations",
            "Fielders: Improve agility, catching, and ground fielding",
            "Wicket-Keeper: Practice quick reflexes and coordination"
        ],
        eventHighlights: [
            "Intensive net sessions for batting and bowling",
            "Fielding drills improving catching, ground fielding, and agility",
            "Simulated match scenarios to enhance teamwork and strategy",
            "Individual skill improvement tracked by coaching staff",
            "Overall team performance enhanced ahead of the Champion Trophy"
        ]
    },
    {
        id: 3,
        image: images.portfolio3,
        title: "Top Scorer, PL-2",
        details: {
            matchDate: "Mar 10, 2024",
            category: "Premier League",
            matchType: "Group Stage / Match 2",
            venue: "Main Stadium, Karachi",
            ticketPrice: "₹500 / Online Streaming Free",
            matchOfficial: "Match Commissioner",
            duration: "Full Day"
        },
        paragraphs: [
            "Premier League Match PL-2 delivered an exciting contest, with players showcasing top-notch cricketing skills. Spectators witnessed aggressive batting, strategic bowling, and excellent fielding throughout the match.",
            "The match was organized professionally with live commentary, umpiring, and media coverage, providing a complete cricketing experience for fans both in-stadium and online."
        ],
        gallery: [
            images.portfolio3Gallery1,
            images.portfolio3Gallery2,
            images.portfolio3Gallery3,
            images.portfolio3Gallery4,
            images.portfolio3Gallery5,
            images.portfolio3Gallery6
        ],
        teamLineup: [
            "Openers: James Anderson (RHB), John Smith (RHB) – set the innings pace",
            "Top Order: Robert Johnson (RHB), Michael Davis (RHB), William Brown (RHB) – stabilize and accelerate scoring",
            "Middle Order All-Rounders: David Martinez (LHB, Leg Spin), Joseph Taylor (RHB, Leg Spin), Lucas Baker (All-Rounder) – balance batting and bowling",
            "Wicket-Keeper: Kevin King (RHB) – maintain field coordination and key dismissals",
            "Bowlers: Charles Wilson (RMF), Thomas Thompson (RF), Daniel Garcia (RMF) – execute strategic bowling plans"
        ],
        eventHighlights: [
            "Team A scored 280/6 in 50 overs",
            "Robert Johnson top-scored with 95 runs off 70 balls",
            "David Martinez took 4 wickets for 38 runs",
            "Lucas Baker contributed 50 runs and 2 wickets",
            "Team B managed 270/8 in 50 overs – Team A won by 10 runs",
            "Player of the Match: Robert Johnson for batting excellence"
        ]
    },
    {
        id: 4,
        image: images.portfolio4,
        title: "Victory Celebration, 2021",
        details: {
            eventDate: "Dec 20, 2021",
            category: "National Cup",
            eventType: "Post-Tournament Celebration",
            venue: "Main Stadium, Karachi",
            ticketPrice: "Free Entry",
            eventLead: "Club Management & Team Captain",
            duration: "Full Day"
        },
        paragraphs: [
            "The Victory Celebration of the 2021 National Cup honored the outstanding performance of the winning team. Fans, players, and officials gathered to celebrate the hard-earned victory and remarkable achievements.",
            "The event included trophy presentation, speeches from the team captain and management, photo sessions, and interactive activities with supporters, highlighting the spirit of sportsmanship and community engagement."
        ],
        gallery: [
            images.portfolio4Gallery1,
            images.portfolio4Gallery2,
            images.portfolio4Gallery3,
            images.portfolio4Gallery4,
            images.portfolio4Gallery5,
            images.portfolio4Gallery6
        ],
        teamLineup: [
            "Winning Team Members: Recognized for their contribution to the tournament victory",
            "Coaches & Support Staff: Honored for training and guidance",
            "Club Management: Coordinated the celebration and awards distribution",
            "Special Guests & Sponsors: Participated in event proceedings"
        ],
        eventHighlights: [
            "Trophy presentation and award ceremony",
            "Top performers of the tournament recognized",
            "Fan engagement activities and photo opportunities",
            "Speeches highlighting teamwork, dedication, and success",
            "Memorable celebration capturing the triumph of the club"
        ]
    },
    {
        id: 5,
        image: images.portfolio5,
        title: "Team Launch, CT-1",
        details: {
            eventDate: "Jan 5, 2024",
            category: "Champion Trophy",
            eventType: "Team Launch Ceremony",
            venue: "Main Stadium, Karachi",
            ticketPrice: "Free Entry / Online Streaming Available",
            eventLead: "Club Management & Team Captain",
            duration: "Half Day"
        },
        paragraphs: [
            "The Champion Trophy Team Launch, CT-1, marked the official introduction of the participating teams for the tournament. Players, coaches, and officials were formally presented to fans and media.",
            "The event included team introductions, speeches from club management, player interactions with supporters, and media coverage to build excitement ahead of the tournament matches."
        ],
        gallery: [
            images.portfolio5Gallery1,
            images.portfolio5Gallery2,
            images.portfolio5Gallery3,
            images.portfolio5Gallery4,
            images.portfolio5Gallery5,
            images.portfolio5Gallery6
        ],
        teamLineup: [
            "Team Players: Introduced to the fans and media",
            "Coaches & Support Staff: Presented alongside the team",
            "Club Management: Hosted the launch event",
            "Special Guests & Sponsors: Participated in presentations"
        ],
        eventHighlights: [
            "Formal introduction of all team members and coaching staff",
            "Speeches highlighting tournament goals and team strategy",
            "Fan engagement with player interactions and photos",
            "Media coverage to promote tournament excitement",
            "Setting the stage for the upcoming Champion Trophy matches"
        ]
    },
    {
        id: 6,
        image: images.portfolio6,
        title: "Final Pre-match Practice",
        details: {
            sessionDate: "Mar 20, 2024",
            category: "Premier League",
            sessionType: "Pre-Final Practice",
            venue: "Main Stadium & Practice Grounds, Karachi",
            ticketPrice: "Free / Online Streaming Optional",
            sessionLead: "Head Coach & Training Staff",
            duration: "Full Day"
        },
        paragraphs: [
            "The Final Pre-match Practice sessions were conducted to prepare the teams for the Premier League final. Focused drills, tactical simulations, and fitness exercises ensured players were match-ready.",
            "Coaches emphasized strategy, batting-bowling coordination, and fielding efficiency, while also addressing individual player strengths and areas for improvement."
        ],
        gallery: [
            images.portfolio6Gallery1,
            images.portfolio6Gallery2,
            images.portfolio6Gallery3,
            images.portfolio6Gallery4,
            images.portfolio6Gallery5,
            images.portfolio6Gallery6
        ],
        teamLineup: [
            "Openers & Top Order Batsmen: Sharpening timing and shot selection",
            "Middle Order & All-Rounders: Practicing both batting and bowling scenarios",
            "Bowlers: Perfecting line, length, pace, and spin variations",
            "Fielders: Enhancing agility, catching, and throwing accuracy",
            "Wicket-Keeper: Practicing reflexes, stumping, and coordination"
        ],
        eventHighlights: [
            "Focused net sessions improving batting and bowling skills",
            "Simulated match scenarios to refine strategy and teamwork",
            "Fielding and wicket-keeping drills enhancing defensive skills",
            "Individual performance tracked and coached for improvements",
            "Team fully prepared for Premier League final showdown"
        ]
    }

];

export default portfolio;