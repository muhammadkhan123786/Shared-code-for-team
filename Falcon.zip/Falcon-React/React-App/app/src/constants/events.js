const events = [ 
    {
        id: 1,
        teamA: 'United Falcon',
        teamB: 'Wolf Club',
        details: {
            league: 'International Champions Cup',
            matchNo: '3rd',
            date: 'Feb 21, 2024',
            time: '7:00 PM',
            venue: 'Aviva Stadium, Dublin', 
            umpires: 'James Anderson, Carlos Mendes',
            referee: 'Michael O’Connor',
            ticketPrice: '€60'
        },
        playingXI: {
            teamA: [1, 2, 3, 4, 5, 6, 7, 20, 8, 9, 10],
            teamB: [5, 4, 3, 2, 1, 6, 7, 20, 11, 10, 9],
        },
    },
    {
        id: 2,
        teamA: 'United Falcon',
        teamB: 'Tigers Club',
        details: {
            league: 'International Super League',
            matchNo: '4th',
            date: 'Feb 23, 2024',
            time: '7:30 PM',
            venue: 'Croke Park, Dublin',
            umpires: 'Richard Hall, Marco Silva',
            referee: 'Patrick Murphy',
            ticketPrice: '€65'
        },
        playingXI: {
            teamA: [2, 3, 4, 5, 6, 7, 13, 20, 9, 10, 11],
            teamB: [12, 13, 14, 15, 16, 17, 18, 20, 8, 9, 11],
        },
    },
    {
        id: 3,
        teamA: 'United Falcon',
        teamB: 'Eagle Club',
        details: {
            league: 'International Super League',
            matchNo: '5th',
            date: 'Feb 28, 2024',
            time: '2:30 PM',
            venue: 'Aviva Stadium, Dublin', 
            umpires: 'Richard Hall, Marco Silva',
            referee: 'Patrick Murphy',
            ticketPrice: '€65'
        },
        playingXI: {
            teamA: [3, 4, 5, 6, 7, 15, 20, 13, 10, 11, 8],
            teamB: [5, 4, 3, 2, 1, 6, 7, 20, 11, 10, 9], 
        },
    },
    {
        id: 4,
        teamA: 'United Falcon',
        teamB: 'Lions Club',
        details: {
            league: 'International Super League',
            matchNo: '6th',
            date: 'Mar 1, 2024',
            time: '7:30 PM',
            venue: 'Croke Park, Dublin',
            umpires: 'Richard Hall, Marco Silva',
            referee: 'Patrick Murphy',
            ticketPrice: '€65'
        },
        playingXI: {
            teamA: [4, 5, 6, 7, 1, 20, 13, 15, 11, 8, 9],
            teamB: [12, 15, 18, 16, 14, 13, 17, 20, 8, 9, 11], 
        },
    },
    {
        id: 5,
        teamA: 'United Falcon',
        teamB: 'Hawk Club',
        details: {
            league: 'International Super League',
            matchNo: '7th',
            date: 'Mar 2, 2024',
            time: '2:30 PM',
            venue: 'Aviva Stadium, Dublin', 
            umpires: 'Richard Hall, Marco Silva',
            referee: 'Patrick Murphy',
            ticketPrice: '€65'
        },
        playingXI: {
            teamA: [5, 6, 7, 1, 2, 13, 20, 15, 8, 9, 10],
            teamB: [1, 3, 5, 2, 4, 6, 20, 7, 8, 9, 10], 
        },
    },
    {
        id: 6,
        teamA: 'United Falcon',
        teamB: 'Wolf Club',
        details: {
            league: 'International Super League',
            matchNo: '8th',
            date: 'Mar 6, 2024',
            time: '7:30 PM',
            venue: 'Croke Park, Dublin',
            umpires: 'Richard Hall, Marco Silva',
            referee: 'Patrick Murphy',
            ticketPrice: '€65'
        },
        playingXI: {
            teamA: [6, 7, 1, 2, 3, 20, 13, 15, 9, 10, 11],
            teamB: [5, 4, 3, 2, 1, 6, 7, 20, 11, 10, 9],
        },
    },
    {
        id: 7,
        teamA: 'United Falcon',
        teamB: 'Tigers Club',
        details: {
            league: 'International Super League',
            matchNo: '9th',
            date: 'Mar 8, 2024',
            time: '2:30 PM',
            venue: 'Aviva Stadium, Dublin', 
            umpires: 'Richard Hall, Marco Silva',
            referee: 'Patrick Murphy',
            ticketPrice: '€65'
        },
        playingXI: {
            teamA: [7, 1, 2, 3, 4, 13, 20, 15, 10, 11, 8],
            teamB: [12, 14, 16, 18, 15, 13, 17, 20, 8, 11, 10], 
        },
    },
    {
        id: 8,
        teamA: 'United Falcon',
        teamB: 'Eagle Club',
        details: {
            league: 'International Super League',
            matchNo: '10th',
            date: 'Mar 12, 2024',
            time: '7:30 PM',
            venue: 'Croke Park, Dublin',
            umpires: 'Richard Hall, Marco Silva',
            referee: 'Patrick Murphy',
            ticketPrice: '€65'
        },
        playingXI: {
            teamA: [1, 2, 3, 4, 5, 20, 13, 15, 11, 8, 9],
            teamB: [2, 4, 6, 1, 3, 5, 20, 7, 9, 10, 11],
        },
    },
    {
        id: 9,
        teamA: 'United Falcon',
        teamB: 'Lions Club',
        details: {
            league: 'International Super League',
            matchNo: '11th',
            date: 'Mar 14, 2024',
            time: '2:30 PM',
            venue: 'Aviva Stadium, Dublin', 
            umpires: 'Richard Hall, Marco Silva',
            referee: 'Patrick Murphy',
            ticketPrice: '€65'
        },
        playingXI: {
            teamA: [2, 3, 4, 5, 6, 13, 20, 15, 8, 9, 10],
            teamB: [13, 15, 17, 12, 14, 16, 18, 20, 8, 9, 11],
        },
    },
    {
        id: 10,
        teamA: 'United Falcon',
        teamB: 'Hawk Club',
        details: {
            league: 'International Super League',
            matchNo: '12th',
            date: 'Mar 15, 2024',
            time: '7:30 PM',
            venue: 'Croke Park, Dublin',
            umpires: 'Richard Hall, Marco Silva',
            referee: 'Patrick Murphy',
            ticketPrice: '€65'
        },
        playingXI: {
            teamA: [3, 4, 5, 6, 7, 20, 13, 15, 9, 10, 11],
            teamB9: [1, 5, 3, 2, 4, 6, 7, 20, 10, 9, 11], 
        },
    }

];

export default events;