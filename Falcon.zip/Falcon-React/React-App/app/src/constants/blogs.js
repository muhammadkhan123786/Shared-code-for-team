import { images } from '../constants';

const blogs = [
  {
    id: 1,
    image: images.blog1,
    category: "Cricket Equipment",
    date: "23 Aug, 2025",
    admin: "Admin",
    heading: "Complete List of Cricket Equipment",
    content: "Explore the essential gear every cricketer needs to perform at their best.",
    important: {
      content: "From bats and balls to protective gear and team kits, discover a complete breakdown of cricket equipment used by both professionals and beginners.",
      intro: "Sports Analyst"
    },
    paragraph: {
      para1: "Cricket is a game that requires a wide range of equipment to ensure both performance and safety. Having the right gear not only enhances play but also reduces the risk of injury.",
      para2: "The most basic items include a cricket bat and ball, while protective equipment such as pads, gloves, and helmets are essential for player safety during matches.",
      para3: "In addition to individual gear, team equipment like jerseys, kits, and practice accessories play an important role in uniting the squad and building team spirit.",
      para4: "Whether you’re a beginner or an experienced player, understanding the function of each piece of cricket equipment is key to improving your overall game."
    },
    gallery: [
      images.blog1Gallery1,
      images.blog1Gallery2,
      images.blog1Gallery3,
      images.blog1Gallery4,
      images.blog1Gallery5,
      images.blog1Gallery6,
    ],
    tags: ["Cricket", "Equipment", "Training"],
    comments: [
      {
        id: 1,
        image: images.blog1Comment1,
        name: "David Johnson",
        date: "9 May, 2025",
        content: "Great overview of cricket gear! Very useful for beginners like me.",
        replies: [
          {
            id: 1,
            image: images.blog1Comment2,
            name: "Emma Wilson",
            date: "10 May, 2025",
            content: "Exactly! This helps me decide what to buy first for my practice sessions."
          }
        ]
      },
      {
        id: 2,
        image: images.blog1Comment3,
        name: "Liam Anderson",
        date: "11 May, 2025",
        content: "Detailed and well-written. Covers all the essentials clearly."
      }
    ]
  },
  {
    id: 2,
    image: images.blog2,
    category: "Club History",
    date: "15 Aug, 2025",
    admin: "Admin",
    heading: "A Brief History of United Falcon",
    content: "Discover the inspiring journey and legacy of the United Falcon cricket club.",
    important: {
      content: "From its humble beginnings to becoming a respected name in the cricket community, United Falcon’s story reflects passion, teamwork, and dedication to the sport.",
      intro: "Club Historian"
    },
    paragraph: {
      para1: "The United Falcon cricket club started with a group of passionate players aiming to build a team that represented unity, strength, and sportsmanship.",
      para2: "Over the years, the club participated in local and national tournaments, gradually establishing a reputation for discipline, skill, and teamwork.",
      para3: "United Falcon not only focused on winning matches but also on nurturing young talent, providing training opportunities, and promoting cricket at the grassroots level.",
      para4: "Today, the club stands as a symbol of perseverance and pride, inspiring new generations to embrace the sport with the same passion as its founders."
    },
    gallery: [
      images.blog2Gallery1,
      images.blog2Gallery2,
      images.blog2Gallery3,
      images.blog2Gallery4,
      images.blog2Gallery5,
      images.blog2Gallery6,
    ],
    tags: ["History", "Club", "Cricket"],
    comments: [
      {
        id: 1,
        image: images.blog2Comment1,
        name: "Sophia Harris",
        date: "16 April, 2025",
        content: "Loved learning about the roots of United Falcon. Truly inspiring!",
        replies: [
          {
            id: 1,
            image: images.blog2Comment2,
            name: "James Lee",
            date: "17 April, 2025",
            content: "Same here! It shows how far passion and teamwork can take a club."
          }
        ]
      },
      {
        id: 2,
        image: images.blog2Comment3,
        name: "Isabella Clark",
        date: "18 April, 2025",
        content: "Great read. Proud to support such a historic and dedicated cricket club."
      }
    ]
  },
  {
    id: 3,
    image: images.blog3,
    category: "Team Spirit",
    date: "4 Aug, 2025",
    admin: "Admin",
    heading: "We Are a Family, Not Just a Team",
    content: "Explore how unity, trust, and togetherness make our cricket team more than just teammates.",
    important: {
      content: "Behind every victory and challenge lies the bond of brotherhood. Our team thrives not only on skill but also on the strong relationships and trust that unite us as one family.",
      intro: "Team Captain"
    },
    paragraph: {
      para1: "In cricket, skill and strategy are essential, but the foundation of success is teamwork rooted in mutual respect and trust.",
      para2: "Our players share more than the pitch; they share experiences, values, and a spirit of camaraderie that creates a family-like environment.",
      para3: "This unity helps us overcome challenges, celebrate victories together, and support one another through setbacks.",
      para4: "Being more than a team means fostering lifelong bonds, inspiring future players, and showing that true strength lies in unity."
    },
    gallery: [
      images.blog3Gallery1,
      images.blog3Gallery2,
      images.blog3Gallery3,
      images.blog3Gallery4,
      images.blog3Gallery5,
      images.blog3Gallery6,
    ],
    tags: ["Team", "Club", "History"],
    comments: [
      {
        id: 1,
        image: images.blog3Comment1,
        name: "Liam Johnson",
        date: "26 April, 2025",
        content: "This resonates so much! A team built on trust is unstoppable.",
        replies: [
          {
            id: 1,
            image: images.blog3Comment2,
            name: "Emily Davis",
            date: "27 April, 2025",
            content: "Absolutely! Unity makes the game even more enjoyable and meaningful."
          }
        ]
      },
      {
        id: 2,
        image: images.blog3Comment3,
        name: "Mason Walker",
        date: "28 April, 2025",
        content: "Love this perspective. Cricket is more than just a sport—it's about family."
      }
    ]
  },
  {
    id: 4,
    image: images.blog4,
    category: "Coaching Guides",
    date: "29 July, 2025",
    admin: "Admin",
    heading: "Top 10 Best Batting Coaches in Cricket",
    content: "Discover the most influential batting coaches who have shaped the careers of world-class cricketers.",
    important: {
      content: "Batting coaches play a vital role in guiding players to refine their technique, boost confidence, and achieve success at the crease. Here are the top 10 coaches who have left a lasting impact on cricket.",
      intro: "Cricket Analyst"
    },
    paragraph: {
      para1: "Behind every successful batsman, there is often a great coach who provided mentorship and technical expertise.",
      para2: "From grassroots training to international arenas, these coaches help players develop skills that build consistency and resilience.",
      para3: "Their influence goes beyond technique, fostering mental strength and discipline required to face challenges on the pitch.",
      para4: "This list highlights the coaches who have produced champions, inspired teams, and contributed to the evolution of modern batting."
    },
    gallery: [
      images.blog4Gallery1,
      images.blog4Gallery2,
      images.blog4Gallery3,
      images.blog4Gallery4,
      images.blog4Gallery5,
      images.blog4Gallery6,
    ],
    tags: ["Coaches", "Cricket", "Training"],
    comments: [
      {
        id: 1,
        image: images.blog4Comment1,
        name: "Daniel Carter",
        date: "6 April, 2025",
        content: "Such an insightful list! Coaching really makes a difference in a player’s career.",
        replies: [
          {
            id: 1,
            image: images.blog4Comment2,
            name: "Sophia Miller",
            date: "7 April, 2025",
            content: "Absolutely! A good coach can transform an average batsman into a legend."
          }
        ]
      },
      {
        id: 2,
        image: images.blog4Comment3,
        name: "Ethan Wright",
        date: "8 April, 2025",
        content: "Great article. Would love to see a similar one on bowling coaches too!"
      }
    ]
  },
  {
    id: 5,
    image: images.blog5,
    category: "Training Tips",
    date: "21 July, 2025",
    admin: "Admin",
    heading: "How to Stay Motivated for Daily Training",
    content: "Discover effective ways to keep yourself motivated and consistent in your daily cricket training routine.",
    important: {
      content: "Consistency in training is the foundation of success in cricket. Staying motivated ensures improvement in skills, fitness, and mental toughness. Learn practical tips to maintain focus and discipline in your daily routine.",
      intro: "Fitness Coach"
    },
    paragraph: {
      para1: "Daily training can feel challenging, especially when motivation starts to fade. However, building strong habits can help maintain consistency.",
      para2: "Setting small, achievable goals is one of the most effective ways to stay on track and see continuous progress.",
      para3: "Finding a training partner or coach can also provide accountability and encouragement when motivation dips.",
      para4: "Celebrate small milestones along the way, as they boost confidence and reinforce the importance of staying committed to your training journey."
    },
    gallery: [
      images.blog5Gallery1,
      images.blog5Gallery2,
      images.blog5Gallery3,
      images.blog5Gallery4,
      images.blog5Gallery5,
      images.blog5Gallery6,
    ],
    tags: ["Training", "Team", "Cricket"],
    comments: [
      {
        id: 1,
        image: images.blog5Comment1,
        name: "Liam Johnson",
        date: "28 March, 2025",
        content: "This really inspired me to stick with my practice routine. Thank you!",
        replies: [
          {
            id: 1,
            image: images.blog5Comment2,
            name: "Emily Davis",
            date: "29 March, 2025",
            content: "Same here! These tips are practical and easy to apply every day."
          }
        ]
      },
      {
        id: 2,
        image: images.blog5Comment3,
        name: "James Walker",
        date: "30 March, 2025",
        content: "Motivation is always the hardest part. These strategies make it so much easier."
      }
    ]
  },
  {
    id: 6,
    image: images.blog6,
    category: "Club History",
    date: "12 July, 2025",
    admin: "Admin",
    heading: "New Cricket Season Schedule Released",
    content: "Stay updated with the latest cricket season schedule, including match dates, venues, and key tournaments.",
    important: {
      content: "The upcoming cricket season is packed with exciting tournaments, fixtures, and matches that fans won’t want to miss. From local competitions to international tours, the schedule is designed to bring non-stop action for cricket enthusiasts.",
      intro: "Tournament Committee"
    },
    paragraph: {
      para1: "The new season schedule has been officially released, featuring a series of thrilling matches across multiple venues.",
      para2: "Teams will compete in both domestic and international fixtures, providing fans with an action-packed calendar.",
      para3: "Special attention has been given to ensure balanced match days, player rest periods, and high-quality venues.",
      para4: "Fans can check our gallery for the complete match calendar, including dates, timings, and locations."
    },
    gallery: [
      images.blog6Gallery1,
      images.blog6Gallery2,
      images.blog6Gallery3,
      images.blog6Gallery4,
      images.blog6Gallery5,
      images.blog6Gallery6,
    ],
    tags: ["Schedule", "Team", "Cricket"],
    comments: [
      {
        id: 1,
        image: images.blog6Comment1,
        name: "Sophia Martinez",
        date: "9 May, 2025",
        content: "Can’t wait for the new season! The schedule looks amazing.",
        replies: [
          {
            id: 1,
            image: images.blog6Comment2,
            name: "Daniel Thompson",
            date: "10 May, 2025",
            content: "Same here! Some of the match-ups look really exciting."
          }
        ]
      },
      {
        id: 2,
        image: images.blog6Comment3,
        name: "William Harris",
        date: "11 May, 2025",
        content: "Great to finally see the dates. Time to book tickets!"
      }
    ]
  },
  {
    id: 7,
    image: images.blog7,
    category: "Cricket Equipment",
    date: "6 July, 2025",
    admin: "Admin",
    heading: "Comprehensive Guide to Cricket Gear",
    content: "Explore everything you need to know about cricket gear, from bats and balls to protective equipment.",
    important: {
      content: "Cricket requires specialized gear for performance and safety. This guide covers all essential equipment including bats, balls, pads, gloves, and helmets, ensuring players are well-prepared for every match.",
      intro: "Cricket Expert"
    },
    paragraph: {
      para1: "Cricket gear is designed not only to improve a player’s performance but also to provide maximum safety on the field.",
      para2: "Bats come in various weights and designs, allowing players to choose according to their playing style. Similarly, protective gear like pads and helmets are critical to ensure safety.",
      para3: "Choosing the right ball for practice or matches is also essential, as different formats use specific ball types.",
      para4: "Check our gallery for a detailed look at modern cricket gear and how professionals select their equipment."
    },
    gallery: [
      images.blog7Gallery1,
      images.blog7Gallery2
    ],
    tags: ["Equipment", "Cricket", "Training"],
    comments: [
      {
        id: 1,
        image: images.blog7Comment1,
        name: "Emma Johnson",
        date: "21 May, 2025",
        content: "This guide is very detailed! Perfect for beginners wanting to know about cricket gear.",
        replies: [
          {
            id: 1,
            image: images.blog7Comment2,
            name: "Liam Roberts",
            date: "22 May, 2025",
            content: "Absolutely! I learned a lot about which bat to pick for my style."
          }
        ]
      },
      {
        id: 2,
        image: images.blog7Comment3,
        name: "Noah Wilson",
        date: "23 May, 2025",
        content: "Really helpful breakdown. I finally understand the difference between gear for practice and matches."
      }
    ]
  },
  {
    id: 8,
    image: images.blog8,
    category: "Club History",
    date: "28 June, 2025",
    admin: "Admin",
    heading: "The History of United Falcon Club",
    content: "Discover the inspiring journey of the United Falcon Club and how it became a prominent cricket community.",
    important: {
      content: "From its humble beginnings to becoming a well-known cricket club, United Falcon has played a major role in shaping local cricket culture. This article highlights its achievements, struggles, and growth over the years.",
      intro: "Club Historian"
    },
    paragraph: {
      para1: "The United Falcon Club was founded with the aim of providing young players with opportunities to showcase their cricketing talent.",
      para2: "Over the decades, the club has produced several outstanding players who went on to represent at higher levels.",
      para3: "Despite facing challenges such as limited resources, the club’s determination and community support helped it flourish.",
      para4: "Today, United Falcon stands as a symbol of passion, dedication, and love for the game of cricket."
    },
    gallery: [
      images.blog8Gallery1,
      images.blog8Gallery2
    ],
    tags: ["History", "Club", "Cricket"],
    comments: [
      {
        id: 1,
        image: images.blog8Comment1,
        name: "Sophia Miller",
        date: "29 May, 2025",
        content: "Such an inspiring story! The United Falcon Club has truly shaped local cricket.",
        replies: [
          {
            id: 1,
            image: images.blog8Comment2,
            name: "James Anderson",
            date: "30 May, 2025",
            content: "Agreed! Their dedication to cricket development is remarkable."
          }
        ]
      },
      {
        id: 2,
        image: images.blog8Comment3,
        name: "Ethan Lewis",
        date: "31 May, 2025",
        content: "Proud to have been part of this club. The history reflects our hard work and love for the game."
      }
    ]
  },
  {
    id: 9,
    image: images.blog9,
    category: "Team Spirit",
    date: "12 June, 2025",
    admin: "Admin",
    heading: "More Than a Team, We’re Family",
    content: "Explore how the bond between players goes beyond cricket, creating a family-like atmosphere in the club.",
    important: {
      content: "The United Falcon players and staff share a connection that extends beyond the pitch. Discover how unity, trust, and support create a family spirit within the club.",
      intro: "Club Captain"
    },
    paragraph: {
      para1: "Cricket is not just about winning matches; it’s about building relationships that last a lifetime.",
      para2: "The United Falcon Club has always emphasized brotherhood and mutual respect among its members.",
      para3: "This family spirit helps players support each other during victories, defeats, and personal challenges.",
      para4: "The close-knit bond within the team has played a huge role in their consistent success on and off the field."
    },
    gallery: [
      images.blog9Gallery1,
      images.blog9Gallery2
    ],
    tags: ["Team", "Club", "History"],
    comments: [
      {
        id: 1,
        image: images.blog9Comment1,
        name: "Amelia Johnson",
        date: "11 June, 2025",
        content: "This really shows how important unity is in cricket teams.",
        replies: [
          {
            id: 1,
            image: images.blog9Comment2,
            name: "Liam Carter",
            date: "12 June, 2025",
            content: "Absolutely! A strong bond always reflects in team performance."
          }
        ]
      },
      {
        id: 2,
        image: images.blog9Comment3,
        name: "Noah Wilson",
        date: "13 June, 2025",
        content: "Proud to be part of a club where players are like family."
      }
    ]
  },
  {
    id: 10,
    image: images.blog10,
    category: "Coaching Guides",
    date: "2 June, 2025",
    admin: "Admin",
    heading: "Top 10 Cricket Batting Coaches",
    content: "A curated list of the best batting coaches who have shaped modern cricket with their expertise.",
    important: {
      content: "Batting coaches play a vital role in refining techniques, building confidence, and guiding players to excel on the pitch. Here’s our list of the top 10 batting coaches who have made a lasting impact in cricket.",
      intro: "Sports Analyst"
    },
    paragraph: {
      para1: "Batting is the backbone of cricket, and great coaches help players unlock their true potential.",
      para2: "From grassroots training to international stardom, batting coaches play an instrumental role in shaping careers.",
      para3: "This list highlights coaches who have worked with legendary cricketers and upcoming stars alike.",
      para4: "Their contributions continue to inspire the next generation of players to master the art of batting."
    },
    gallery: [
      images.blog10Gallery1,
      images.blog10Gallery2
    ],
    tags: ["Coaches", "Cricket", "Training"],
    comments: [
      {
        id: 1,
        image: images.blog10Comment1,
        name: "Sophia Taylor",
        date: "21 June, 2025",
        content: "Loved this breakdown! Some of my favorite coaches are on this list.",
        replies: [
          {
            id: 1,
            image: images.blog10Comment2,
            name: "James Anderson",
            date: "22 June, 2025",
            content: "Same here! Great to see how much they’ve contributed to cricket."
          }
        ]
      },
      {
        id: 2,
        image: images.blog10Comment3,
        name: "Ethan Miller",
        date: "23 June, 2025",
        content: "Would be great to also have a list of bowling coaches!"
      }
    ]
  }

];

export default blogs;