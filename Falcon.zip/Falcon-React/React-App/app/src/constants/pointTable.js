const cricketPointTable = [
  { 
    name: 'united falcon',
    stats: [5, 4, 1, '+0.328', 8],
  },
  {
    name: 'wolf club',
    stats: [5, 3, 2, '+1.049', 6], 
  },
  { 
    name: 'tigers club',
    stats: [5, 3, 2, '+0.299', 6],
  },
  {
    name: 'eagle club',
    stats: [5, 2, 3, '-0.727', 4],
  },
  {
    name: 'lions club',
    stats: [5, 2, 3, '-0.829', 4],
  },
  {
    name: 'hawk club',
    stats: [5, 1, 4, '-0.164', 2],
  },
];

export default cricketPointTable;
  