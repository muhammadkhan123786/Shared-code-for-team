export const payment = [
    {
        id: 1, 
        paymentID: 'cash-on-delivery',
        value: 'CASH',
        title: 'cash on delivery',
        content: 'Pay in cash when your order is delivered to your doorstep. Simply hand over the payment to the delivery person at the time of delivery.'
    },
    {
        id: 2,
        paymentID: 'card-on-delivery',
        value: 'CARD',
        title: 'card on delivery',
        content: 'Pay using your credit or debit card when your order is delivered. The delivery person will have a mobile card reader to process your payment securely.'
    },
    {
        id: 3,
        paymentID: 'mobile-wallet',
        value: 'MOBILE',
        title: 'mobile wallet payment',
        content: 'Pay via mobile wallet apps such as Google Pay, Paytm, or PhonePe at the time of delivery. Simply scan the QR code provided by the delivery person to make the payment.'
    },
];