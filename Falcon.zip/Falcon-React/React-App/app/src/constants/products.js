import { images } from '../constants';

const products = [
    {
        id: 1,
        image: images.product1Gallery1,
        name: "Running Shoes",
        price: 270.00,
        disprice: 260.00,
        stock: 9,
        content: "High-performance running shoes designed for comfort, durability, and speed.",
        description: "These running shoes feature lightweight materials, cushioned soles, and breathable fabric. Perfect for athletes, casual wear, and daily workouts.",
        category: ["Shoes Wear", "Sports Gear"],
        tags: ["Shoes", "Bag", "Jersey"],
        gallery: {
            image1: images.product1Gallery1,
            image2: images.product1Gallery2,
            image3: images.product1Gallery3, 
            image4: images.product1Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "Breathable Mesh & Rubber Sole" },
            { id: 2, title: "Size", content: "Available in 7 - 12" },
            { id: 3, title: "Color", content: "Black / White / Blue" }
        ],
        comments: [
            {
                id: 1,
                image: images.product1Review1,
                name: "David Smith",
                date: "August 5, 2025",
                rating: 4,
                content: "Comfortable shoes, great for running. Fits well and looks stylish."
            },
            {
                id: 2,
                image: images.product1Review2,
                name: "Emily Johnson",
                date: "August 12, 2025",
                rating: 5,
                content: "Excellent quality! Super lightweight and perfect for my daily jog."
            }
        ]
    },
    {
        id: 2,
        image: images.product2Gallery1,
        name: "Sports Cap",
        price: 290.00,
        disprice: 280.00,
        stock: 5,
        content: "A lightweight sports cap designed to keep you cool and comfortable during outdoor activities.",
        description: "This sports cap is crafted from breathable fabric with adjustable straps for a perfect fit. Ideal for workouts, casual wear, or sunny day outings.",
        category: ["Head Wear", "Sports Gear"],
        tags: ["Cap", "Hat", "Coat"],
        gallery: {
            image1: images.product2Gallery1,
            image2: images.product2Gallery2,
            image3: images.product2Gallery3, 
            image4: images.product2Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "Cotton Blend with Breathable Mesh" },
            { id: 2, title: "Size", content: "Adjustable Strap (One Size Fits All)" },
            { id: 3, title: "Color", content: "Black / White / Red" }
        ],
        comments: [
            {
                id: 1,
                image: images.product2Review1,
                name: "Ahmed Raza",
                date: "August 14, 2025",
                rating: 4.5,
                content: "Really good quality cap. Comfortable and fits perfectly!"
            }
        ]
    },
    {
        id: 3,
        image: images.product3Gallery1,
        name: "Cricket Ball",
        price: 310.00,
        disprice: 300.00,
        stock: 2,
        content: "Durable cricket ball designed for practice and professional matches.",
        description: "This cricket ball is crafted from high-quality leather with strong stitching to ensure durability and consistent performance. Suitable for both training sessions and competitive games.",
        category: ["Sports Gear", "Team Apparel"],
        tags: ["Ball", "Gloves", "Shoes"],
        gallery: {
            image1: images.product3Gallery1,
            image2: images.product3Gallery2,
            image3: images.product3Gallery3, 
            image4: images.product3Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "Genuine Leather with Cork Core" },
            { id: 2, title: "Weight", content: "156 grams (Standard)" },
            { id: 3, title: "Color", content: "Red" }
        ],
        comments: [
            {
                id: 1,
                image: images.product3Review1,
                name: "John Parker",
                date: "August 15, 2025",
                rating: 0,
                content: "Haven’t tried it yet, but it looks premium and feels solid in hand."
            }
        ]
    },
    {
        id: 4,
        image: images.product4Gallery1,
        name: "Team Jersey",
        price: 330.00,
        disprice: 320.00,
        stock: 0,
        content: "Lightweight and breathable team jersey designed for sports and casual wear.",
        description: "This team jersey is made from moisture-wicking fabric to keep players cool and dry. Featuring vibrant colors and durable stitching, it’s perfect for team matches, training, or fan gear.",
        category: ["Team Apparel", "Sports Gear"],
        tags: ["Jersey", "Cap", "Hoodie"],
        gallery: {
            image1: images.product4Gallery1,
            image2: images.product4Gallery2,
            image3: images.product4Gallery3, 
            image4: images.product4Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "100% Polyester (Moisture-Wicking)" },
            { id: 2, title: "Size", content: "S / M / L / XL / XXL" },
            { id: 3, title: "Color", content: "Blue / White / Custom Team Colors" }
        ],
        comments: [
            {
                id: 1,
                image: images.product4Review1,
                name: "Imran Malik",
                date: "August 16, 2025",
                rating: 5,
                content: "Amazing quality jersey. Super comfortable and perfect for matches."
            },
            {
                id: 2,
                image: images.product4Review2,
                name: "Sarah Ahmed",
                date: "August 17, 2025",
                rating: 4.9,
                content: "Loved it! The colors are vibrant and the fabric feels premium."
            }
        ]
    },
    {
        id: 5,
        image: images.product5Gallery1,
        name: "Sports Jacket",
        price: 350.00,
        disprice: 340.00,
        stock: 10,
        content: "A stylish sports jacket designed for warmth, comfort, and performance.",
        description: "This sports jacket is crafted with premium fabric, offering lightweight insulation and a sleek design. Perfect for training, outdoor activities, or casual wear during colder seasons.",
        category: ["Outer Wear", "Sports Gear"],
        tags: ["Jacket", "Hat", "Ball"],
        gallery: {
            image1: images.product5Gallery1,
            image2: images.product5Gallery2,
            image3: images.product5Gallery3, 
            image4: images.product5Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "Polyester Blend with Inner Lining" },
            { id: 2, title: "Size", content: "M / L / XL / XXL" },
            { id: 3, title: "Color", content: "Black / Grey / Navy" }
        ],
        comments: [
            {
                id: 1,
                image: images.product5Review1,
                name: "Hassan Ali",
                date: "August 17, 2025",
                rating: 0,
                content: "Haven’t worn it yet, but the jacket feels warm and well-made."
            }
        ]
    },
    {
        id: 6,
        image: images.product6Gallery1,
        name: "Sports Bag",
        price: 370.00,
        disprice: 360.00,
        stock: 6,
        content: "Durable and spacious sports bag designed for athletes and travelers.",
        description: "This sports bag features multiple compartments, strong zippers, and padded straps for comfort. Ideal for carrying sports gear, gym essentials, or travel items.",
        category: ["Sports Gear", "Outer Wear"],
        tags: ["Bag", "Shoes", "Gloves"],
        gallery: {
            image1: images.product6Gallery1,
            image2: images.product6Gallery2,
            image3: images.product6Gallery3, 
            image4: images.product6Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "Water-Resistant Polyester" },
            { id: 2, title: "Capacity", content: "40 Liters" },
            { id: 3, title: "Color", content: "Black / Red / Blue" }
        ],
        comments: [
            {
                id: 1,
                image: images.product6Review1,
                name: "Adeel Khan",
                date: "August 17, 2025",
                rating: 4.5,
                content: "Great bag with lots of space. Very sturdy and comfortable to carry."
            },
            {
                id: 2,
                image: images.product6Review2,
                name: "Maria Fatima",
                date: "August 17, 2025",
                rating: 4.5,
                content: "Perfect for gym and travel. Quality is excellent for the price."
            }
        ]
    },
    {
        id: 7,
        image: images.product7Gallery1,
        name: "Sports Hoodie",
        price: 390.00,
        disprice: 380.00,
        stock: 3,
        content: "A warm and comfortable hoodie, perfect for workouts and casual wear.",
        description: "This sports hoodie is made with soft fleece fabric and features a front pocket with an adjustable drawstring hood. Ideal for athletes, gym sessions, or everyday use during cooler weather.",
        category: ["Outer Wear", "Team Apparel"],
        tags: ["Hoodie", "Jacket", "Cap"],
        gallery: {
            image1: images.product7Gallery1,
            image2: images.product7Gallery2,
            image3: images.product7Gallery3, 
            image4: images.product7Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "Cotton-Polyester Blend with Fleece" },
            { id: 2, title: "Size", content: "S / M / L / XL / XXL" },
            { id: 3, title: "Color", content: "Grey / Black / Blue" }
        ],
        comments: [
            {
                id: 1,
                image: images.product7Review1,
                name: "Bilal Ahmed",
                date: "August 17, 2025",
                rating: 4,
                content: "Nice hoodie, very comfortable. Would have liked more color options."
            }
        ]
    },
    {
        id: 8,
        image: images.product8Gallery1,
        name: "Sports Gloves",
        price: 410.00,
        disprice: 400.00,
        stock: 0,
        content: "Durable sports gloves offering grip, comfort, and protection.",
        description: "These sports gloves are designed with breathable fabric and reinforced padding to enhance grip and protect hands during workouts, training, or outdoor activities. Suitable for fitness, cycling, and general sports use.",
        category: ["Sports Gear", "Outer Wear"],
        tags: ["Gloves", "Ball", "Coat"],
        gallery: {
            image1: images.product8Gallery1,
            image2: images.product8Gallery2,
            image3: images.product8Gallery3, 
            image4: images.product8Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "Breathable Mesh & Synthetic Leather" },
            { id: 2, title: "Size", content: "S / M / L / XL" },
            { id: 3, title: "Color", content: "Black / Red / Grey" }
        ],
        comments: [
            {
                id: 1,
                image: images.product8Review1,
                name: "Usman Tariq",
                date: "August 17, 2025",
                rating: 0,
                content: "Haven’t used them yet, but they look strong and comfortable."
            }
        ]
    },
    {
        id: 9,
        image: images.product9Gallery1,
        name: "Tennis Ball",
        price: 420.00,
        disprice: 410.00,
        stock: 10,
        content: "High-quality tennis ball designed for consistent bounce and durability.",
        description: "This tennis ball is crafted with premium felt and a durable rubber core, ensuring excellent performance on all court types. Suitable for both practice sessions and competitive matches.",
        category: ["Sports Gear", "Team Apparel"],
        tags: ["Ball", "Shoes", "Jersey"],
        gallery: {
            image1: images.product9Gallery1,
            image2: images.product9Gallery2,
            image3: images.product9Gallery3, 
            image4: images.product9Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "Premium Felt with Rubber Core" },
            { id: 2, title: "Weight", content: "58 grams (Standard)" },
            { id: 3, title: "Color", content: "Yellow" }
        ],
        comments: [
            {
                id: 1,
                image: images.product9Review1,
                name: "James Wilson",
                date: "August 17, 2025",
                rating: 4.4,
                content: "Great tennis ball! Bounces really well and lasts longer than others I’ve used."
            }
        ]
    },
    {
        id: 10,
        image: images.product10Gallery1,
        name: "Sports Footwear",
        price: 440.00,
        disprice: 430.00,
        stock: 20,
        content: "Comfortable and durable sports footwear built for performance and style.",
        description: "These sports shoes are designed with cushioned soles, breathable uppers, and durable outsoles. Perfect for running, training, or everyday wear with maximum comfort and grip.",
        category: ["Shoes Wear", "Sports Gear"],
        tags: ["Shoes", "Bag", "Hoodie"],
        gallery: {
            image1: images.product10Gallery1,
            image2: images.product10Gallery2,
            image3: images.product10Gallery3, 
            image4: images.product10Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "Mesh Upper with Rubber Sole" },
            { id: 2, title: "Size", content: "Available in 7 - 12" },
            { id: 3, title: "Color", content: "Black / White / Grey" }
        ],
        comments: [
            {
                id: 1,
                image: images.product10Review1,
                name: "Michael Brown",
                date: "August 17, 2025",
                rating: 5,
                content: "Super comfortable footwear! Great for both gym and casual wear."
            }
        ]
    },
    {
        id: 11,
        image: images.product11Gallery1,
        name: "Sports Hat",
        price: 290.00,
        disprice: 280.00,
        stock: 25,
        content: "Lightweight and breathable sports hat for outdoor activities and casual wear.",
        description: "This sports hat is made from quick-dry fabric with ventilation panels to keep you cool. It features an adjustable strap for a snug fit, making it ideal for workouts, running, or sunny day outings.",
        category: ["Head Wear", "Outer Wear"],
        tags: ["Ball", "Jacket", "Coat"],
        gallery: {
            image1: images.product11Gallery1,
            image2: images.product11Gallery2,
            image3: images.product11Gallery3, 
            image4: images.product11Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "Polyester with Breathable Mesh" },
            { id: 2, title: "Size", content: "Adjustable Strap (One Size Fits All)" },
            { id: 3, title: "Color", content: "Black / White / Blue" }
        ],
        comments: [
            {
                id: 1,
                image: images.product11Review1,
                name: "Zara Khan",
                date: "August 17, 2025",
                rating: 4.6,
                content: "Very comfortable and light. Perfect for my morning jogs!"
            }
        ]
    },
    {
        id: 12,
        image: images.product12Gallery1,
        name: "Professional Cricket Ball",
        price: 315.00,
        disprice: 305.00,
        stock: 28,
        content: "A professional-grade cricket ball offering durability and consistent bounce.",
        description: "Crafted from premium leather with a hand-stitched seam, this cricket ball provides excellent swing and spin. Perfect for both training sessions and professional-level matches.",
        category: ["Sports Gear", "Team Apparel"],
        tags: ["Ball", "Jacket", "Coat"],
        gallery: {
            image1: images.product12Gallery1,
            image2: images.product12Gallery2,
            image3: images.product12Gallery3, 
            image4: images.product12Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "Genuine Leather with Cork Core" },
            { id: 2, title: "Weight", content: "156 grams (Standard)" },
            { id: 3, title: "Color", content: "Red / White" }
        ],
        comments: [
            {
                id: 1,
                image: images.product12Review1,
                name: "Rahul Mehta",
                date: "August 18, 2025",
                rating: 4.8,
                content: "Excellent ball for league matches. Swings beautifully and lasts long."
            }
        ]
    },
    {
        id: 13,
        image: images.product13Gallery1,
        name: "Team Uniform",
        price: 335.00,
        disprice: 325.00,
        stock: 20,
        content: "Customizable team uniform designed for comfort, durability, and style.",
        description: "This team uniform is made from breathable, moisture-wicking fabric to keep players cool and comfortable. It can be customized with team colors, logos, and names—ideal for clubs, schools, and professional teams.",
        category: ["Team Apparel", "Sports Gear"],
        tags: ["Jersey", "Shoes", "Bag"],
        gallery: {
            image1: images.product13Gallery1,
            image2: images.product13Gallery2,
            image3: images.product13Gallery3, 
            image4: images.product13Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "100% Polyester (Moisture-Wicking)" },
            { id: 2, title: "Size", content: "S / M / L / XL / XXL" },
            { id: 3, title: "Color", content: "Custom Team Colors Available" }
        ],
        comments: [
            {
                id: 1,
                image: images.product13Review1,
                name: "Ali Hassan",
                date: "August 18, 2025",
                rating: 5,
                content: "Fantastic quality! Our whole team loved the design and comfort."
            },
            {
                id: 2,
                image: images.product13Review2,
                name: "Sofia Iqbal",
                date: "August 18, 2025",
                rating: 4.7,
                content: "The fabric is very breathable. Perfect for long matches."
            }
        ]
    },
    {
        id: 14,
        image: images.product14Gallery1,
        name: "Sports Coat",
        price: 355.00,
        disprice: 345.00,
        stock: 12,
        content: "A sleek and comfortable sports coat designed for casual and semi-formal wear.",
        description: "This sports coat is tailored with premium fabric, offering a balance of comfort and style. Ideal for casual outings, team events, or layering during colder seasons.",
        category: ["Outer Wear", "Team Apparel"],
        tags: ["Coat", "Hat", "Hoodie"],
        gallery: {
            image1: images.product14Gallery1,
            image2: images.product14Gallery2,
            image3: images.product14Gallery3, 
            image4: images.product14Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "Polyester Blend with Inner Lining" },
            { id: 2, title: "Size", content: "M / L / XL / XXL" },
            { id: 3, title: "Color", content: "Black / Grey / Navy" }
        ],
        comments: [
            {
                id: 1,
                image: images.product14Review1,
                name: "Omar Farooq",
                date: "August 18, 2025",
                rating: 4.6,
                content: "Very stylish coat. Fits perfectly and feels premium."
            }
        ]
    },
    {
        id: 15,
        image: images.product15Gallery1,
        name: "Sports Backpack",
        price: 375.00,
        disprice: 365.00,
        stock: 18,
        content: "A durable and spacious backpack designed for sports, travel, and daily use.",
        description: "This sports backpack offers multiple compartments, padded shoulder straps, and water-resistant fabric. Perfect for carrying gym gear, books, or travel essentials with comfort and style.",
        category: ["Sports Gear", "Outer Wear"],
        tags: ["Bag", "Gloves", "Jacket"],
        gallery: {
            image1: images.product15Gallery1,
            image2: images.product15Gallery2,
            image3: images.product15Gallery3, 
            image4: images.product15Gallery4,
        },
        addInfo: [
            { id: 1, title: "Material", content: "Water-Resistant Polyester" },
            { id: 2, title: "Capacity", content: "35 Liters" },
            { id: 3, title: "Color", content: "Black / Blue / Grey" }
        ],
        comments: [
            {
                id: 1,
                image: images.product15Review1,
                name: "Nadia Karim",
                date: "August 18, 2025",
                rating: 4.5,
                content: "Great backpack! Very spacious and comfortable to carry."
            },
            {
                id: 2,
                image: images.product15Review2,
                name: "Salman Yousuf",
                date: "August 18, 2025",
                rating: 4.8,
                content: "Strong zippers and quality fabric. Ideal for my gym and weekend trips."
            }
        ]
    },

];

export default products;