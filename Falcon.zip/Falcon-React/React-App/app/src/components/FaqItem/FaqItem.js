import React from 'react';
import './FaqItem.css';

// Importing the plus and minus icons from react-icons
import { FaPlus, FaMinus } from 'react-icons/fa';



const FaqItem = (props) => {

  // Destructuring props to extract id, title, content, isActive, and onAccordionClick
  const { id, title, content, isActive, onAccordionClick } = props;

  return (

    // Main accordion container that conditionally applies 'active' class based on isActive
    <div className={`accordion ${isActive ? 'active' : ''}`}>

      {/* Accordion heading: This section is clickable to toggle the content visibility */}
      <div className='accordion-heading' onClick={() => onAccordionClick(id)}>
        <h3>{title}</h3> {/* Title of the accordion item */}
        <div className='icon'>{isActive ? <FaMinus /> : <FaPlus />}</div> {/* Icon changes based on whether the section is active or not */}
      </div>

      {/* Accordion content: Only visible when 'isActive' is true */}
      {isActive && <div className='accordion-content'>{content}</div>}

    </div>

  );
};

export default FaqItem;