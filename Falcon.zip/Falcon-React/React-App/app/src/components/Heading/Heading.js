import React from 'react';
import './Heading.css';



const Heading = ({ title, subTitle = '', sideHeading = false, linear = false }) => {

  return (
    <div className={`heading ${sideHeading ? 'sideheading' : ''} ${linear ? 'linear-bg' : ''}`}>

      {/* Render the subTitle section only if subTitle is provided */}
      {subTitle && (
        <div className="sub">

          {/* Display the subtitle text */}
          <span>{subTitle}</span>

        </div>
      )}

      <h2>{title}</h2> {/* Display the title */}

    </div>
  );
};

export default Heading;