import React from 'react';
import './PortfolioItem.css';

import { FaLink, FaPlus } from 'react-icons/fa';
import { Link } from 'react-router-dom';

// Import PhotoView from react-photo-view
import { PhotoView } from 'react-photo-view';



const PortfolioItem = (props) => {

  // Destructuring props
  const { id, image, title, category, portfolio, className } = props;

  return (
    <div className={`portfolio-item ${className}`} key={id}>
      <div className="portfolio-content">

        {/* Portfolio Image */}
        <img src={image} alt={title} />

        {/* Portfolio Content */}
        <div className='content'>

          <div className='btn-container'>
            {/* Link to the individual Portfolio Detail Page */}
            <Link
              to={{
                pathname: '/Portfolio/' + title,
              }}
              state={portfolio}
            >
              <div className='icon'><FaLink /></div>
            </Link>

            {/* Plus icon for lightbox */}
            <PhotoView src={image}>
                <div className='icon'><FaPlus /></div>
            </PhotoView>
          </div>

          <div className='text'>

            {/* Portfolio Category */}
            <p><span></span>{category}</p>

            {/* Link to the individual Portfolio Detail Page */}
            <Link
              to={{
                pathname: '/Portfolio/' + title,
              }}
              state={portfolio}
            >
              <h3>{title}</h3> {/* Portfolio Title */}
            </Link>

          </div>

        </div>

      </div>
    </div>
  );
};

export default PortfolioItem;