import React from 'react';
import './TeamSquad.css';

import { cricketTeams } from '../../constants';
import { getItemsByIds, getTeamLogo } from '../../utils';



const TeamSquad = (props) => {

  // Destructuring props
  const { teamName, teamSquad } = props;

  // Find the team in cricketTeams to get its players
  const team = cricketTeams.find(team => 
    team.name.toLowerCase() === teamName.toLowerCase()
  );

  // Get players from the specific team
  const teamPlayers = team ? getItemsByIds(teamSquad, team.players) : [];

  return (
    <div className='team-squad'>

      <div className='title'>
        <img src={getTeamLogo(teamName)} alt='Event' /> {/* Team Logo */}
        <h5>{teamName}</h5> {/* Team name */}
      </div>

      <div className='box-container'>

        {/* Column headers for the squad */}
        <div className='sub-heading'>
          <h3>#</h3>
          <h3>player</h3>
          <h3>playing role</h3>
        </div>

        {/* Squad Details */}
        <div className='squad-content'>
          {/* Render each player in the squad */}
          {teamPlayers.map((player, index) => {
            return(
              <div className='squad-item' key={player.id}>
                <h3>{index+1}</h3> {/* Player number (position in squad) */}
                <h3>{player.name}</h3> {/* Player name */}
                <p>{player.role}</p> {/* Player playing role */}
              </div>
            )
          })}
        </div>
      </div>
    </div>
  );
}

export default TeamSquad;