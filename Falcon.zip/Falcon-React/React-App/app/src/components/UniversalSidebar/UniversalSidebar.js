import React, { useState } from 'react';
import './UniversalSidebar.css'; 

import { SidebarHeading, PriceFilter, Product } from '../../components';
import { blogContent, productsContent } from '../../constants';
import { getPopular, latestItems } from '../../utils';

import { BsSearch } from 'react-icons/bs';
import { BiCricketBall } from 'react-icons/bi';

import { Link } from 'react-router-dom';



const UniversalSidebar = ({
  type, // 'shop' or 'blog'
  priceRange,
  setPriceRange,
  selectedCategory,
  selectedTag,
  handleSubmit,
}) => {

  // State for search input value
  const [searchValue, setSearchValue] = useState('');



  /*--------------- 1-Search ---------------*/

  // Handles search input changes.
  const handleSearchChange = (e) => {
    setSearchValue(e.target.value);
  };

  // Handles search form submission.
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchValue.trim()) {
      handleSubmit(searchValue.trim(), type);  // Type can be 'blogs', 'products', or 'cars'
      setSearchValue('');
    }
  };



  /*--------------- 2-Categories Titles ---------------*/

  // Object to store category quantities for shop and blog
  const categoryQuantities = {
    shop: {},
    blog: {},
  };

  // Extract categories from blogContent
  for (const blog of blogContent) { 
    const category = blog.category.toLowerCase();
    categoryQuantities.blog[category] = (categoryQuantities.blog[category] || 0) + 1;
  }

  // Extract categories from productsContent
  productsContent.forEach(product => {
    product.category.forEach(category => { // Ensures handling of multiple categories
      const categoryName = category.toLowerCase();
      categoryQuantities.shop[categoryName] = (categoryQuantities.shop[categoryName] || 0) + 1;
    });
  });

  // Create combined categories array based on type
  const categories = (type === 'shop'
      ? ['all', ...Object.keys(categoryQuantities.shop)] // Include "all" in shop categories
      : Object.keys(categoryQuantities.blog) // Blog categories only
  ).map(category => ({
      name: category,
      quantity: category === 'all' ? productsContent.length : categoryQuantities[type][category] || 0,
  }));



  /*--------------- 3-Recent Blogs & Popular Products ---------------*/

  // Get the latest blogs
  const blogs = latestItems(blogContent);

  // Get the top 3 popular products
  const popularProducts = getPopular(productsContent);
  const topProducts = popularProducts.slice(0, 3);



  /*--------------- 4-Tag Titles ---------------*/
  // Extract unique tags from blogContent
  const tagTitles = [];
  for (const blog of blogContent) {
      const tags = blog.tags;
      for (const tag of tags) {
          const formattedTag = tag.toLowerCase(); // Convert tag name to lowercase
          if (!tagTitles.includes(formattedTag)) {
              tagTitles.push(formattedTag);
          }
      }
  }


  return (
    <div className={`sidebar ${type}-sidebar`}>

      {/* Search Section */}
      <div className='search sidebar-item'>
        <SidebarHeading title='search' />
        <div className='box-container'>
          <form onSubmit={handleSearchSubmit}>
            <div className='input-box'>
              <input
                type='text'
                id='search'
                placeholder={`Search ${type}...`}
                value={searchValue}
                onChange={handleSearchChange}
                required
              />
              <button type='submit'><BsSearch /></button>
            </div>
          </form>
        </div>
      </div>


      {/* Categories Section */}
      {categories && (
      <div className='category sidebar-item'>
        {/* Sidebar Heading */}
        <SidebarHeading title='categories' />
        <div className='box-container'>
          {/* Loop through categories based on type (shop/blog) */}
          {categories.map((category, index) => (
            <Link
              className={`item ${category.name.toLowerCase() === selectedCategory.toLowerCase() ? 'active' : ''}`}
              key={index}
              to={`/${type === 'shop' ? 'Shop' : 'Blogs'}/category/${category.name}`}
            >
              <span><BiCricketBall className='icon' /> {category.name}</span>
              <p>({category.quantity})</p>
            </Link>
          ))}
        </div>
      </div>

      )}


      {/* Shop-specific Price Filter */}
      {type === 'shop' && priceRange && (
        <div className='filter sidebar-item'>
          <SidebarHeading title='price filter' />
          <PriceFilter priceRange={priceRange} setPriceRange={setPriceRange} />
        </div>
      )}


      {/* Content Section */}
      <div className={`${type === 'shop' ? 'popular' : 'recent-post'} sidebar-item`}>
        <SidebarHeading title={type === 'shop' ? 'popular products' : 'recent posts'} />
        <div className='box-container'>
          {(type === 'shop' ? topProducts : blogs)?.map((item) => (
            type === 'shop' ? (
            <Product key={item.id} product={item} />
            ) : (
              <div className='post-item' key={item.id}> 
                <img src={item.image} alt={item.heading} />
                <div className='content'>
                  <Link
                    to={`/Blogs/${item.heading}`}
                    state={item}
                    className='main-heading'
                  >
                    {item.heading}
                  </Link>
                </div>
              </div>
            )
          ))}
        </div>
      </div>


      {/* Blog-specific Tags */}
      {type === 'blog' && tagTitles && (
        <div className='tags sidebar-item'>
          <SidebarHeading title='tags' />
          <div className='box-container'>
            {tagTitles.map((tag, index) => (
              <Link
                className={`tag-item ${tag.toLowerCase() === selectedTag?.toLowerCase() ? 'active' : ''}`}
                key={index}
                to={`/Blogs/tag/${tag}`}
              >
                {tag}
              </Link>
            ))}
          </div>
        </div>
      )}


    </div>

  );
};

export default UniversalSidebar;