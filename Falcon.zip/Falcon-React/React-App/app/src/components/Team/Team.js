import React, { useState, useRef } from 'react';
import './Team.css';

import { coaches, players } from '../../constants';
import { Heading, TeamItem } from '../../components';

import { FaUserTie } from 'react-icons/fa';
import { FaBaseball, FaBaseballBatBall, FaPersonWalkingWithCane } from 'react-icons/fa6';



const Team = ({ showCoaches = true }) => {

  // Use the imported data
  const [playersData] = useState(players);
  const [coachesData] = useState(coaches);

  // Refs for each section
  const batterRef = useRef(null);
  const allrounderRef = useRef(null);
  const bowlerRef = useRef(null);
  const coachesRef = useRef(null);

  // Function to scroll to a section
  const scrollToSection = (ref) => {
    if (ref && ref.current) {
      ref.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  // Group players by type
  const groupedPlayers = {
    batter: playersData.filter(player => player.type === 'batter'),
    allrounder: playersData.filter(player => player.type === 'allrounder'),
    bowler: playersData.filter(player => player.type === 'bowler')
  };

  return (
    <section className="team">

      {/* Section heading */}
      <Heading title={showCoaches ? "Our Team" : "Our Players"} subTitle={showCoaches ? "Players & Coaches" : "Team squad"} />

      <div className="tab-buttons">
        <button 
          className="btn"
          onClick={() => scrollToSection(batterRef)}
        >
          batter
        </button>
        <button 
          className="btn"
          onClick={() => scrollToSection(allrounderRef)}
        >
          allrounder
        </button>
        <button 
          className="btn"
          onClick={() => scrollToSection(bowlerRef)}
        >
          bowler
        </button>
        {showCoaches && (
          <button 
            className="btn"
            onClick={() => scrollToSection(coachesRef)}
          >
            coaches
          </button>
        )}
      </div>

      <div className="team-container">

        {/* Batters Section */}
        <div ref={batterRef} className="team-section">
          <div className="team-heading">
            <div className='icon'><FaPersonWalkingWithCane /></div>
            <h3>batter</h3>
          </div>
          <div className="box-container">
            {groupedPlayers.batter.map(player => (
              <TeamItem key={player.id} team={player} />
            ))}
          </div>
        </div>

        {/* All Rounders Section */}
        <div ref={allrounderRef} className="team-section">
          <div className="team-heading">
            <div className='icon'><FaBaseballBatBall /></div>
            <h3>All Rounder</h3>
          </div>
          <div className="box-container">
            {groupedPlayers.allrounder.map(player => (
              <TeamItem key={player.id} team={player} />
            ))}
          </div>
        </div>

        {/* Bowlers Section */}
        <div ref={bowlerRef} className="team-section">
          <div className="team-heading">
            <div className='icon'><FaBaseball /></div>
            <h3>bowler</h3>
          </div>
          <div className="box-container">
            {groupedPlayers.bowler.map(player => (
              <TeamItem key={player.id} team={player} />
            ))}
          </div>
        </div>

        {/* Conditionally Render Coaches Section */}
        {showCoaches && (
          <div ref={coachesRef} className="team-section">
            <div className="team-heading">
              <div className='icon'><FaUserTie /></div>
              <h3>Team coaches</h3>
            </div>
            <div className="box-container">
              {coachesData.map(coach => (
                <TeamItem key={coach.id} team={coach} type='coaches' />
              ))}
            </div>
          </div>

        )}
      </div>
    </section>
  );
};

export default Team;