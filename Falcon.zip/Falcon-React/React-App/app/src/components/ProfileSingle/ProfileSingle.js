import React from 'react';

import { PageTitle, ProfileDetails } from '../../components';

import { useLocation } from 'react-router-dom';



const ProfileSingle = ({ type, profile: propProfile }) => {
  
  const location = useLocation();
  const profile = propProfile || location.state; // Use propProfile if provided, otherwise get from route state

  if (!profile) return null; // Prevent errors if no profile is available

  const isCoach = type === 'coach';

  return (

    <>

      {/* Page title */}
      <PageTitle title={profile.name} page={isCoach ? 'Coach Single' : 'Player Single'} />

      <section>
        <ProfileDetails profile={profile} isCoach={isCoach} />
      </section>

    </>

  );
}

export default ProfileSingle;