import React from 'react';
import './Comments.css';

import { Comment } from '../../components';
import { countCommentsAndReplies } from '../../utils';



const Comments = ({ comments, showReplyIcon }) => {
   
  // Initializing the totalComments variable
  let totalComments = 0;

  // Checking if comments exist
  if (comments) {

    // Calling the countCommentsAndReplies function to count the comments and replies
    totalComments = countCommentsAndReplies(comments);
  }

  return (
    
    <div className='comments'>

      {/* Display the total number of comments */}
      {comments.length > 0 ? (
        <h4>{totalComments} {comments.length > 1 ? 'Comments' : 'Comment'}</h4>
      ) : null}

      <div className='box-container'>
        
        {/* Render each comment */}
        {comments.map((comment) => {
          return (
            <div className='main' key={comment.id}>
              {/* Render the main comment */}
              <Comment comment={comment} reply={showReplyIcon} />

              {/* Render the replies to the main comment */}
              {comment.replies &&
                comment.replies.map((replyComment) => {
                  return (
                    <div className='replies' key={comment.id}>
                      <Comment comment={replyComment} reply={showReplyIcon} />
                    </div>
                  );
                })}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Comments;