import React from 'react';
import './Product.css';

import { calculateAverageRating, useCart, useWishlist } from '../../utils';

import { FaStar } from 'react-icons/fa';
import { BsCartPlusFill, BsHeart, BsEye, BsCartXFill } from 'react-icons/bs';

import { Link } from 'react-router-dom';


 
const Product = ({ product, list }) => {

  // Destructuring product properties
  const { image, content, name, disprice, price} = product;

  // Calculate the average rating for the product
  const averageRating = calculateAverageRating(product);

  // Access cart and wishlist functions
  const { addToCart } = useCart();
  const { addToWishlist } = useWishlist();

  return ( 

    <div className='product-item'>

      <div className='image'>

        <div className='options'>

          {/* Add to Cart Button - Handles stock availability */}
          <Link
            to={product.stock ? "/cart" : "#"}
            onClick={(e) => {
              if (product.stock) {
                addToCart(product);
              } else {
                e.preventDefault();
                alert("This product is out of stock!");
              }
            }}
            data-tooltip={product.stock ? "Add to Cart" : "Out of Stock"}
          >
            {product.stock ? <BsCartPlusFill /> : <BsCartXFill />}
          </Link>

          {/* Add to Wishlist Button */}
          <Link to='/wishlist' onClick={() => addToWishlist(product)} data-tooltip="Add to Wishlist">
            <BsHeart />
          </Link>

          {/* View Product Details Button */}
          <Link to={`/Shop/${name}`} state={product} data-tooltip="View Details">
            <BsEye />
          </Link>

        </div>
  
        <img src={image} alt={name} /> {/* Product image */}

      </div>
 
      <div className='content'>

        {/* Product Name Link */}
        <Link
          to={{
            pathname: '/Shop/' + name,
          }}
          location={{ product }}
          state={product}><h3>{name}</h3> {/* Product name */}
        </Link> 

        {/* Star rating */}
        <div className='rating'>
          <div className='icon'>
            <FaStar /> <FaStar /> <FaStar /> <FaStar /> <FaStar />
          </div>
          {/* Display average rating and number of comments */}
          {product.comments.length > 0 ? (
            <h5> {averageRating} ({product.comments.length}) </h5>
          ) : (
            <h5>Not rated</h5>
          )}
        </div>

        {/* Product Description (conditionally rendered) */}
        {list && <p>{content}</p>} 

        {/* Discounted price and original price */}
        <div className='price'>
          <p>${disprice} <span>${price}</span></p>
        </div>

      </div>

    </div>
  );
};

export default Product;