import React from 'react';
import './PageSidebar.css';

import { Button } from '../../components';
import { renderIcon } from '../../utils';



const PageSidebar = (props) => {

  // Destructure props, including the optional button prop
  const { heading, details, button } = props;

  return (
    <div className='page-sidebar'>

      {/* Display the main heading of the sidebar */}
      <h3 className="sub-heading">{heading} Info</h3>

      <div className="container">

        {/* Iterate over details object and render each key-value pair */}
        {Object.entries(details).map(([key, value]) => (

          <div className='detail-item' key={key}>

            {/* Render an icon for each detail item */}
            <div className='icon'>{renderIcon(key)}</div>

            <div className="detail-content">
              {/* Display the key with proper formatting (insert spaces and capitalize) */}
              <h3>{key.replace(/([A-Z])/g, " $1").replace(/^./, (str) => str.toUpperCase())}</h3>
              {/* Display the corresponding value for each detail */}
              <p>{value}</p>
            </div>

          </div>
        ))}

      </div>

      {/* Conditionally render Button if button prop exists */}
      {button && (
        <Button link={button.link} title={button.title} />
      )}

    </div>
  );
};

export default PageSidebar;