import React from "react";
import './StockMessage.css';



const StockMessage = ({ stock }) => {

  let message = ""; // Initialize message variable

  // Set message based on stock quantity
  if (stock === 0) {
    message = "Out of stock"; // No stock available
  } else if (stock <= 3) {
    message = `Hurry! Only ${stock} left in stock!`; // Very low stock
  } else if (stock <= 5) {
    message = `Only ${stock} left – order soon!`; // Low stock
  } else if (stock <= 10) {
    message = "Limited stock available!"; // Moderate stock
  }

  return (
    <div className="stock-message">
      {message && <p>{message}</p>} {/* Display message only if it exists */}
    </div>
  );
};

export default StockMessage;