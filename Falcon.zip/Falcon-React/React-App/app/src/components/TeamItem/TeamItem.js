import React from 'react';
import './TeamItem.css';

import { FaFacebookF, FaInstagram, FaLinkedin } from 'react-icons/fa';
import { FaXTwitter } from 'react-icons/fa6';

import { Link } from 'react-router-dom';



const TeamItem = ({ team, type = 'player' }) => {

    // Destructuring props
    const { id, image, name, role, accounts } = team;

    // Determine the base path based on the type
    const basePath = type === 'coaches' ? '/Coaches/' : '/Players/';

    return (

        <div className='team-item' key={id}>

            <div className='team-image'>

                <img src={image} alt={name} /> {/* Team member Picture */}

                {/* Social media icons */}
                <div className='icon-container'>
                    <a className='icon' href={accounts.facebook}><FaFacebookF /></a>
                    <a className='icon' href={accounts.linkedin}><FaLinkedin /></a>
                    <a className='icon' href={accounts.twitter}><FaXTwitter /></a>
                    <a className='icon' href={accounts.instagram}><FaInstagram /></a>
                </div>

            </div>

            <div className='team-content'>

                <Link
                    to={{
                        pathname: basePath + name, // Dynamic path based on type
                    }}
                    state={team}>
                    <h3>{name}</h3> {/* Team member name */}
                </Link>

                <h5>{role}</h5> {/* Team member role */}

            </div>

        </div>
    );
}

export default TeamItem;