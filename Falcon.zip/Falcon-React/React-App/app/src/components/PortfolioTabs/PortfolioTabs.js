import React from "react";
import "./PortfolioTabs.css";



const PortfolioTabs = ({ id, title, active, setSelected }) => {

  return (
    <li
      key={id}
      className={active ? "button active" : "button"}
      onClick={() => setSelected(id)}
    >
      {title} {/* Portfolio Tab title */}
    </li>
  );

};

export default PortfolioTabs;