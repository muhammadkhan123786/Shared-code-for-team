import React, { useState } from 'react';

import { FaqItem } from '../../components';



const Faqs = ({ faqs }) => { 

  // Setting the initial active accordion ID to the first FAQ item or null if empty
  const [activeAccordionId, setActiveAccordionId] = useState(faqs[0]?.id || null);

  // Function to handle accordion toggle
  const handleAccordionClick = (id) => {
    setActiveAccordionId((prevId) => (prevId === id ? null : id));
  };

  return (
    <div className='faq'>
      <div className='accordion-container'>
        {faqs.map((faq) => (
          <FaqItem
            key={faq.id} // Unique key for each FAQ item
            id={faq.id} // Passing ID to FaqItem
            title={faq.heading} // Passing FAQ heading
            content={faq.content} // Passing FAQ content
            isActive={faq.id === activeAccordionId} // Checking if the item is active
            onAccordionClick={handleAccordionClick} // Handling click event
          />
        ))}
      </div>
    </div>
  );
};

export default Faqs;