import React from 'react';
import './ProfileDetails.css';

import { SidebarHeading } from '../../components';

import { FaFacebookF, FaInstagram, FaLinkedin, FaBriefcase, FaBaseballBall, FaUserTie, FaUsers, FaCertificate, FaCalendarAlt, FaGlobe, FaRulerVertical, FaWeight } from 'react-icons/fa';
import { FaXTwitter } from 'react-icons/fa6';
import { BiSolidCricketBall } from 'react-icons/bi';



const ProfileDetails = ({ profile, isCoach }) => {

  // Extract relevant sections from the profile object
  const { accounts, personalInfo, battingStats, bowlingStats } = profile;

  // Define halved stats first
  // 🔹 Function to split any stats object
  const splitStats = (stats) => {
    const entries = Object.entries(stats);
    const mid = Math.ceil(entries.length / 2);

    return {
      firstHalf: Object.fromEntries(entries.slice(0, mid)),
      secondHalf: Object.fromEntries(entries.slice(mid))
    };
  };

  // Only prepare stats if not a coach
  const { firstHalf: firstHalfBatting, secondHalf: secondHalfBatting } =
    !isCoach ? splitStats(battingStats) : { firstHalf: {}, secondHalf: {} };

  const { firstHalf: firstHalfBowling, secondHalf: secondHalfBowling } =
    !isCoach ? splitStats(bowlingStats) : { firstHalf: {}, secondHalf: {} };

  /* Utility function for formatting keys */
  const formatLabel = (key) => {
    return key
      .replace(/([A-Z])/g, " $1")   // Add space before capital letters
      .replace(/^./, (str) => str.toUpperCase()); // Capitalize first letter
  };

  return (

    <>

      <div className={`${isCoach ? 'coach-single' : 'team-single'} profile-single`}>

        {/* Profile Introduction */}
        <div className='profile-intro'>

          {/* Profile Image */}
          <div className='profile-image'>

            <img src={profile.image} alt={profile.name} />

            <div className='intro-text'>

              <h3>{profile.name}</h3> {/* Profile Name */}
              <h5>{profile.role}</h5> {/* Profile Title */}

              {/* Social media icons */}
            <div className='icon-container'>
              <a className='icon' href={accounts.facebook}><FaFacebookF /></a> {/* Facebook Icon */}
              <a className='icon' href={accounts.linkedin}><FaLinkedin /></a> {/* LinkedIn Icon */}
              <a className='icon' href={accounts.twitter}><FaXTwitter /></a> {/* Twitter Icon */}
              <a className='icon' href={accounts.instagram}><FaInstagram /></a> {/* Instagram Icon */}
            </div>

            </div>
          </div>

          {/* Profile Details */}
          <div className='information'>

            {/* Profile About */}
            <div className='profile-about'>
              <div className='text'>{profile.biography}</div> {/* Profile Biography */}
            </div>

            <ul className="profile-personal-info info-item">

              <SidebarHeading title='Personal Information' />
              {/* Date of Birth - Show for both */}
              {personalInfo.dateOfBirth && (
                <li> 
                  <div className='title'>
                    <div className='icon'><FaCalendarAlt /></div>
                    <h6>Date of Birth:</h6>
                  </div> 
                  <span>{personalInfo.dateOfBirth}</span>
                </li>
              )}
              
              {/* Nationality - Show for both */}
              {personalInfo.nationality && (
                <li> 
                  <div className='title'>
                    <div className='icon'><FaGlobe /></div>
                    <h6>Nationality:</h6>
                  </div> 
                  <span>{personalInfo.nationality}</span>
                </li>
              )}
              
              {/* Height - Show for both */}
              {personalInfo.height && (
                <li> 
                  <div className='title'>
                    <div className='icon'><FaRulerVertical /></div>
                    <h6>Height:</h6>
                  </div> 
                  <span>{personalInfo.height}</span>
                </li>
              )}
              
              {/* Weight - Show for both */}
              {personalInfo.weight && (
                <li> 
                  <div className='title'>
                    <div className='icon'><FaWeight /></div>
                    <h6>Weight:</h6>
                  </div> 
                  <span>{personalInfo.weight}</span>
                </li>
              )}
              
              {/* Player-specific fields */}
              {personalInfo.battingStyle && (
                <li> 
                  <div className='title'>
                    <div className='icon'><FaBaseballBall /></div>
                    <h6>Batting Style:</h6>
                  </div> 
                  <span>{personalInfo.battingStyle}</span>
                </li>
              )}
              
              {personalInfo.bowlingStyle && (
                <li> 
                  <div className='title'>
                    <div className='icon'><FaBaseballBall /></div>
                    <h6>Bowling Style:</h6>
                  </div> 
                  <span>{personalInfo.bowlingStyle}</span>
                </li>
              )}
              
              {/* Coach-specific fields */}
              {personalInfo.coachingRole && (
                <li> 
                  <div className='title'>
                    <div className='icon'><FaUserTie /></div>
                    <h6>Coaching Role:</h6>
                  </div> 
                  <span>{personalInfo.coachingRole}</span>
                </li>
              )}
              
              {personalInfo.coachingExperience && (
                <li> 
                  <div className='title'>
                    <div className='icon'><FaBriefcase /></div>
                    <h6>Coaching Experience:</h6>
                  </div> 
                  <span>{personalInfo.coachingExperience}</span>
                </li>
              )}
              
              {/* Major Teams - Different labels for player vs coach */}
              {personalInfo.majorTeams && (
                <li> 
                  <div className='title'>
                    <div className='icon'><FaUsers /></div>
                    <h6>{personalInfo.coachingRole ? "Teams Coached:" : "Major Teams:"}</h6>
                  </div> 
                  <span>{personalInfo.majorTeams.join(', ')}</span>
                </li>
              )}
              
              {/* Certifications - Coach specific */}
              {personalInfo.certifications && (
                <li> 
                  <div className='title'>
                    <div className='icon'><FaCertificate /></div>
                    <h6>Certifications:</h6>
                  </div> 
                  <span>{personalInfo.certifications.join(', ')}</span>
                </li>
              )}
            </ul>

          </div>

        </div>

        {!isCoach && (
          <div className='box-container player-stats'>

            {/* Batting Statistics */}
            <div className='info-item stat-item'>

              <SidebarHeading title='Batting Stats' />

              <div className="stat-container">

                {/* Batting first half */}
                <ul>
                  {Object.entries(firstHalfBatting).map(([key, value]) => (
                    <li key={key}>
                      <div className='title'>
                        <div className='icon'><BiSolidCricketBall /></div>
                        <h6>{formatLabel(key)}:</h6>
                      </div> 
                      <span>{value}</span>
                    </li>
                  ))}
                </ul>

                {/* Batting second half */}
                <ul>
                  {Object.entries(secondHalfBatting).map(([key, value]) => (
                    <li key={key}>
                      <div className='title'>
                        <div className='icon'><BiSolidCricketBall /></div>
                        <h6>{formatLabel(key)}:</h6>
                      </div> 
                      <span>{value}</span>
                    </li>
                  ))}
                </ul>

              </div>

            </div>

            {/* Bowling Statistics */}
            <div className='info-item stat-item'>

              <SidebarHeading title='Bowling Stats' />

              <div className="stat-container">

                {/* Bowling first half */}
                <ul>
                  {Object.entries(firstHalfBowling).map(([key, value]) => (
                    <li key={key}>
                      <div className='title'>
                        <div className='icon'><BiSolidCricketBall /></div>
                        <h6>{formatLabel(key)}:</h6>
                      </div> 
                      <span>{value}</span>
                    </li>
                  ))}
                </ul>

                {/* Bowling second half */}
                <ul>
                  {Object.entries(secondHalfBowling).map(([key, value]) => (
                    <li key={key}>
                      <div className='title'>
                        <div className='icon'><BiSolidCricketBall /></div>
                        <h6>{formatLabel(key)}:</h6>
                      </div> 
                      <span>{value}</span>
                    </li>
                  ))}
                </ul>

              </div>

            </div>

          </div>
        )}

      </div>

    </>

  );
}

export default ProfileDetails;