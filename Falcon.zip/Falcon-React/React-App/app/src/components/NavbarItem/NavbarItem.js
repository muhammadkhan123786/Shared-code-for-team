import React from 'react';
import './NavbarItem.css';

import { FaPlus, FaMinus } from 'react-icons/fa';
import { Link } from 'react-router-dom';
 
  

const NavbarItem = (props) => {
    const { id, mainLink, subLink, isActive, onNavLinkClick, activeNestedId, onNestedNavLinkClick } = props;
  
    return (
      <div className="nav-link">
        {/* Main Navigation Link */}
        <div
          className={`main-nav-link ${isActive ? 'active' : ''}`}
          onClick={() => onNavLinkClick(id)}
        >
          {subLink.length ? (
            <div className="nav-btn">{mainLink.title}</div>
          ) : (
            <Link className="nav-btn" to={mainLink.link}>
              {mainLink.title}
            </Link>
          )}
          {subLink.length > 0 && (
            <div className="icon">{isActive ? <FaMinus /> : <FaPlus />}</div>
          )}
        </div>
  
        {/* Sub Navigation Links */}
        {isActive && subLink.length > 0 && (
          <div className="sub-nav-link">
            {subLink.map((item) => {
              if (item.children) {
                // Render nested sub-links
                return (
                  <div key={item.id} className="nav-link">
                    <div
                      className="main-nav-link"
                      onClick={(e) => {
                        e.stopPropagation(); // Prevent parent dropdown from closing
                        onNestedNavLinkClick(item.id);
                      }}
                    >
                      <div className="nav-btn">{item.title}</div>
                      <div className="icon">
                        {activeNestedId === item.id ? <FaMinus /> : <FaPlus />}
                      </div>
                    </div>
                    {activeNestedId === item.id && (
                      <div className="sub-nav-link">
                        {item.children.map((child) => (
                          <Link
                            key={child.id}
                            to={child.link}
                            className='sub-nav'
                            state={child.state || {}}
                          >
                            {child.title}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                );
              } else {
                // Render regular sub-links
                return (
                  <Link key={item.id} to={item.link} className='nav-btn' state={item.state || {}}>
                    {item.title}
                  </Link>
                );
              }
            })}
          </div>
        )}
      </div>
    );
  };
export default NavbarItem;