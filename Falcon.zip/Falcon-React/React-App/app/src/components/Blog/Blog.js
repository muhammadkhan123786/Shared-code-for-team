import React from 'react';
import './Blog.css';

import { countCommentsAndReplies, extractDateParts } from '../../utils'; // Utility function to extract date parts

import { FaComment, FaUser } from 'react-icons/fa'; // Importing icons
import { Link } from 'react-router-dom'; // Importing Link for navigation



const Blog = ({ blog }) => {

  // Extracting data from blog
  const { id, admin, image, date, heading, content, category } = blog; 

  // Format date into weekday, day, short month
  const { weekday, day, shortMonth } = extractDateParts(date);

  // Count total comments including replies
  const blogComments = blog.comments;
  const totalComments = countCommentsAndReplies(blogComments);

  return (
    <div className='blog-item' key={id}>

      <div className='image'>
        <img src={image} alt={heading} /> {/* Blog image */}
        <div className="date">{weekday} <br></br> <span>{day}</span> <br></br> {shortMonth}</div> {/* Formatted Blog date */}
      </div>

      <div className='content'>

        <Link className='category' to={`/Blogs/category/${category}`}>{category}</Link> {/* Blog category with navigation link */}

        {/* Blog Title with dynamic navigation */}
        <Link
          to={{
            pathname: '/Blogs/' + heading,
          }}
          state={blog}
          className='main-heading'>
          {heading}
        </Link>

        <p>{content}</p> {/* Short blog content/summary */}

        <div className='details'>

          {/* Blog Admin */}
          <h3>
            <div className='icon'><FaUser /></div>
            <span>By {admin}</span>
          </h3>

          {/* Blog Comments */}
          <h3>
            <div className='icon'><FaComment /></div>
            <span>{totalComments} Comments</span>
          </h3>

        </div>

      </div>

    </div>
  );
};

export default Blog;