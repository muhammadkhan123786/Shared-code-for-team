import React, { useState, useEffect } from 'react';
import './Header.css';

import { HeaderItem, MobileNavbar, Logo } from '../../components';
import { navbar } from '../../constants';

import { FaFacebookF, FaInstagram, FaLinkedin, FaBars, FaTimes, FaSearch, FaUser, FaCartArrowDown } from 'react-icons/fa';
import { FaXTwitter } from 'react-icons/fa6';

import { Link, useLocation, useNavigate } from 'react-router-dom';



const Header = () => {

  const navigate = useNavigate(); 
  const { pathname } = useLocation();

  const [click, setClick] = useState(false);
  const [isOpen, setOpen] = useState(false);
  const [isActive, setIsActive] = useState(false);
  const [searchValue, setSearchValue] = useState('');

  /********** 1-Manage Sticky Header ***********/
  useEffect(() => {
    window.addEventListener('scroll', stickyHeader);
    return () => {
      window.removeEventListener('scroll', stickyHeader);
    };
  });

  // Function to add 'active' class to header when scrolling past 60px
  const stickyHeader = (e) => {
    const header = document.querySelector('.header');
    const scrollTop = window.scrollY;
    scrollTop >= 60 ? header.classList.add('active') : header.classList.remove('active');
  };

  /********** 2-Manage On Scroll ***********/
  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  });

  // Function to close mobile navbar and search when scrolling
  const handleScroll = (e) => {
    const navbar = document.querySelector('.navbar');
    navbar.classList.remove('active');
    setClick(false);
    setOpen(false);
    setIsActive(false);
  };

  /********** 3-Manage Mobile Navbar ***********/
  // Toggles mobile menu state
  const handleClick = () => { 
    setIsActive(false);
    setClick((prevClick) => !prevClick);
    setOpen((prevOpen) => !prevOpen);
  };

  // Closes mobile menu on route change
  useEffect(() => {
    setOpen(false);
    setClick(false);
    setIsActive(false);
  }, [pathname]);

  /********** 4-Manage Search Functionality ***********/
  // Toggles search bar visibility
  const handleSearchIconClick = () => {
    setIsActive(!isActive);
    if (!isActive) {
      setSearchValue('');
    }
  };

  // Handles search submission
  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchValue.trim() !== '') {
      navigate(`/blogs/search/${searchValue}`);
      setSearchValue(''); // Reset the search value to clear the input field
    }
  };

  // Function to handle search input change
  const handleSearchChange = (e) => {
    setSearchValue(e.target.value);
  };


  return (
    <nav className='header'>

      {/* 1st Header Container - Social Links */}
      <div className='header-1'>

        {/* Social contacts */}
        <div className='social-contacts'>
          <a href="/#" className='icon'><FaFacebookF /></a>
          <a href="/#" className='icon'><FaXTwitter /></a>
          <a href="/#" className='icon'><FaInstagram /></a>
          <a href="/#" className='icon'><FaLinkedin /></a>
        </div>

      </div>

      {/* 2nd Header Container - Navbar & Search */}
      <div className='header-2'>

        {/* Mobile Navbar */}
        <MobileNavbar isOpen={isOpen} />

        {/* Logo */}
        <Logo />

        {/* Desktop Navbar */}
        <div className='navbar'>
          {
            navbar.map((item) => (
              <HeaderItem key={item.id} {...item} />
            ))
          }
        </div>

        {/* Header Icons (Search, Mobile Menu) */}
        <div className='icon-container'>
          <div id="search" className={`icon fa-solid fa-magnifying-glass ${isActive ? 'active' : ''}`} onClick={handleSearchIconClick}>
            <FaSearch className='icon' />
          </div>
          <Link to='/Login' className='icon'><FaUser /></Link>
          <Link to='/Cart' className='icon'><FaCartArrowDown /></Link>
          <div className='icon menu-btn' onClick={handleClick}>{click ? <FaTimes /> : <FaBars />}</div>
        </div>

        {/* Search Input Field */}
        <form onSubmit={handleSearchSubmit} className={`search-container ${isActive ? 'active' : ''}`}>
          <input 
            type='text' 
            id='search' 
            placeholder='Search here...' 
            value={searchValue} 
            onChange={handleSearchChange} 
            required 
          />
          <button type="submit"><FaSearch className='icon' /></button>
        </form>

      </div>

    </nav>
  );
}

export default Header;