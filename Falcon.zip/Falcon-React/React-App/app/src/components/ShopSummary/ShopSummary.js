import React, { useEffect } from 'react';
import './ShopSummary.css';



const ShopSummary = ({ cart, discount, onSummaryChange }) => {

  // Calculate subtotal (without any discounts)
  const subTotal = cart.reduce((total, item) => {
    return total + (item.price * item.quantity);
  }, 0);

  // Calculate total item-level discounts (disprice)
  const discountedAmount = cart.reduce((total, item) => {
    if (item.disprice > 0) {
      return total + ((item.price - item.disprice) * item.quantity);
    }
    return total;
  }, 0);

  // Calculate adjusted subtotal (after item-level discounts)
  const adjustedSubTotal = subTotal - discountedAmount;

  // Check if any item has disprice greater than 0
  const hasDiscountedItems = cart.some(item => item.disprice > 0);

  // Calculate coupon discount
  const couponDiscount = discount.type === 'percent'
    ? adjustedSubTotal * (discount.value / 100)
    : discount.value;

  // Calculate tax and delivery
  const taxRate = 0.1;
  const taxAmount = adjustedSubTotal * taxRate;
  const deliveryFee = adjustedSubTotal >= 300 ? 0 : 5;

  // Final total calculation
  const cartTotal = adjustedSubTotal + taxAmount + deliveryFee - couponDiscount;

  // Notify parent component whenever values change
  useEffect(() => {
    onSummaryChange?.({
      subTotal: +subTotal.toFixed(2),
      discountedAmount: +discountedAmount.toFixed(2),
      adjustedSubTotal: +adjustedSubTotal.toFixed(2),
      couponDiscount: +couponDiscount.toFixed(2),
      taxAmount: +taxAmount.toFixed(2),
      deliveryFee: +deliveryFee.toFixed(2),
      cartTotal: +cartTotal.toFixed(2),
    });
  }, [subTotal, discountedAmount, adjustedSubTotal, couponDiscount, taxAmount, deliveryFee, cartTotal, onSummaryChange]);

  return (
    <div className='shop-summary'>
      {/* Subtotal (before any discounts) */}
      <div className='summary-item'>
        <div className='box name'>Sub Total</div>
        <div className='box value'>${subTotal.toFixed(2)}</div>
      </div>

      {/* Item Discounts (only show if any item has disprice > 0) */}
      {hasDiscountedItems && (
        <div className='summary-item'>
          <div className='box name'>Item Discounts</div>
          <div className='box value'>-${discountedAmount.toFixed(2)}</div>
        </div>
      )}

      {/* Adjusted Subtotal (only show if any item has disprice > 0) */}
      {hasDiscountedItems && (
        <div className='summary-item highlighted'>
          <div className='box name'>Adjusted Subtotal</div>
          <div className='box value'>${adjustedSubTotal.toFixed(2)}</div>
        </div>
      )}

      {/* Coupon Discount (only show if a coupon is applied) */}
      {couponDiscount > 0 && (
        <div className='summary-item'>
          <div className='box name'>Coupon Discount ({discount.type === 'percent' ? `${discount.value}%` : `$${discount.value}`})</div>
          <div className='box value'>-${couponDiscount.toFixed(2)}</div>
        </div>
      )}

      {/* Tax */}
      <div className='summary-item'>
        <div className='box name'>Tax (10%)</div>
        <div className='box value'>${taxAmount.toFixed(2)}</div>
      </div>

      {/* Delivery */}
      <div className='summary-item'>
        <div className='box name'>Delivery</div>
        <div className='box value'>${deliveryFee.toFixed(2)}</div>
      </div>

      {/* Total */}
      <div className='summary-item total'>
        <div className='box name'>Total</div>
        <div className='box value'>${cartTotal.toFixed(2)}</div>
      </div>
    </div>
  );
};

export default ShopSummary;