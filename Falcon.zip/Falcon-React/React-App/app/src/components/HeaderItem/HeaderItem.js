import React from "react";
import "./HeaderItem.css";

import { FaChevronRight } from "react-icons/fa";
import { Link } from "react-router-dom";



const HeaderItem = ({ id, mainLink, subLink }) => {

  return (
    <div className="nav-item" key={id}>

      {/* Dropdown Menu - Main navigation button */}
      <div className="dropdown-menu">
        {subLink.length > 0 ? (
          <div className="nav-btn">{mainLink.title}</div>
        ) : (
          <Link className="nav-btn" to={mainLink.link}>
            {mainLink.title}
          </Link>
        )}
      </div>

      {/* Dropdown Content - Display sub-links if available */}
      {subLink.length > 0 && (
        <div className="dropdown-content">
          {subLink.map((item) => (
            <div key={item.id} className="dropdown-item">
              {item.children ? (
                <div className="side-dropdown">

                  {/* Button for nested sub-dropdown */}
                  <button>{item.title}</button> 
                  <FaChevronRight />

                  {/* Sub-dropdown Content */}
                  <div className="dropdown-content">
                    {item.children.map((subItem) => (
                      <Link to={subItem.link} state={subItem.state} key={subItem.id}>
                        {subItem.title}
                      </Link>
                    ))}
                  </div>

                </div>
              ) : (
                // Direct link if there are no child links
                <Link to={item.link} state={item.state}>
                  {item.title}
                </Link>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HeaderItem;