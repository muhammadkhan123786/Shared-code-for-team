import React from 'react';
import './EmptyState.css'; 

import { Button } from '../../components';



const EmptyState = ({ icon: Icon, title, message, buttonLink, buttonText }) => {
  return (

    <div className='empty-state'>

      {/* Display the provided icon */}
      <div>{Icon && <Icon className='icon' />}</div>

      {/* Display the title */}
      <h3>{title}</h3>

      {/* Display the message */}
      <p className="empty-state-message">{message}</p>

      {/* Button for navigation */}
      <Button link={buttonLink} title={buttonText} />

    </div>

  );
};

export default EmptyState;