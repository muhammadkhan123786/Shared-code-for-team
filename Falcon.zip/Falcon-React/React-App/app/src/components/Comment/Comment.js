import React from 'react';
import './Comment.css';

import { FaReply, FaStar } from 'react-icons/fa';



const Comment = ({ comment, reply }) => { 

  // Destructuring props
  const { id, image, name, date, rating, content } = comment;

  return (
    <div className='comment' key={id}>

      {/* User Image */}
      <div className='comment-image'>
        <img src={image} alt={name} /> 
      </div>

      {/* Comment Content Container */}
      <div className='comment-content'>

        <div className='comment-intro'>

          <div className='comment-text'>
            <h3>{name}</h3> {/* User Name */}
            <h6>{date}</h6> {/* Comment Date */}
          </div>

          {/* Render rating if it's greater than 0 */}
          {rating > 0 && (
            <div className='rating'>
              <div className='icon'>
                <FaStar /> <FaStar /> <FaStar /> <FaStar /> <FaStar />
              </div>
              <h5>{rating}</h5>
            </div>
          )}

        </div>

        {/* Comment Text */}
        <p>{content}</p>

        {/* Reply Icon */}
        {reply && (
        <div className='icon-item'>
          <FaReply className='icon' />
          <span>reply</span>
        </div>)}

      </div> 
    </div>
  );
};

export default Comment;