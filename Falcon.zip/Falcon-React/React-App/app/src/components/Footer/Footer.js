import React from 'react';
import './Footer.css';

import { Logo, Newsletter } from '../../components'; // Importing the Logo and Newsletter components
import { contactContent } from '../../constants'; // Importing contact information and services data

// Importing necessary icons from react-icons
import { FaFacebookF, FaInstagram, FaLinkedin } from 'react-icons/fa';
import { FaXTwitter } from "react-icons/fa6";
import { BiSolidCricketBall } from 'react-icons/bi';

// Importing Link for navigation
import { Link } from 'react-router-dom';



const Footer = () => {

  return (
    <footer className='footer'>

      <div className='box-container'>

        {/* About Section */}
        <div className='footer-item'>

          <Logo /> {/* Display the Logo component */}
          <p>Experience the spirit of sportsmanship at Falcon Cricket & Sports Club. We are dedicated to developing cricketing talent, building teamwork, and creating memorable moments for players and fans alike.</p> {/* Description for the about section */}

          {/* Social media icons with links */}
          <div className='social'>
            <a href="/#"><FaFacebookF className='icon' /></a>
            <a href="/#"><FaXTwitter className='icon' /></a>
            <a href="/#"><FaInstagram className='icon' /></a>
            <a href="/#"><FaLinkedin className='icon' /></a>
          </div>

        </div>

        {/* Contact Info Section */}
        <div className='footer-item'> 

          <h2>Contact Info</h2>

          <div className='info connect'>
            {contactContent
              .filter(contact => contact.id !== 4) // Exclude the contact with id: 4
              .map((contact) => {
                return (
                  <div key={contact.id}>
                    {contact.content.map((item, index) => (
                      <div key={index} className='connect-item'>
                        <div className='icon'>{contact.icon}</div>
                        <span>{item}</span>
                      </div>
                    ))}
                  </div>
                );
              })
            }
          </div>

        </div>

        {/* Useful Links Section */}
        <div className='footer-item'>

          <h2>Quick Links</h2>

          {/* Links for easy navigation to various pages */}
          <div className='info links'> 
            <p><BiSolidCricketBall className='icon' /><Link to='/About-us'>about Us</Link></p>
            <p><BiSolidCricketBall className='icon' /><Link to='/Team'>Team</Link></p>
            <p><BiSolidCricketBall className='icon' /><Link to='/Events'>Events</Link></p>
            <p><BiSolidCricketBall className='icon' /><Link to='/Fixtures'>Fixtures</Link></p>
            <p><BiSolidCricketBall className='icon' /><Link to='/Shop-grid'>Shop</Link></p>
            <p><BiSolidCricketBall className='icon' /><Link to='/Contact-us'>contact</Link></p>
          </div>

        </div>

        {/* Newsletter Section */}
        <div className='footer-item'>

          <h2>Newsletter</h2>
          <p>Stay connected for match updates, club news, and exciting events from Falcon Cricket & Sports Club.</p> {/* Description for the Newsletter section */}

          {/* Newsletter component to subscribe */}
          <Newsletter variant='dark' idPrefix='2' />

        </div>

      </div>

      <div className='content'>

        {/* Footer content with copyright information */}
        <p> &copy; Falcon 2025 All Rights Reserved</p>

      </div>

    </footer>
  )
}

export default Footer;