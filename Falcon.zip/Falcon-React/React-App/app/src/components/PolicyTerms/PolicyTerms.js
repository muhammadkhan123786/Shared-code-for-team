import React, { useEffect } from "react";
import "./PolicyTerms.css";

import { PageTitle } from "../../components";

import { FaCircleNotch } from "react-icons/fa";



const PolicyTerms = ({ title = "Privacy Policy", page = "privacy policy", policies }) => {

  // useEffect hook to scroll to the section when URL hash changes
  useEffect(() => {

    // If there's a hash in the URL, find the corresponding element and scroll to it
    if (window.location.hash) {
      const element = document.querySelector(window.location.hash);
      if (element) {
        element.scrollIntoView({ behavior: "smooth" });  // Smooth scroll to the sectio
      }
    }
  }, []);

  return (
    <>
      {/* Page Title */}
      <PageTitle title={title} page={page} />

      <section className="policy">

        {/* Tab Buttons */}
        <div className="policy-tab-buttons">
          {policies.map((item) => (
            <a key={item.id} href={`#${item.id}`} className="category btn">
              {item.title}
            </a>
          ))}
        </div>

        {/* Policy Content - All sections visible */}
        <div className="policy-tabs">
          {policies.map((item) => (
            <div key={item.id} id={item.id} className="policy-item">

              <h3>{item.title}</h3> {/* Display the policy title */}
              <p>{item.content}</p> {/* Display the policy content */}

              {/* Render a list if it exists */}
              {item.list && (
                <ul>
                  {item.list.map((point, index) => (
                    <li key={index}>
                      <div className="icon"><FaCircleNotch /></div> {/* Icon for each list item */}
                      <span>{point}</span> {/* Display the list point */}
                    </li>
                  ))}
                </ul>
              )}
            </div>
          ))}
        </div>
      </section>
    </>
  );
};

export default PolicyTerms;