import React from 'react';
import './LightBox.css';

// Import react-photo-view components and styles
import { PhotoProvider, PhotoView } from 'react-photo-view';
import 'react-photo-view/dist/react-photo-view.css';



const LightBox = ({ images }) => {
  return (
    <div className="page-gallery">
      {/* Wrap the gallery in PhotoProvider */}
      <PhotoProvider>
        <div className="gallery-grid">
          {images.map((image, index) => (
            <PhotoView key={index} src={image}>
              <img src={image} alt="" />
            </PhotoView>
          ))}
        </div>
      </PhotoProvider>
    </div>
  );
};

export default LightBox;