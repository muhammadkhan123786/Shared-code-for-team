import React from 'react';
import './ShowcaseHeader.css';

import { FaList } from 'react-icons/fa';
import { BsFillGrid3X3GapFill } from 'react-icons/bs';

import { Link } from 'react-router-dom';
import Select from 'react-select';



// Base sorting options
let baseSorting = [
  { value: '', label: 'default', isDisabled: true },
  { value: 'featured', label: 'featured' },
  { value: 'lowPrice', label: 'low price' },
  { value: 'highPrice', label: 'high price' }
];

const ShowcaseHeader = ({ showing, total, sortOption, handleSort }) => {

  // Determine correct links based on the type
  const gridLink = '/Shop-grid';
  const listLink = '/Shop-list';

  // Find the selected sorting option
  const selectedOption = baseSorting.find((option) => option.value === sortOption);

  return (
    <div className='showcase'>

      <div className='showing'>showing {showing} of {total} products</div>

      <div className='styles'>
        <Link to={gridLink}><BsFillGrid3X3GapFill /></Link>
        <Link to={listLink}><FaList /></Link>
      </div>

      <Select
        options={baseSorting}
        value={selectedOption}
        onChange={handleSort}
        isSearchable={false}
        className="custom-select sorting box"
        classNamePrefix="custom-select-prefix"
      />
    </div>
  );
}

export default ShowcaseHeader;