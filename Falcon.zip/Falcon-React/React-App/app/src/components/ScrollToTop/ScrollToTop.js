import { useEffect } from "react";
import { useLocation } from "react-router-dom";

const ScrollToTop = () => {
    const { pathname, hash } = useLocation();

    useEffect(() => {
        // Only scroll to the top if there's no hash in the URL
        if (!hash) {
            window.scrollTo(0, 0);
        }
    }, [pathname]); // Runs only when the pathname changes

    return null;
};

export default ScrollToTop;
