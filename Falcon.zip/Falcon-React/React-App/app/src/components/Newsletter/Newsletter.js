import React, { useState, useEffect } from "react";
import "./Newsletter.css";

import { FaEnvelope } from "react-icons/fa"; // Importing email icon
import axios from "axios"; // Importing axios for making HTTP requests

// API path for the newsletter subscription endpoint
const API_PATH = "https://www.example.com/api/phpmailer/newsletter.php";



const Newsletter = ({ variant, idPrefix }) => {

  // State hooks for managing form values and errors
  const [email, setEmail] = useState(""); 
  const [mailSent, setMailSent] = useState(false); // To track if the email is successfully sent
  const [serverError, setServerError] = useState(""); // To store server-side errors

  // Using useEffect to reset the mailSent state after a few seconds
  useEffect(() => {
    const timer = mailSent && setTimeout(() => setMailSent(false), 3000);
    return () => timer && clearTimeout(timer);
  }, [mailSent]); // This effect runs when the mailSent state changes

  // Handle form submission
  const handleSubmit = async (e) => {

    e.preventDefault(); // Prevent the default form submission
    const submitBtn = document.querySelector(`#submit-${idPrefix}`); // Get the submit button

    try {

      submitBtn.innerText = "Processing..."; // Change button text to indicate processing
      setServerError(""); // Clear any previous server errors

      // Basic email validation using regular expression
      if (!/^\w+([.-]?\w+)*@\w+([.-]?\w+)*(\.\w{2,3})+$/.test(email)) {
        throw new Error("Please enter a valid email address"); // Show error if email is invalid
      }

      // Create FormData object and append email
      const formData = new FormData();
      formData.append("email", email);

      // Send the form data to the server via POST request
      const response = await axios.post(API_PATH, formData, {
        headers: { "Content-Type": "multipart/form-data" }
      });

      // If the subscription is successful
      if (response.data.sent) {
        setMailSent(true); // Set mailSent to true for success message
        setEmail(""); // Clear the email input field
      } else {
        setServerError(response.data.message || "Subscription failed"); // Show server error message
      }

    } catch (error) {
      // Handle errors
      const errorMessage = error.response?.data?.message 
        || error.message 
        || "An error occurred"; // Get error message
      setServerError(errorMessage); // Set server error state
    } finally {
      submitBtn.innerText = "Subscribe"; // Reset button text to original after submission
    }

  };

  return (
    <form
      onSubmit={handleSubmit} // Handle form submission
      className={`${variant === "dark" ? "dark-form" : "newsletter-form"} news-form`}
    >

      {/* Conditional rendering based on variant */}
      {variant === "default" ? (
        <div className="box-container">

          {/* Email input field */}
          <input type="email" id={`sub-email-${idPrefix}`} value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Your email address" required />

          {/* Submit button */}
          <button type="submit" id={`submit-${idPrefix}`} className="btn">Subscribe</button>
        
        </div>
      ) : (
        <>
          {/* Input field with icon for dark variant */}
          <div className="input-field">

            <label htmlFor={`news-email-${idPrefix}`} className="icon">
              <FaEnvelope /> {/* Envelope icon */}
            </label>
            <input type="email" id={`news-email-${idPrefix}`} value={email} onChange={(e) => setEmail(e.target.value)} className="box" placeholder="Your email address" required />

          </div>
          
          {/* Submit button */}
          <button type="submit" id={`submit-${idPrefix}`} className="btn">Subscribe</button>
        </>
      )}

      {/* Display success or error message */}
      {(mailSent || serverError) && (
        <span 
          className={`alert ${mailSent ? "success" : "error"}`} // Show success or error class
          id={`msg-${idPrefix}`}
        >
          {mailSent ? "Thank you for subscribing!" : serverError} {/* Display success or error message */}
        </span>
      )}
    </form>
  );
};

export default Newsletter;