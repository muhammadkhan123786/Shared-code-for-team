import React, { useEffect, useRef, useState } from 'react';
import './Portfolio.css';

import { PortfolioItem, PortfolioTabs } from '..';
import { portfolio } from '../../constants';

import Isotope from 'isotope-layout';

// Import react-photo-view components and styles
import { PhotoProvider } from 'react-photo-view';
import 'react-photo-view/dist/react-photo-view.css';



const Portfolio = () => {

  // State
  const [category, setCategory] = useState('all');
  const iso = useRef(null);
  const gridRef = useRef(null);

  // Function to format category names as Isotope classes
  const formatCategory = (name) => name.toLowerCase().replace(/\s+/g, '-');

  // Get unique categories from Portfolio
  const categories = ['all', ...new Set(portfolio.map(item => formatCategory(item.details.category)))];

  // Initialize Isotope
  useEffect(() => {
    iso.current = new Isotope(gridRef.current, {
      itemSelector: '.portfolio-item',
      layoutMode: 'fitRows',
    });

    return () => {
      iso.current.destroy();
    };
  }, []);

  // Apply filter when category changes
  useEffect(() => {
    if (iso.current) {
      iso.current.arrange({
        filter: category === 'all' ? '*' : `.${category}`, // Filters by class name
      });
    }
  }, [category]);

  return (
    <div className='portfolio'>

      {/* Portfolio Tabs */}
      <ul className="tab-buttons">
        {categories.map((item) => (
          <PortfolioTabs
            key={item}
            id={item}
            title={item.replace(/-/g, ' ')} // Show original category name
            setSelected={() => setCategory(item)}
            active={category === item}
          />
        ))}
      </ul>

      {/* Portfolio */}
      <PhotoProvider>
        <div className="box-container" ref={gridRef}>
          {portfolio.map((item, index) => {
            const className = formatCategory(item.details.category);
            return (
              <PortfolioItem
                key={index}
                id={index}
                image={item.image}
                title={item.title}
                category={item.details.category}
                portfolio={item}
                className={className} // Add class for Isotope filtering
              />
            );
          })}
        </div>
      </PhotoProvider>
    </div>
  );
};

export default Portfolio;