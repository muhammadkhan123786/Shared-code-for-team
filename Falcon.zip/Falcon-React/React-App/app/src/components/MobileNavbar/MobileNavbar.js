import React, { useEffect, useState } from 'react';
import './MobileNavbar.css';

import { NavbarItem } from '../../components';
import { navbar } from '../../constants';



/* Mobile Navbar container */
const MobileNavbar = (props) => { 
 
  // Destructuring props 
  const { isOpen } = props;
 
  const [activeNavLinkId, setActiveNavLinkId] = useState(null);
  const [activeNestedId, setActiveNestedId] = useState(null);

  const handleNavLinkClick = (id) => {
    setActiveNavLinkId((prevId) => (prevId === id ? null : id));
    setActiveNestedId(null); // Reset nested dropdown when parent is clicked
  };

  const handleNestedNavLinkClick = (id) => {
    setActiveNestedId((prevId) => (prevId === id ? null : id));
  };
 
  // Reset the active nav link when the mobile navbar menu is closed
  useEffect(() => {
    if (!isOpen) {
      setActiveNavLinkId(null); 
    }
  }, [isOpen]);

  return (
    
    <div className={`mobile-menu ${isOpen ? 'active' : ''}`}>

      {/* Navigation items */}
      <nav className="mobile-navbar">
      {navbar.map((item) => (
        <NavbarItem
          key={item.id}
          id={item.id}
          mainLink={item.mainLink}
          subLink={item.subLink}
          isActive={item.id === activeNavLinkId}
          activeNestedId={activeNestedId}
          onNavLinkClick={handleNavLinkClick}
          onNestedNavLinkClick={handleNestedNavLinkClick}
        />
      ))}
    </nav>
    
    </div>
  )
}

export default MobileNavbar;