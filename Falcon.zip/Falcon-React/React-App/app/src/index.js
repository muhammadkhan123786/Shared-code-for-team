import React from 'react';
import ReactDOM from "react-dom/client";
import App from './App';
import './index.css';
import { BrowserRouter } from 'react-router-dom';

import { WishlistProvider } from "./utils/WishlistUtils";
import { CartProvider } from './utils/CartUtils';



const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(
    <BrowserRouter>
      <CartProvider>
        <WishlistProvider>
            <App />
        </WishlistProvider>
      </CartProvider>
    </BrowserRouter>
);

