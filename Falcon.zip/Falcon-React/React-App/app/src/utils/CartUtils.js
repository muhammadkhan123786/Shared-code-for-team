import { createContext, useReducer, useContext, useEffect, useMemo } from "react";

import { showErrorToast, showSuccessToast } from "../components";
import { productsContent } from "../constants"; // Importing product list

// Define action types
const ADD_TO_CART = "ADD_TO_CART";
const REMOVE_FROM_CART = "REMOVE_FROM_CART";
const REMOVE_COMPLETELY = "REMOVE_COMPLETELY";
const CLEAR_CART = "CLEAR_CART";
const LOAD_CART = "LOAD_CART";
const SYNC_CART_WITH_PRODUCTS = "SYNC_CART_WITH_PRODUCTS";
const APPLY_COUPON = "APPLY_COUPON";

// Valid coupons
const validCoupons = {
  SAVE10: { type: "percent", value: 10 }, // 10% discount
  FREESHIP: { type: "fixed", value: 5 }, // $5 discount
  WELCOME20: { type: "percent", value: 20 }, // 20% discount
};

// Helper function to get cart from localStorage
const getCartFromStorage = () => {
  if (typeof window === "undefined") {
    return [];
  }
  try {
    const storedCart = localStorage.getItem("cart");
    return storedCart ? JSON.parse(storedCart) : [];
  } catch (error) {
    console.error("Error accessing localStorage:", error);
    return [];
  }
};

// Cart reducer function to manage cart actions
const cartReducer = (state, action) => {
  switch (action.type) {
    case ADD_TO_CART: {
      const { id, quantity } = action.payload;
      const existingItem = state.cart.find((item) => item.id === id);
    
      if (existingItem) {
        return {
          ...state,
          cart: state.cart.map((item) =>
            item.id === id
              ? { ...item, quantity: quantity !== undefined ? quantity : item.quantity + 1 }
              : item
          ),
        };
      }
    
      return {
        ...state,
        cart: [...state.cart, { ...action.payload, quantity: quantity || 1 }],
      };
    }
    

    case REMOVE_FROM_CART: {
      return {
        ...state,
        cart: state.cart
          .map((item) =>
            item.id === action.payload.id ? { ...item, quantity: item.quantity - 1 } : item
          )
          .filter((item) => item.quantity > 0),
      };
    }

    case REMOVE_COMPLETELY: {
      return {
        ...state,
        cart: state.cart.filter((item) => item.id !== action.payload.id),
      };
    }

    case CLEAR_CART: {
      return { ...state, cart: [], discount: { type: "fixed", value: 0 }, couponCode: "" };
    }

    case LOAD_CART: {
      return { ...state, cart: action.payload };
    }

    case SYNC_CART_WITH_PRODUCTS: {
      const syncedCart = state.cart.map((cartItem) => {
        const product = action.payload.find((p) => p.id === cartItem.id);
        return product
          ? { ...cartItem, stock: product.stock }
          : cartItem;
      });

      return {
        ...state,
        cart: syncedCart,
      };
    }

    case APPLY_COUPON: {
      const coupon = validCoupons[action.payload];
      if (coupon) {
        return {
          ...state,
          discount: coupon,
          couponCode: action.payload,
        };
      }
      return state;
    }

    default:
      return state;
  }
};

// Create Context
const CartContext = createContext();

// CartProvider component to manage cart state and provide it to the app
export const CartProvider = ({ children, products = productsContent }) => {
  const [state, dispatch] = useReducer(
    cartReducer,
    { cart: [], discount: { type: "fixed", value: 0 }, couponCode: "" },
    () => {
      const storedCart = getCartFromStorage();
      return { cart: storedCart, discount: { type: "fixed", value: 0 }, couponCode: ""};
    }
  );

  // Create a product map for faster lookups
  const productMap = useMemo(() => new Map(products.map((product) => [product.id, product])), [products]);

  // Sync cart state with localStorage whenever it changes
  useEffect(() => {
    if (typeof window !== "undefined") {
      localStorage.setItem("cart", JSON.stringify(state.cart));
    }
  }, [state.cart]);

  // Sync cart with product data whenever productsContent changes
  useEffect(() => {
    dispatch({ type: SYNC_CART_WITH_PRODUCTS, payload: products });
  }, [products]);

  // Action creators
  const addToCart = (item, newQuantity = undefined) => {
    try {
      if (!item || !item.id) {
        showErrorToast("Invalid item.");
        return;
      }
  
      const product = productMap.get(item.id);
      if (!product) {
        showErrorToast("Product not found.");
        return;
      }
  
      const availableStock = product.stock;
      const existingItem = state.cart.find((cartItem) => cartItem.id === item.id);
  
      let finalQuantity = existingItem ? (newQuantity !== undefined ? newQuantity : existingItem.quantity + 1) : (newQuantity || 1);
  
      if (finalQuantity > availableStock) {
        showErrorToast(`Limited stock available! You can add up to ${availableStock} units.`);
        return;
      }
  
      dispatch({ type: ADD_TO_CART, payload: { ...item, quantity: finalQuantity } });
  
      if (existingItem) {
        showSuccessToast(`Updated quantity of ${item.name} to ${finalQuantity}`);
      } else {
        showSuccessToast(`${item.name} added to cart!`);
      }
    } catch (error) {
      console.error("Error adding to cart:", error);
    }
  };
  

  const removeFromCart = (item) => {
    dispatch({ type: REMOVE_FROM_CART, payload: item });

    // Show success toast after dispatch
    const itemToRemove = state.cart.find((cartItem) => cartItem.id === item.id);
    if (itemToRemove) {
      if (itemToRemove.quantity === 1) {
        showSuccessToast(`Removed ${itemToRemove.name} from cart.`);
      } else {
        showSuccessToast(`Reduced quantity of ${itemToRemove.name} to ${itemToRemove.quantity - 1}`);
      }
    }
  };

  const removeCompletely = (item) => {
    dispatch({ type: REMOVE_COMPLETELY, payload: item });

    // Show success toast after dispatch
    const itemToRemove = state.cart.find((cartItem) => cartItem.id === item.id);
    if (itemToRemove) {
      showSuccessToast(`Removed ${itemToRemove.name} from the cart.`);
    }
  };

  const clearCart = () => {
    dispatch({ type: CLEAR_CART });
  };

  const applyCoupon = (couponCode) => {
    if (validCoupons[couponCode]) {
      dispatch({ type: APPLY_COUPON, payload: couponCode });

      // Show success toast after dispatch
      showSuccessToast(
        `Coupon applied successfully! You got a ${
          validCoupons[couponCode].type === "percent"
            ? `${validCoupons[couponCode].value}%`
            : `$${validCoupons[couponCode].value}`
        } discount.`
      );
    } else {
      showErrorToast("Invalid coupon code. Please try again.");
    }
  };

  // Function to get product stock
  const getProductStock = (productId) => {
    const product = productMap.get(productId);
    return product?.stock || 0; // Return the stock if the product exists, otherwise return 0
  };

  const validateCheckout = async () => {
    // Perform validation logic directly
    const outOfStockItems = state.cart.filter((item) => item.stock === 0);
    const itemsExceedingStock = state.cart.filter(
      (item) => item.quantity > item.stock && item.stock > 0
    );

    if (outOfStockItems.length > 0 || itemsExceedingStock.length > 0) {
      if (outOfStockItems.length > 0) {
        showErrorToast(`Out of stock: ${outOfStockItems.map(item => item.name).join(", ")}. Please remove them to proceed.`);
      }
      if (itemsExceedingStock.length > 0) {
        showErrorToast(`Some items exceed available stock: ${itemsExceedingStock.map(item => item.name).join(", ")}. Please update your cart.`);
      }
      return false; // Checkout is blocked
    }

    return true; // Checkout is allowed
  };

  // Provide cart state and actions to the app
  return (
    <CartContext.Provider
      value={{
        cart: state.cart,
        addToCart,
        removeFromCart,
        removeCompletely,
        clearCart,
        discount: state.discount,
        applyCoupon,
        getProductStock,
        validateCheckout,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

// Custom Hook for using Cart Context
export const useCart = () => useContext(CartContext);