import { createContext, useReducer, useContext, useEffect, useMemo } from "react";

import isEqual from "lodash/isEqual"; // For deep comparison

import { productsContent } from "../constants"; // Importing product list
import { showErrorToast, showSuccessToast } from "../components";



// Define action types
const ADD_TO_WISHLIST = "ADD_TO_WISHLIST";
const REMOVE_FROM_WISHLIST = "REMOVE_FROM_WISHLIST";
const UPDATE_WISHLIST = "UPDATE_WISHLIST";

// Get wishlist from localStorage
const getWishlistFromStorage = () => {
  if (typeof window === "undefined") {
    return [];
  }
  try {
    const storedWishlist = localStorage.getItem("wishlist");
    return storedWishlist ? JSON.parse(storedWishlist) : [];
  } catch (error) {
    console.error("Error accessing localStorage:", error);
    return [];
  }
};

// Wishlist reducer function
const wishlistReducer = (state, action) => {
  switch (action.type) {
    case ADD_TO_WISHLIST: {
      const existingItem = state.find((item) => item.id === action.payload.id);
      if (existingItem) {
        return state; // Item already exists in wishlist
      }
      return [
        ...state,
        {
          ...action.payload,
        },
      ];
    }

    case REMOVE_FROM_WISHLIST: {
      return state.filter((item) => item.id !== action.payload.id);
    }

    case UPDATE_WISHLIST: {
      if (!Array.isArray(action.payload)) {
        console.error("Invalid payload for UPDATE_WISHLIST");
        return state;
      }
      return action.payload;
    }

    default:
      return state;
  }
};

// Create Context
const WishlistContext = createContext();

// Wishlist Provider Component
export const WishlistProvider = ({ children, products = productsContent }) => {

  const [wishlist, dispatch] = useReducer(wishlistReducer, [], getWishlistFromStorage);

  // Create a product map for faster lookups
  const productMap = useMemo(() => new Map(products.map((product) => [product.id, product])), [products]);

  // Sync with localStorage
  useEffect(() => {
    try {
      if (typeof window !== "undefined") {
        localStorage.setItem("wishlist", JSON.stringify(wishlist));
      }
    } catch (error) {
      console.error("Error updating localStorage:", error);
    }
  }, [wishlist]);

  // Update stock status dynamically
  useEffect(() => {
    const updatedWishlist = wishlist.map((item) => {
      const latestProduct = productMap.get(item.id);
      return {
        ...item,
        stock: latestProduct ? latestProduct.stock : 0, // Update stock
      };
    });

    // Deep comparison to check if the wishlist has changed
    if (!isEqual(updatedWishlist, wishlist)) {
      dispatch({ type: UPDATE_WISHLIST, payload: updatedWishlist });
    }
  }, [products]);

  // Actions
  const addToWishlist = (item) => {
    try {
      const latestProduct = productMap.get(item.id);
      if (!latestProduct) {
        console.error("Product not found in productsContent.");
        return;
      }

      const existingItem = wishlist.find((wishlistItem) => wishlistItem.id === item.id);
      if (existingItem) {
        showErrorToast(`${item.name} is already in your wishlist!`);
        return;
      }

      dispatch({
        type: ADD_TO_WISHLIST,
        payload: {
          ...item,
          stock: latestProduct.stock, // Update stock instead of inStock
        },
      });

      showSuccessToast(`${item.name} added to wishlist!`);
    } catch (error) {
      console.error("Error adding to wishlist:", error);
    }
  };

  const removeFromWishlist = (item) => {
    dispatch({ type: REMOVE_FROM_WISHLIST, payload: item });
    showSuccessToast(`${item.name} removed from wishlist.`);
  };

  // Function to check product availability
  const checkProductAvailability = (productId) => {
    const product = productMap.get(productId);
    return product?.stock > 0 || false; // Check if stock is greater than 0
  };

  return (
    <WishlistContext.Provider value={{ wishlist, addToWishlist, removeFromWishlist, checkProductAvailability }}>
      {children}
    </WishlistContext.Provider>
  );
};

// Custom Hook for using Wishlist Context
export const useWishlist = () => useContext(WishlistContext);