// Exporting the 'renderIcon' function from 'RenderIcons.js' (handles icon rendering)
export { renderIcon } from './RenderIcons';

// Exporting the 'latestItems' array from 'LatestItems.js' (contains latest product or item data)
export { latestItems } from './LatestItems';

// 'getPopular' fetches popular items, and 'calculateAverageRating' calculates the average rating
export { getPopular, calculateAverageRating } from './PopularItems';

// Handles loading state management while filtering items
export { useFilterLoading } from './FilterLoading';

// Exporting the utility function to retrieve items based on their IDs
export { getItemsByIds } from './IdItems';

// Manages filtering logic for items or products
export { useFilter } from './FilterUtils';

// Exporting 'getTeamLogo' from 'TeamLogo.js'
export { getTeamLogo } from './TeamLogo';

// Counts the number of comments and replies
export { countCommentsAndReplies } from './CommentsLength';

// Extracts day, month, and year from a given date
export { extractDateParts } from './ExtractDate';

// Manages cart functionality (add, remove, update items)
export { useCart } from './CartUtils';

// Manages wishlist functionality (add and remove items)
export { useWishlist } from './WishlistUtils';

// 'generateOrderId' generates a unique order ID
// 'calculateDeliveryDate' calculates the estimated delivery date
export { generateOrderId, calculateDeliveryDate } from './CheckoutUtils';