// Function to generate a unique order ID
export const generateOrderId = () => {

  // Generate a timestamp and convert it to a base-36 string
  const timestamp = Date.now().toString(36); 

  // Generate a random string and slice it to 6 characters
  const randomString = Math.random().toString(36).substring(2, 8); 

  // Combine timestamp and random string to create a unique order ID
  return `ORDER-${timestamp}-${randomString}`.toUpperCase();

};

// Function to calculate the delivery date excluding weekends
export const calculateDeliveryDate = (businessDays = 5) => {

  const date = new Date(); // Get the current date
  let addedDays = 0; // Counter to track business days added

  // Loop until the required number of business days is added
  while (addedDays < businessDays) {
    date.setDate(date.getDate() + 1); // Move to the next day

    // Skip weekends (0 = Sunday, 6 = Saturday)
    if (date.getDay() !== 0 && date.getDay() !== 6) { 
      addedDays++; // Increment only if it's a business day
    }
  }

  // Return the formatted date in 'Month Day, Year' format
  return date.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric',
  });

};