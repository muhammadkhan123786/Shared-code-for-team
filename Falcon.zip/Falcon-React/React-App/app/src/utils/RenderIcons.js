import { FaClock, FaMapMarkerAlt, FaUserTie, FaDollarSign, FaTags, FaCalendarAlt, FaHourglassHalf, FaTrophy, FaHashtag, FaFlagCheckered, FaCoins, FaStar, FaGamepad } from 'react-icons/fa';

// Function to render the appropriate icon based on the service name
export const renderIcon = (iconName) => {

  // Convert the service name to lowercase
  const lowercaseServiceName = iconName.toLowerCase();

  // Check the lowercase service name and return the corresponding icon component
  switch (lowercaseServiceName) {

    /*----- Page Sidebar -----*/
    case 'date':
    case 'matchdate':
    case 'sessiondate':
    case 'eventdate':  
      return <FaCalendarAlt />; // Calendar for match date

    case 'time':
      return <FaClock />; // Clock for match time

    case 'duration':
      return <FaHourglassHalf />; // Hourglass for duration

    case 'category':
      return <FaTags />; // Tags for match category/format

    case 'venue':
      return <FaMapMarkerAlt />; // Map Marker for venue

    case 'ticketprice':
      return <FaDollarSign />; // Dollar sign for ticket price

    case 'umpires':
    case 'referee':
    case 'matchofficial':
    case 'sessionlead': 
    case 'eventlead':
      return <FaUserTie />; // User Tie for officials

    case 'league':
    case 'series':  
      return <FaTrophy />; // Trophy for league/series

    case 'matchno':
      return <FaHashtag />; // Hashtag for match number

    case 'result':
      return <FaFlagCheckered />; // Checkered Flag for result

    case 'toss':
      return <FaCoins />; // Coins for toss decision

    case 'pom': // Player of the Match
      return <FaStar />; // Star for standout player

    case 'matchtype':
    case 'sessiontype':
    case 'eventtype':  
      return <FaGamepad />; // Gamepad (or FaListAlt for match type/format)

    default:
      return null; // Return null if no matching icon is found
  }

};