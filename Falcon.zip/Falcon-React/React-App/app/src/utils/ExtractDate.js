// Function to extract date parts (day, month, year, and weekday) from a given date string
export function extractDateParts(dateString) {
    
    // Convert the provided date string to a Date object
    const dateObj = new Date(dateString); 
    
    // Extract the day of the month (e.g., 18)
    const day = dateObj.getDate(); 

    // Extract the full month name (e.g., January)
    const fullMonth = dateObj.toLocaleString('en-US', { month: 'long' }); 

    // Extract the short month name (e.g., Jan)
    const shortMonth = dateObj.toLocaleString('en-US', { month: 'short' }); 

    // Extract the full year (e.g., 2025)
    const year = dateObj.getFullYear(); 

    // Extract the short weekday name (e.g., 'fri') and convert to lowercase
    const weekday = dateObj.toLocaleString('en-US', { weekday: 'short' }).toLowerCase(); 

    // Return an object containing all the extracted date parts
    return { day, shortMonth, fullMonth, year, weekday };
}