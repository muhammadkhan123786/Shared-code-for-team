import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getPopular } from './PopularItems';

/**
 * Custom hook for filtering, sorting, and paginating items.
 * 
 * @param {Array} initialItems - The initial list of items to filter.
 * @param {number} itemsPerPage - Number of items to display per page (default: 4).
 * @param {string} type - Type of items (e.g., 'blog' or 'shop').
 * @returns {Object} - Filtered items, pagination, and utility functions.
 */
export const useFilter = (initialItems, itemsPerPage = 4, type) => {

  const navigate = useNavigate();

  const { category, tag, search } = useParams();

  // State variables
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedTag, setSelectedTag] = useState('');
  const [searchKeyword, setSearchKeyword] = useState('');
  const [filteredItems, setFilteredItems] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortOption, setSortOption] = useState('');
  const [priceRange, setPriceRange] = useState({ min: 0, max: 500 });

  // Synchronize state with URL params (category, tag, search)
  useEffect(() => {
    setSelectedCategory(category || 'all');
    setSelectedTag(tag || '');
    setSearchKeyword(search || '');
  }, [category, tag, search]);

  // Main filtering and sorting effect
  useEffect(() => {
    let matchingItems = initialItems;

    // Apply category filter
    if (selectedCategory) {
      matchingItems = handleCategoryChange(selectedCategory);
    }

    // Apply tag filter
    if (selectedTag) {
      matchingItems = handleTagChange(selectedTag);
    }

    // Apply search keyword filter
    if (searchKeyword) {
      matchingItems = handleSearchChange(searchKeyword);
    }

    // Apply price range filter (only for 'shop' type)
    if (type === 'shop' && priceRange) {
      matchingItems = handlePriceRange(matchingItems);
    }

    // Apply sorting
    matchingItems = handleSortChange(matchingItems, sortOption);

    // Update filtered items and reset to the first page
    setFilteredItems(matchingItems);
    setCurrentPage(1);

  }, [selectedCategory, selectedTag, searchKeyword, priceRange, initialItems, sortOption, type]);

  /*************** 1-Category Change ***************/
  /**
   * Filters items by category.
   * 
   * @param {Array} items - The items to filter.
   * @param {string} category - The selected category.
   * @returns {Array} - Filtered items.
   */

  const handleCategoryChange = (category) => {
    if (category.toLowerCase() === 'all') return initialItems;
  
    return initialItems.filter(item => {
      if (Array.isArray(item.category)) {

        // Handle shop category (array)
        return item.category.some(cat => cat.toLowerCase() === category.toLowerCase());
      } else if (typeof item.category === 'string') {

        // Handle blog category (string)
        return item.category.toLowerCase() === category.toLowerCase();
      }

      return false;
    });
  };
  

  /*************** 2-Tag Change ***************/
  /**
   * Filters items by tag.
   * 
   * @param {Array} items - The items to filter.
   * @param {string} tag - The selected tag.
   * @returns {Array} - Filtered items.
   */
  const handleTagChange = (tag) => {
    return initialItems.filter(item => item.tags?.some(t => t.toLowerCase() === tag.toLowerCase()));
  };

  /*************** 3-Search Change ***************/
  /**
   * Filters items by search keyword.
   * 
   * @param {Array} items - The items to filter.
   * @param {string} searchTerm - The search keyword.
   * @param {string} type - The type of items (e.g., 'blog' or 'shop').
   * @returns {Array} - Filtered items.
   */
  const handleSearchChange = (searchTerm) => {
    return initialItems.filter(item => {
      const searchLower = searchTerm.toLowerCase();
      switch(type) {
        case 'blog':
          return item.heading?.toLowerCase().includes(searchLower);
        case 'shop':
          return item.name?.toLowerCase().includes(searchLower);
        default:
          return false;
      }
    });

  };

  /**
   * Handles search submission and updates the URL.
   * 
   * @param {string} selectedSearchQuery - The search query.
   */
  const handleSearchSubmit = (selectedSearchQuery) => {
    setSelectedCategory('all');
    setSelectedTag('');
    const encodedQuery = encodeURIComponent(selectedSearchQuery);
    navigate(`/${type === 'blog' ? 'Blogs' : 'Shop'}/search/${encodedQuery}`);
  };


  /*************** 5-Price Range ***************/
    /**
   * Filters items by price range.
   * 
   * @param {Array} items - The items to filter.
   * @param {Object} range - The price range (min and max).
   * @returns {Array} - Filtered items.
   */
  const handlePriceRange = (items) => {
    return items.filter(item => item.price >= priceRange.min && item.price <= priceRange.max);
  };

  /*************** 6-Sort Option ***************/
  /**
   * Sorts items based on the selected option.
   * 
   * @param {Array} items - The items to sort.
   * @param {string} sortOption - The sorting option.
   * @returns {Array} - Sorted items.
   */
  const handleSortChange = (items, sortOption) => {

    switch (sortOption) {
      case 'featured': 
        return getPopular(items);
      case 'lowPrice':
        return [...items].sort((a, b) => a.price - b.price);
      case 'highPrice':
        return [...items].sort((a, b) => b.price - a.price);
      default:
        return items;
    
    }

  };

  /**
   * Handles sorting option change.
   * 
   * @param {Object} selectedOption - The selected sorting option.
   */
  const handleSort = (selectedOption) => {
    setSortOption(selectedOption ? selectedOption.value : '');
    setCurrentPage(1); // Reset to the first page on sort change
  };

  /*************** 7-Page Change ***************/

  // Calculate pagination values
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const displayedItems = filteredItems.slice(startIndex, endIndex);
  const totalPages = Math.ceil(filteredItems.length / itemsPerPage);

    /**
   * Handles page change.
   * 
   * @param {number} page - The page number to navigate to.
   */
  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  /********************** Return Values **********************/
  return {
    selectedCategory,
    selectedTag,
    searchKeyword,
    filteredItems,
    displayedItems,
    currentPage,
    totalPages,
    priceRange,
    setPriceRange,
    sortOption,
    handleSort,
    handleSearchSubmit,
    handlePageChange,
  };

};
