// Function to get items by their IDs
export const getItemsByIds = (ids, items) => {

  // Map through each item ID and find the corresponding item object from the items array
  return ids.map(id => items.find(item => item.id === id));

};