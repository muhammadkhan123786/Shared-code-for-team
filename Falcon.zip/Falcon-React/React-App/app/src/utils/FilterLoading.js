import { useState, useEffect } from 'react';

// Custom hook to track filtering state
export const useFilterLoading = (filteredItems, searchKeyword) => {

  // State to track whether filtering is in progress
  const [isFiltering, setIsFiltering] = useState(true);

  // Reset isFiltering to true whenever the search keyword changes
  useEffect(() => { 
    setIsFiltering(true);
  }, [searchKeyword]);

  // Set isFiltering to false when filtering is complete
  useEffect(() => {
    // If there are filtered items or a search keyword is present, filtering is considered complete
    if (filteredItems.length > 0 || searchKeyword) {
      setIsFiltering(false);
    }
  }, [filteredItems, searchKeyword]);

  // Return the filtering status
  return isFiltering;

};